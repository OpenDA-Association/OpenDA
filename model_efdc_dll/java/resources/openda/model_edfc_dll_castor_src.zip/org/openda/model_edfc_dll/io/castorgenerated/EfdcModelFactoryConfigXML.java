/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_edfc_dll.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class EfdcModelFactoryConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class EfdcModelFactoryConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The path and name of the EFDC model dll file to use
     * (relative to this configuration file).
     */
    private java.lang.String _efdcDllFile;

    /**
     * The timeZone that is used by the EFDC model. This should be
     * the offset of the timeZone with respect to GMT, in hours
     * between -12 and 12.
     */
    private double _timeZoneOffset;

    /**
     * keeps track of state for field: _timeZoneOffset
     */
    private boolean _has_timeZoneOffset;

    /**
     * The model template directory (relative to this configuration
     * file). This directory will be cloned to create instance
     * directories.
     */
    private java.lang.String _templateDirectory;

    /**
     * Base name for instance directories (relative to this
     * configuration file). The number of the instance will be
     * appended to this base name to create the instance directory
     * name.
     */
    private java.lang.String _instanceDirectory;

    /**
     * The path and name of one or more input netcdf files
     * (relative to the instance directory). Together these input
     * files must contain all input data that is needed for the
     * model to run.
     */
    private java.util.ArrayList _inputFileList;

    /**
     * Field _useGateWaterLevel
     */
    private boolean _useGateWaterLevel = false;

    /**
     * keeps track of state for field: _useGateWaterLevel
     */
    private boolean _has_useGateWaterLevel;

    /**
     * The path and name of the model output netcdf file (relative
     * to the instance directory). This file will be created during
     * the model run. After each model timestep the model output
     * data will be written to this file.
     */
    private java.lang.String _modelOutputFile;

    /**
     * The path and name of the analysis output netcdf file
     * (relative to the instance directory). This file will be
     * created during the model run. After each analysis time the
     * updated state will be written to this file.
     */
    private java.lang.String _analysisOutputFile;


      //----------------/
     //- Constructors -/
    //----------------/

    public EfdcModelFactoryConfigXML() {
        super();
        _inputFileList = new ArrayList();
    } //-- org.openda.model_edfc_dll.io.castorgenerated.EfdcModelFactoryConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addInputFile
     * 
     * @param vInputFile
     */
    public void addInputFile(java.lang.String vInputFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _inputFileList.add(vInputFile);
    } //-- void addInputFile(java.lang.String) 

    /**
     * Method addInputFile
     * 
     * @param index
     * @param vInputFile
     */
    public void addInputFile(int index, java.lang.String vInputFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _inputFileList.add(index, vInputFile);
    } //-- void addInputFile(int, java.lang.String) 

    /**
     * Method clearInputFile
     */
    public void clearInputFile()
    {
        _inputFileList.clear();
    } //-- void clearInputFile() 

    /**
     * Method deleteUseGateWaterLevel
     */
    public void deleteUseGateWaterLevel()
    {
        this._has_useGateWaterLevel= false;
    } //-- void deleteUseGateWaterLevel() 

    /**
     * Method enumerateInputFile
     */
    public java.util.Enumeration enumerateInputFile()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_inputFileList.iterator());
    } //-- java.util.Enumeration enumerateInputFile() 

    /**
     * Returns the value of field 'analysisOutputFile'. The field
     * 'analysisOutputFile' has the following description: The path
     * and name of the analysis output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each analysis time the updated state will
     * be written to this file.
     * 
     * @return the value of field 'analysisOutputFile'.
     */
    public java.lang.String getAnalysisOutputFile()
    {
        return this._analysisOutputFile;
    } //-- java.lang.String getAnalysisOutputFile() 

    /**
     * Returns the value of field 'efdcDllFile'. The field
     * 'efdcDllFile' has the following description: The path and
     * name of the EFDC model dll file to use (relative to this
     * configuration file).
     * 
     * @return the value of field 'efdcDllFile'.
     */
    public java.lang.String getEfdcDllFile()
    {
        return this._efdcDllFile;
    } //-- java.lang.String getEfdcDllFile() 

    /**
     * Method getInputFile
     * 
     * @param index
     */
    public java.lang.String getInputFile(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _inputFileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_inputFileList.get(index);
    } //-- java.lang.String getInputFile(int) 

    /**
     * Method getInputFile
     */
    public java.lang.String[] getInputFile()
    {
        int size = _inputFileList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_inputFileList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getInputFile() 

    /**
     * Method getInputFileCount
     */
    public int getInputFileCount()
    {
        return _inputFileList.size();
    } //-- int getInputFileCount() 

    /**
     * Returns the value of field 'instanceDirectory'. The field
     * 'instanceDirectory' has the following description: Base name
     * for instance directories (relative to this configuration
     * file). The number of the instance will be appended to this
     * base name to create the instance directory name.
     * 
     * @return the value of field 'instanceDirectory'.
     */
    public java.lang.String getInstanceDirectory()
    {
        return this._instanceDirectory;
    } //-- java.lang.String getInstanceDirectory() 

    /**
     * Returns the value of field 'modelOutputFile'. The field
     * 'modelOutputFile' has the following description: The path
     * and name of the model output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each model timestep the model output data
     * will be written to this file.
     * 
     * @return the value of field 'modelOutputFile'.
     */
    public java.lang.String getModelOutputFile()
    {
        return this._modelOutputFile;
    } //-- java.lang.String getModelOutputFile() 

    /**
     * Returns the value of field 'templateDirectory'. The field
     * 'templateDirectory' has the following description: The model
     * template directory (relative to this configuration file).
     * This directory will be cloned to create instance
     * directories.
     * 
     * @return the value of field 'templateDirectory'.
     */
    public java.lang.String getTemplateDirectory()
    {
        return this._templateDirectory;
    } //-- java.lang.String getTemplateDirectory() 

    /**
     * Returns the value of field 'timeZoneOffset'. The field
     * 'timeZoneOffset' has the following description: The timeZone
     * that is used by the EFDC model. This should be the offset of
     * the timeZone with respect to GMT, in hours between -12 and
     * 12.
     * 
     * @return the value of field 'timeZoneOffset'.
     */
    public double getTimeZoneOffset()
    {
        return this._timeZoneOffset;
    } //-- double getTimeZoneOffset() 

    /**
     * Returns the value of field 'useGateWaterLevel'.
     * 
     * @return the value of field 'useGateWaterLevel'.
     */
    public boolean getUseGateWaterLevel()
    {
        return this._useGateWaterLevel;
    } //-- boolean getUseGateWaterLevel() 

    /**
     * Method hasTimeZoneOffset
     */
    public boolean hasTimeZoneOffset()
    {
        return this._has_timeZoneOffset;
    } //-- boolean hasTimeZoneOffset() 

    /**
     * Method hasUseGateWaterLevel
     */
    public boolean hasUseGateWaterLevel()
    {
        return this._has_useGateWaterLevel;
    } //-- boolean hasUseGateWaterLevel() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeInputFile
     * 
     * @param vInputFile
     */
    public boolean removeInputFile(java.lang.String vInputFile)
    {
        boolean removed = _inputFileList.remove(vInputFile);
        return removed;
    } //-- boolean removeInputFile(java.lang.String) 

    /**
     * Sets the value of field 'analysisOutputFile'. The field
     * 'analysisOutputFile' has the following description: The path
     * and name of the analysis output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each analysis time the updated state will
     * be written to this file.
     * 
     * @param analysisOutputFile the value of field
     * 'analysisOutputFile'.
     */
    public void setAnalysisOutputFile(java.lang.String analysisOutputFile)
    {
        this._analysisOutputFile = analysisOutputFile;
    } //-- void setAnalysisOutputFile(java.lang.String) 

    /**
     * Sets the value of field 'efdcDllFile'. The field
     * 'efdcDllFile' has the following description: The path and
     * name of the EFDC model dll file to use (relative to this
     * configuration file).
     * 
     * @param efdcDllFile the value of field 'efdcDllFile'.
     */
    public void setEfdcDllFile(java.lang.String efdcDllFile)
    {
        this._efdcDllFile = efdcDllFile;
    } //-- void setEfdcDllFile(java.lang.String) 

    /**
     * Method setInputFile
     * 
     * @param index
     * @param vInputFile
     */
    public void setInputFile(int index, java.lang.String vInputFile)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _inputFileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _inputFileList.set(index, vInputFile);
    } //-- void setInputFile(int, java.lang.String) 

    /**
     * Method setInputFile
     * 
     * @param inputFileArray
     */
    public void setInputFile(java.lang.String[] inputFileArray)
    {
        //-- copy array
        _inputFileList.clear();
        for (int i = 0; i < inputFileArray.length; i++) {
            _inputFileList.add(inputFileArray[i]);
        }
    } //-- void setInputFile(java.lang.String) 

    /**
     * Sets the value of field 'instanceDirectory'. The field
     * 'instanceDirectory' has the following description: Base name
     * for instance directories (relative to this configuration
     * file). The number of the instance will be appended to this
     * base name to create the instance directory name.
     * 
     * @param instanceDirectory the value of field
     * 'instanceDirectory'.
     */
    public void setInstanceDirectory(java.lang.String instanceDirectory)
    {
        this._instanceDirectory = instanceDirectory;
    } //-- void setInstanceDirectory(java.lang.String) 

    /**
     * Sets the value of field 'modelOutputFile'. The field
     * 'modelOutputFile' has the following description: The path
     * and name of the model output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each model timestep the model output data
     * will be written to this file.
     * 
     * @param modelOutputFile the value of field 'modelOutputFile'.
     */
    public void setModelOutputFile(java.lang.String modelOutputFile)
    {
        this._modelOutputFile = modelOutputFile;
    } //-- void setModelOutputFile(java.lang.String) 

    /**
     * Sets the value of field 'templateDirectory'. The field
     * 'templateDirectory' has the following description: The model
     * template directory (relative to this configuration file).
     * This directory will be cloned to create instance
     * directories.
     * 
     * @param templateDirectory the value of field
     * 'templateDirectory'.
     */
    public void setTemplateDirectory(java.lang.String templateDirectory)
    {
        this._templateDirectory = templateDirectory;
    } //-- void setTemplateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'timeZoneOffset'. The field
     * 'timeZoneOffset' has the following description: The timeZone
     * that is used by the EFDC model. This should be the offset of
     * the timeZone with respect to GMT, in hours between -12 and
     * 12.
     * 
     * @param timeZoneOffset the value of field 'timeZoneOffset'.
     */
    public void setTimeZoneOffset(double timeZoneOffset)
    {
        this._timeZoneOffset = timeZoneOffset;
        this._has_timeZoneOffset = true;
    } //-- void setTimeZoneOffset(double) 

    /**
     * Sets the value of field 'useGateWaterLevel'.
     * 
     * @param useGateWaterLevel the value of field
     * 'useGateWaterLevel'.
     */
    public void setUseGateWaterLevel(boolean useGateWaterLevel)
    {
        this._useGateWaterLevel = useGateWaterLevel;
        this._has_useGateWaterLevel = true;
    } //-- void setUseGateWaterLevel(boolean) 

    /**
     * Method unmarshalEfdcModelFactoryConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_edfc_dll.io.castorgenerated.EfdcModelFactoryConfigXML unmarshalEfdcModelFactoryConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_edfc_dll.io.castorgenerated.EfdcModelFactoryConfigXML) Unmarshaller.unmarshal(org.openda.model_edfc_dll.io.castorgenerated.EfdcModelFactoryConfigXML.class, reader);
    } //-- org.openda.model_edfc_dll.io.castorgenerated.EfdcModelFactoryConfigXML unmarshalEfdcModelFactoryConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
