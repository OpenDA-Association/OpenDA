/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ZeroMqModelStateExchangeItemXML.
 * 
 * @version $Revision$ $Date$
 */
public class ZeroMqModelStateExchangeItemXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public ZeroMqModelStateExchangeItemXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addZeroMqModelStateExchangeItemXMLItem
     * 
     * @param vZeroMqModelStateExchangeItemXMLItem
     */
    public void addZeroMqModelStateExchangeItemXMLItem(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem vZeroMqModelStateExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vZeroMqModelStateExchangeItemXMLItem);
    } //-- void addZeroMqModelStateExchangeItemXMLItem(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) 

    /**
     * Method addZeroMqModelStateExchangeItemXMLItem
     * 
     * @param index
     * @param vZeroMqModelStateExchangeItemXMLItem
     */
    public void addZeroMqModelStateExchangeItemXMLItem(int index, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem vZeroMqModelStateExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vZeroMqModelStateExchangeItemXMLItem);
    } //-- void addZeroMqModelStateExchangeItemXMLItem(int, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) 

    /**
     * Method clearZeroMqModelStateExchangeItemXMLItem
     */
    public void clearZeroMqModelStateExchangeItemXMLItem()
    {
        _items.clear();
    } //-- void clearZeroMqModelStateExchangeItemXMLItem() 

    /**
     * Method enumerateZeroMqModelStateExchangeItemXMLItem
     */
    public java.util.Enumeration enumerateZeroMqModelStateExchangeItemXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateZeroMqModelStateExchangeItemXMLItem() 

    /**
     * Method getZeroMqModelStateExchangeItemXMLItem
     * 
     * @param index
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem getZeroMqModelStateExchangeItemXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) _items.get(index);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem getZeroMqModelStateExchangeItemXMLItem(int) 

    /**
     * Method getZeroMqModelStateExchangeItemXMLItem
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem[] getZeroMqModelStateExchangeItemXMLItem()
    {
        int size = _items.size();
        org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem[] mArray = new org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem[] getZeroMqModelStateExchangeItemXMLItem() 

    /**
     * Method getZeroMqModelStateExchangeItemXMLItemCount
     */
    public int getZeroMqModelStateExchangeItemXMLItemCount()
    {
        return _items.size();
    } //-- int getZeroMqModelStateExchangeItemXMLItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeZeroMqModelStateExchangeItemXMLItem
     * 
     * @param vZeroMqModelStateExchangeItemXMLItem
     */
    public boolean removeZeroMqModelStateExchangeItemXMLItem(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem vZeroMqModelStateExchangeItemXMLItem)
    {
        boolean removed = _items.remove(vZeroMqModelStateExchangeItemXMLItem);
        return removed;
    } //-- boolean removeZeroMqModelStateExchangeItemXMLItem(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) 

    /**
     * Method setZeroMqModelStateExchangeItemXMLItem
     * 
     * @param index
     * @param vZeroMqModelStateExchangeItemXMLItem
     */
    public void setZeroMqModelStateExchangeItemXMLItem(int index, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem vZeroMqModelStateExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vZeroMqModelStateExchangeItemXMLItem);
    } //-- void setZeroMqModelStateExchangeItemXMLItem(int, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) 

    /**
     * Method setZeroMqModelStateExchangeItemXMLItem
     * 
     * @param zeroMqModelStateExchangeItemXMLItemArray
     */
    public void setZeroMqModelStateExchangeItemXMLItem(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem[] zeroMqModelStateExchangeItemXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < zeroMqModelStateExchangeItemXMLItemArray.length; i++) {
            _items.add(zeroMqModelStateExchangeItemXMLItemArray[i]);
        }
    } //-- void setZeroMqModelStateExchangeItemXMLItem(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem) 

    /**
     * Method unmarshalZeroMqModelStateExchangeItemXML
     * 
     * @param reader
     */
    public static org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML unmarshalZeroMqModelStateExchangeItemXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML) Unmarshaller.unmarshal(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML.class, reader);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML unmarshalZeroMqModelStateExchangeItemXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
