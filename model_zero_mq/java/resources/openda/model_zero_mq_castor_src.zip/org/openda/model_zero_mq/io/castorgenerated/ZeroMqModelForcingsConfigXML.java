/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ZeroMqModelForcingsConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class ZeroMqModelForcingsConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The data object containing the forcing data.
     */
    private org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML _dataObject;


      //----------------/
     //- Constructors -/
    //----------------/

    public ZeroMqModelForcingsConfigXML() {
        super();
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dataObject'. The field
     * 'dataObject' has the following description: The data object
     * containing the forcing data.
     * 
     * @return the value of field 'dataObject'.
     */
    public org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML getDataObject()
    {
        return this._dataObject;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML getDataObject() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dataObject'. The field 'dataObject'
     * has the following description: The data object containing
     * the forcing data.
     * 
     * @param dataObject the value of field 'dataObject'.
     */
    public void setDataObject(org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML dataObject)
    {
        this._dataObject = dataObject;
    } //-- void setDataObject(org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML) 

    /**
     * Method unmarshalZeroMqModelForcingsConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML unmarshalZeroMqModelForcingsConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) Unmarshaller.unmarshal(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML.class, reader);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML unmarshalZeroMqModelForcingsConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
