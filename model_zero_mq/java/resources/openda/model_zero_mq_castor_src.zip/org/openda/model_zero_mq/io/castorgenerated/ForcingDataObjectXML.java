/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ForcingDataObjectXML.
 * 
 * @version $Revision$ $Date$
 */
public class ForcingDataObjectXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The openda class name of the forcing's data object.
     */
    private java.lang.String _className;

    /**
     * Name of the forcing's data file.
     */
    private java.lang.String _file;

    /**
     * Input argument(s) for the corresponding openda:class
     */
    private java.util.ArrayList _argList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ForcingDataObjectXML() {
        super();
        _argList = new ArrayList();
    } //-- org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addArg
     * 
     * @param vArg
     */
    public void addArg(java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        _argList.add(vArg);
    } //-- void addArg(java.lang.String) 

    /**
     * Method addArg
     * 
     * @param index
     * @param vArg
     */
    public void addArg(int index, java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        _argList.add(index, vArg);
    } //-- void addArg(int, java.lang.String) 

    /**
     * Method clearArg
     */
    public void clearArg()
    {
        _argList.clear();
    } //-- void clearArg() 

    /**
     * Method enumerateArg
     */
    public java.util.Enumeration enumerateArg()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_argList.iterator());
    } //-- java.util.Enumeration enumerateArg() 

    /**
     * Method getArg
     * 
     * @param index
     */
    public java.lang.String getArg(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_argList.get(index);
    } //-- java.lang.String getArg(int) 

    /**
     * Method getArg
     */
    public java.lang.String[] getArg()
    {
        int size = _argList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_argList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getArg() 

    /**
     * Method getArgCount
     */
    public int getArgCount()
    {
        return _argList.size();
    } //-- int getArgCount() 

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: The openda class
     * name of the forcing's data object.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'file'. The field 'file' has the
     * following description: Name of the forcing's data file.
     * 
     * @return the value of field 'file'.
     */
    public java.lang.String getFile()
    {
        return this._file;
    } //-- java.lang.String getFile() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeArg
     * 
     * @param vArg
     */
    public boolean removeArg(java.lang.String vArg)
    {
        boolean removed = _argList.remove(vArg);
        return removed;
    } //-- boolean removeArg(java.lang.String) 

    /**
     * Method setArg
     * 
     * @param index
     * @param vArg
     */
    public void setArg(int index, java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _argList.set(index, vArg);
    } //-- void setArg(int, java.lang.String) 

    /**
     * Method setArg
     * 
     * @param argArray
     */
    public void setArg(java.lang.String[] argArray)
    {
        //-- copy array
        _argList.clear();
        for (int i = 0; i < argArray.length; i++) {
            _argList.add(argArray[i]);
        }
    } //-- void setArg(java.lang.String) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: The openda class name of the
     * forcing's data object.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'file'. The field 'file' has the
     * following description: Name of the forcing's data file.
     * 
     * @param file the value of field 'file'.
     */
    public void setFile(java.lang.String file)
    {
        this._file = file;
    } //-- void setFile(java.lang.String) 

    /**
     * Method unmarshalForcingDataObjectXML
     * 
     * @param reader
     */
    public static org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML unmarshalForcingDataObjectXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML) Unmarshaller.unmarshal(org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML.class, reader);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ForcingDataObjectXML unmarshalForcingDataObjectXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
