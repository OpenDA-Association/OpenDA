/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class ZeroMqModelStateExchangeItemXMLItem.
 * 
 * @version $Revision$ $Date$
 */
public class ZeroMqModelStateExchangeItemXMLItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _limitedExchangeItem
     */
    private org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItem _limitedExchangeItem;


      //----------------/
     //- Constructors -/
    //----------------/

    public ZeroMqModelStateExchangeItemXMLItem() {
        super();
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXMLItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'limitedExchangeItem'.
     * 
     * @return the value of field 'limitedExchangeItem'.
     */
    public org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItem getLimitedExchangeItem()
    {
        return this._limitedExchangeItem;
    } //-- org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItem getLimitedExchangeItem() 

    /**
     * Sets the value of field 'limitedExchangeItem'.
     * 
     * @param limitedExchangeItem the value of field
     * 'limitedExchangeItem'.
     */
    public void setLimitedExchangeItem(org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItem limitedExchangeItem)
    {
        this._limitedExchangeItem = limitedExchangeItem;
    } //-- void setLimitedExchangeItem(org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItem) 

}
