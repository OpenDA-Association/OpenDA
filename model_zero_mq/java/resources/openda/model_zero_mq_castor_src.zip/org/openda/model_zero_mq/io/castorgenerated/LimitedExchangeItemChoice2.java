/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class LimitedExchangeItemChoice2.
 * 
 * @version $Revision$ $Date$
 */
public class LimitedExchangeItemChoice2 implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Optional. If the value of a model exchange item is above the
     * upper limit, then the value is changed to the upper limit.
     */
    private double _upperLimit;

    /**
     * keeps track of state for field: _upperLimit
     */
    private boolean _has_upperLimit;

    /**
     * Optional. If the value of a model exchange item is above the
     * value of the value of this upper limit exchange item, then
     * the value is changed to the upper limit.
     *  
     */
    private java.lang.String _spaceVaryingUpperLimitExchangeItemId;


      //----------------/
     //- Constructors -/
    //----------------/

    public LimitedExchangeItemChoice2() {
        super();
    } //-- org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItemChoice2()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteUpperLimit
     */
    public void deleteUpperLimit()
    {
        this._has_upperLimit= false;
    } //-- void deleteUpperLimit() 

    /**
     * Returns the value of field
     * 'spaceVaryingUpperLimitExchangeItemId'. The field
     * 'spaceVaryingUpperLimitExchangeItemId' has the following
     * description: Optional. If the value of a model exchange item
     * is above the value of the value of this upper limit exchange
     * item, then the value is changed to the upper limit.
     *  
     * 
     * @return the value of field
     * 'spaceVaryingUpperLimitExchangeItemId'.
     */
    public java.lang.String getSpaceVaryingUpperLimitExchangeItemId()
    {
        return this._spaceVaryingUpperLimitExchangeItemId;
    } //-- java.lang.String getSpaceVaryingUpperLimitExchangeItemId() 

    /**
     * Returns the value of field 'upperLimit'. The field
     * 'upperLimit' has the following description: Optional. If the
     * value of a model exchange item is above the upper limit,
     * then the value is changed to the upper limit.
     * 
     * @return the value of field 'upperLimit'.
     */
    public double getUpperLimit()
    {
        return this._upperLimit;
    } //-- double getUpperLimit() 

    /**
     * Method hasUpperLimit
     */
    public boolean hasUpperLimit()
    {
        return this._has_upperLimit;
    } //-- boolean hasUpperLimit() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field
     * 'spaceVaryingUpperLimitExchangeItemId'. The field
     * 'spaceVaryingUpperLimitExchangeItemId' has the following
     * description: Optional. If the value of a model exchange item
     * is above the value of the value of this upper limit exchange
     * item, then the value is changed to the upper limit.
     *  
     * 
     * @param spaceVaryingUpperLimitExchangeItemId the value of
     * field 'spaceVaryingUpperLimitExchangeItemId'.
     */
    public void setSpaceVaryingUpperLimitExchangeItemId(java.lang.String spaceVaryingUpperLimitExchangeItemId)
    {
        this._spaceVaryingUpperLimitExchangeItemId = spaceVaryingUpperLimitExchangeItemId;
    } //-- void setSpaceVaryingUpperLimitExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'upperLimit'. The field 'upperLimit'
     * has the following description: Optional. If the value of a
     * model exchange item is above the upper limit, then the value
     * is changed to the upper limit.
     * 
     * @param upperLimit the value of field 'upperLimit'.
     */
    public void setUpperLimit(double upperLimit)
    {
        this._upperLimit = upperLimit;
        this._has_upperLimit = true;
    } //-- void setUpperLimit(double) 

    /**
     * Method unmarshalLimitedExchangeItemChoice2
     * 
     * @param reader
     */
    public static org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItemChoice2 unmarshalLimitedExchangeItemChoice2(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItemChoice2) Unmarshaller.unmarshal(org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItemChoice2.class, reader);
    } //-- org.openda.model_zero_mq.io.castorgenerated.LimitedExchangeItemChoice2 unmarshalLimitedExchangeItemChoice2(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
