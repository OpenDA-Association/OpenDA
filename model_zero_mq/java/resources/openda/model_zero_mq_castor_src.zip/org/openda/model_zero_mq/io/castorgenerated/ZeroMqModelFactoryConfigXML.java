/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ZeroMqModelFactoryConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class ZeroMqModelFactoryConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Path and name of the model template directory (relative to
     * this configuration file). This directory will be cloned to
     * create instance directories called work0, work1, work2, etc.
     * The work directories will be created next to the model
     * template directory, i.e. with the same parent directory.
     * Before each run, any work directories from previous runs
     * will be removed.
     */
    private java.lang.String _modelTemplateDirectory;

    /**
     * The path and name of the model configuration file (relative
     * to the model template directory).
     */
    private java.lang.String _modelConfigFile;

    /**
     * The directory in the model instance that contains the input
     * state
     */
    private java.lang.String _inputStateDirectory = "input_state";

    /**
     * The directory in the model instance that contains the input
     * state
     */
    private java.lang.String _outputStateDirectory = "output_state";

    /**
     * Julia WFlow port number.
     */
    private java.lang.String _executable;

    /**
     * Field _executableArguments
     */
    private org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments _executableArguments;

    /**
     * Julia WFlow host.
     */
    private java.lang.String _host;

    /**
     * Julia WFlow port number.
     */
    private int _port;

    /**
     * keeps track of state for field: _port
     */
    private boolean _has_port;

    /**
     * Field _zeroMqModelStateExchangeItems
     */
    private org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML _zeroMqModelStateExchangeItems;

    /**
     * NaN or a valid double value, indicating a missing value in
     * the model data. Default: NaN
     */
    private double _missingValue;

    /**
     * keeps track of state for field: _missingValue
     */
    private boolean _has_missingValue;


      //----------------/
     //- Constructors -/
    //----------------/

    public ZeroMqModelFactoryConfigXML() {
        super();
        setInputStateDirectory("input_state");
        setOutputStateDirectory("output_state");
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteMissingValue
     */
    public void deleteMissingValue()
    {
        this._has_missingValue= false;
    } //-- void deleteMissingValue() 

    /**
     * Method deletePort
     */
    public void deletePort()
    {
        this._has_port= false;
    } //-- void deletePort() 

    /**
     * Returns the value of field 'executable'. The field
     * 'executable' has the following description: Julia WFlow port
     * number.
     * 
     * @return the value of field 'executable'.
     */
    public java.lang.String getExecutable()
    {
        return this._executable;
    } //-- java.lang.String getExecutable() 

    /**
     * Returns the value of field 'executableArguments'.
     * 
     * @return the value of field 'executableArguments'.
     */
    public org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments getExecutableArguments()
    {
        return this._executableArguments;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments getExecutableArguments() 

    /**
     * Returns the value of field 'host'. The field 'host' has the
     * following description: Julia WFlow host.
     * 
     * @return the value of field 'host'.
     */
    public java.lang.String getHost()
    {
        return this._host;
    } //-- java.lang.String getHost() 

    /**
     * Returns the value of field 'inputStateDirectory'. The field
     * 'inputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @return the value of field 'inputStateDirectory'.
     */
    public java.lang.String getInputStateDirectory()
    {
        return this._inputStateDirectory;
    } //-- java.lang.String getInputStateDirectory() 

    /**
     * Returns the value of field 'missingValue'. The field
     * 'missingValue' has the following description: NaN or a valid
     * double value, indicating a missing value in the model data.
     * Default: NaN
     * 
     * @return the value of field 'missingValue'.
     */
    public double getMissingValue()
    {
        return this._missingValue;
    } //-- double getMissingValue() 

    /**
     * Returns the value of field 'modelConfigFile'. The field
     * 'modelConfigFile' has the following description: The path
     * and name of the model configuration file (relative to the
     * model template directory).
     * 
     * @return the value of field 'modelConfigFile'.
     */
    public java.lang.String getModelConfigFile()
    {
        return this._modelConfigFile;
    } //-- java.lang.String getModelConfigFile() 

    /**
     * Returns the value of field 'modelTemplateDirectory'. The
     * field 'modelTemplateDirectory' has the following
     * description: Path and name of the model template directory
     * (relative to this configuration file). This directory will
     * be cloned to create instance directories called work0,
     * work1, work2, etc. The work directories will be created next
     * to the model template directory, i.e. with the same parent
     * directory. Before each run, any work directories from
     * previous runs will be removed.
     * 
     * @return the value of field 'modelTemplateDirectory'.
     */
    public java.lang.String getModelTemplateDirectory()
    {
        return this._modelTemplateDirectory;
    } //-- java.lang.String getModelTemplateDirectory() 

    /**
     * Returns the value of field 'outputStateDirectory'. The field
     * 'outputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @return the value of field 'outputStateDirectory'.
     */
    public java.lang.String getOutputStateDirectory()
    {
        return this._outputStateDirectory;
    } //-- java.lang.String getOutputStateDirectory() 

    /**
     * Returns the value of field 'port'. The field 'port' has the
     * following description: Julia WFlow port number.
     * 
     * @return the value of field 'port'.
     */
    public int getPort()
    {
        return this._port;
    } //-- int getPort() 

    /**
     * Returns the value of field 'zeroMqModelStateExchangeItems'.
     * 
     * @return the value of field 'zeroMqModelStateExchangeItems'.
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML getZeroMqModelStateExchangeItems()
    {
        return this._zeroMqModelStateExchangeItems;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML getZeroMqModelStateExchangeItems() 

    /**
     * Method hasMissingValue
     */
    public boolean hasMissingValue()
    {
        return this._has_missingValue;
    } //-- boolean hasMissingValue() 

    /**
     * Method hasPort
     */
    public boolean hasPort()
    {
        return this._has_port;
    } //-- boolean hasPort() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'executable'. The field 'executable'
     * has the following description: Julia WFlow port number.
     * 
     * @param executable the value of field 'executable'.
     */
    public void setExecutable(java.lang.String executable)
    {
        this._executable = executable;
    } //-- void setExecutable(java.lang.String) 

    /**
     * Sets the value of field 'executableArguments'.
     * 
     * @param executableArguments the value of field
     * 'executableArguments'.
     */
    public void setExecutableArguments(org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments executableArguments)
    {
        this._executableArguments = executableArguments;
    } //-- void setExecutableArguments(org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments) 

    /**
     * Sets the value of field 'host'. The field 'host' has the
     * following description: Julia WFlow host.
     * 
     * @param host the value of field 'host'.
     */
    public void setHost(java.lang.String host)
    {
        this._host = host;
    } //-- void setHost(java.lang.String) 

    /**
     * Sets the value of field 'inputStateDirectory'. The field
     * 'inputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @param inputStateDirectory the value of field
     * 'inputStateDirectory'.
     */
    public void setInputStateDirectory(java.lang.String inputStateDirectory)
    {
        this._inputStateDirectory = inputStateDirectory;
    } //-- void setInputStateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'missingValue'. The field
     * 'missingValue' has the following description: NaN or a valid
     * double value, indicating a missing value in the model data.
     * Default: NaN
     * 
     * @param missingValue the value of field 'missingValue'.
     */
    public void setMissingValue(double missingValue)
    {
        this._missingValue = missingValue;
        this._has_missingValue = true;
    } //-- void setMissingValue(double) 

    /**
     * Sets the value of field 'modelConfigFile'. The field
     * 'modelConfigFile' has the following description: The path
     * and name of the model configuration file (relative to the
     * model template directory).
     * 
     * @param modelConfigFile the value of field 'modelConfigFile'.
     */
    public void setModelConfigFile(java.lang.String modelConfigFile)
    {
        this._modelConfigFile = modelConfigFile;
    } //-- void setModelConfigFile(java.lang.String) 

    /**
     * Sets the value of field 'modelTemplateDirectory'. The field
     * 'modelTemplateDirectory' has the following description: Path
     * and name of the model template directory (relative to this
     * configuration file). This directory will be cloned to create
     * instance directories called work0, work1, work2, etc. The
     * work directories will be created next to the model template
     * directory, i.e. with the same parent directory. Before each
     * run, any work directories from previous runs will be
     * removed.
     * 
     * @param modelTemplateDirectory the value of field
     * 'modelTemplateDirectory'.
     */
    public void setModelTemplateDirectory(java.lang.String modelTemplateDirectory)
    {
        this._modelTemplateDirectory = modelTemplateDirectory;
    } //-- void setModelTemplateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'outputStateDirectory'. The field
     * 'outputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @param outputStateDirectory the value of field
     * 'outputStateDirectory'.
     */
    public void setOutputStateDirectory(java.lang.String outputStateDirectory)
    {
        this._outputStateDirectory = outputStateDirectory;
    } //-- void setOutputStateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'port'. The field 'port' has the
     * following description: Julia WFlow port number.
     * 
     * @param port the value of field 'port'.
     */
    public void setPort(int port)
    {
        this._port = port;
        this._has_port = true;
    } //-- void setPort(int) 

    /**
     * Sets the value of field 'zeroMqModelStateExchangeItems'.
     * 
     * @param zeroMqModelStateExchangeItems the value of field
     * 'zeroMqModelStateExchangeItems'.
     */
    public void setZeroMqModelStateExchangeItems(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML zeroMqModelStateExchangeItems)
    {
        this._zeroMqModelStateExchangeItems = zeroMqModelStateExchangeItems;
    } //-- void setZeroMqModelStateExchangeItems(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML) 

    /**
     * Method unmarshalZeroMqModelFactoryConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML unmarshalZeroMqModelFactoryConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML) Unmarshaller.unmarshal(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML.class, reader);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML unmarshalZeroMqModelFactoryConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
