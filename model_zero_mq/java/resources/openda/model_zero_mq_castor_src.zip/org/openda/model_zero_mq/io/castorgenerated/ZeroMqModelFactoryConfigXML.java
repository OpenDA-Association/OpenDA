/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_zero_mq.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ZeroMqModelFactoryConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class ZeroMqModelFactoryConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Path and name of the model template directory (relative to
     * this configuration file). This directory will be cloned to
     * create instance directories called work0, work1, work2, etc.
     * The work directories will be created next to the model
     * template directory, i.e. with the same parent directory.
     * Before each run, any work directories from previous runs
     * will be removed.
     */
    private java.lang.String _modelTemplateDirectory;

    /**
     * The path and name of the model configuration file (relative
     * to the model template directory).
     */
    private java.lang.String _modelConfigFile;

    /**
     * The directory in the model instance that contains the input
     * state
     */
    private java.lang.String _inputStateDirectory = "input_state";

    /**
     * The directory in the model instance that contains the input
     * state
     */
    private java.lang.String _outputStateDirectory = "output_state";

    /**
     * Julia WFlow port number.
     */
    private java.lang.String _executable;

    /**
     * Field _executableArguments
     */
    private org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments _executableArguments;

    /**
     * Julia WFlow host.
     */
    private java.lang.String _host;

    /**
     * First ZeroMQ port number, for each ensemble the port number
     * will be increased by 1.
     */
    private int _firstPortNumber;

    /**
     * keeps track of state for field: _firstPortNumber
     */
    private boolean _has_firstPortNumber;

    /**
     * Field _modelForcingsList
     */
    private java.util.ArrayList _modelForcingsList;

    /**
     * Field _spaceVaryingLimitsList
     */
    private java.util.ArrayList _spaceVaryingLimitsList;

    /**
     * Field _zeroMqModelStateExchangeItems
     */
    private org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML _zeroMqModelStateExchangeItems;

    /**
     * NaN or a valid double value, indicating a missing value in
     * the model data. Default: NaN
     */
    private double _missingValue;

    /**
     * keeps track of state for field: _missingValue
     */
    private boolean _has_missingValue;


      //----------------/
     //- Constructors -/
    //----------------/

    public ZeroMqModelFactoryConfigXML() {
        super();
        setInputStateDirectory("input_state");
        setOutputStateDirectory("output_state");
        _modelForcingsList = new ArrayList();
        _spaceVaryingLimitsList = new ArrayList();
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addModelForcings
     * 
     * @param vModelForcings
     */
    public void addModelForcings(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vModelForcings)
        throws java.lang.IndexOutOfBoundsException
    {
        _modelForcingsList.add(vModelForcings);
    } //-- void addModelForcings(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method addModelForcings
     * 
     * @param index
     * @param vModelForcings
     */
    public void addModelForcings(int index, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vModelForcings)
        throws java.lang.IndexOutOfBoundsException
    {
        _modelForcingsList.add(index, vModelForcings);
    } //-- void addModelForcings(int, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method addSpaceVaryingLimits
     * 
     * @param vSpaceVaryingLimits
     */
    public void addSpaceVaryingLimits(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vSpaceVaryingLimits)
        throws java.lang.IndexOutOfBoundsException
    {
        _spaceVaryingLimitsList.add(vSpaceVaryingLimits);
    } //-- void addSpaceVaryingLimits(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method addSpaceVaryingLimits
     * 
     * @param index
     * @param vSpaceVaryingLimits
     */
    public void addSpaceVaryingLimits(int index, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vSpaceVaryingLimits)
        throws java.lang.IndexOutOfBoundsException
    {
        _spaceVaryingLimitsList.add(index, vSpaceVaryingLimits);
    } //-- void addSpaceVaryingLimits(int, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method clearModelForcings
     */
    public void clearModelForcings()
    {
        _modelForcingsList.clear();
    } //-- void clearModelForcings() 

    /**
     * Method clearSpaceVaryingLimits
     */
    public void clearSpaceVaryingLimits()
    {
        _spaceVaryingLimitsList.clear();
    } //-- void clearSpaceVaryingLimits() 

    /**
     * Method deleteFirstPortNumber
     */
    public void deleteFirstPortNumber()
    {
        this._has_firstPortNumber= false;
    } //-- void deleteFirstPortNumber() 

    /**
     * Method deleteMissingValue
     */
    public void deleteMissingValue()
    {
        this._has_missingValue= false;
    } //-- void deleteMissingValue() 

    /**
     * Method enumerateModelForcings
     */
    public java.util.Enumeration enumerateModelForcings()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_modelForcingsList.iterator());
    } //-- java.util.Enumeration enumerateModelForcings() 

    /**
     * Method enumerateSpaceVaryingLimits
     */
    public java.util.Enumeration enumerateSpaceVaryingLimits()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_spaceVaryingLimitsList.iterator());
    } //-- java.util.Enumeration enumerateSpaceVaryingLimits() 

    /**
     * Returns the value of field 'executable'. The field
     * 'executable' has the following description: Julia WFlow port
     * number.
     * 
     * @return the value of field 'executable'.
     */
    public java.lang.String getExecutable()
    {
        return this._executable;
    } //-- java.lang.String getExecutable() 

    /**
     * Returns the value of field 'executableArguments'.
     * 
     * @return the value of field 'executableArguments'.
     */
    public org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments getExecutableArguments()
    {
        return this._executableArguments;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments getExecutableArguments() 

    /**
     * Returns the value of field 'firstPortNumber'. The field
     * 'firstPortNumber' has the following description: First
     * ZeroMQ port number, for each ensemble the port number will
     * be increased by 1.
     * 
     * @return the value of field 'firstPortNumber'.
     */
    public int getFirstPortNumber()
    {
        return this._firstPortNumber;
    } //-- int getFirstPortNumber() 

    /**
     * Returns the value of field 'host'. The field 'host' has the
     * following description: Julia WFlow host.
     * 
     * @return the value of field 'host'.
     */
    public java.lang.String getHost()
    {
        return this._host;
    } //-- java.lang.String getHost() 

    /**
     * Returns the value of field 'inputStateDirectory'. The field
     * 'inputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @return the value of field 'inputStateDirectory'.
     */
    public java.lang.String getInputStateDirectory()
    {
        return this._inputStateDirectory;
    } //-- java.lang.String getInputStateDirectory() 

    /**
     * Returns the value of field 'missingValue'. The field
     * 'missingValue' has the following description: NaN or a valid
     * double value, indicating a missing value in the model data.
     * Default: NaN
     * 
     * @return the value of field 'missingValue'.
     */
    public double getMissingValue()
    {
        return this._missingValue;
    } //-- double getMissingValue() 

    /**
     * Returns the value of field 'modelConfigFile'. The field
     * 'modelConfigFile' has the following description: The path
     * and name of the model configuration file (relative to the
     * model template directory).
     * 
     * @return the value of field 'modelConfigFile'.
     */
    public java.lang.String getModelConfigFile()
    {
        return this._modelConfigFile;
    } //-- java.lang.String getModelConfigFile() 

    /**
     * Method getModelForcings
     * 
     * @param index
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML getModelForcings(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _modelForcingsList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) _modelForcingsList.get(index);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML getModelForcings(int) 

    /**
     * Method getModelForcings
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] getModelForcings()
    {
        int size = _modelForcingsList.size();
        org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] mArray = new org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) _modelForcingsList.get(index);
        }
        return mArray;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] getModelForcings() 

    /**
     * Method getModelForcingsCount
     */
    public int getModelForcingsCount()
    {
        return _modelForcingsList.size();
    } //-- int getModelForcingsCount() 

    /**
     * Returns the value of field 'modelTemplateDirectory'. The
     * field 'modelTemplateDirectory' has the following
     * description: Path and name of the model template directory
     * (relative to this configuration file). This directory will
     * be cloned to create instance directories called work0,
     * work1, work2, etc. The work directories will be created next
     * to the model template directory, i.e. with the same parent
     * directory. Before each run, any work directories from
     * previous runs will be removed.
     * 
     * @return the value of field 'modelTemplateDirectory'.
     */
    public java.lang.String getModelTemplateDirectory()
    {
        return this._modelTemplateDirectory;
    } //-- java.lang.String getModelTemplateDirectory() 

    /**
     * Returns the value of field 'outputStateDirectory'. The field
     * 'outputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @return the value of field 'outputStateDirectory'.
     */
    public java.lang.String getOutputStateDirectory()
    {
        return this._outputStateDirectory;
    } //-- java.lang.String getOutputStateDirectory() 

    /**
     * Method getSpaceVaryingLimits
     * 
     * @param index
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML getSpaceVaryingLimits(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _spaceVaryingLimitsList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) _spaceVaryingLimitsList.get(index);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML getSpaceVaryingLimits(int) 

    /**
     * Method getSpaceVaryingLimits
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] getSpaceVaryingLimits()
    {
        int size = _spaceVaryingLimitsList.size();
        org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] mArray = new org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) _spaceVaryingLimitsList.get(index);
        }
        return mArray;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] getSpaceVaryingLimits() 

    /**
     * Method getSpaceVaryingLimitsCount
     */
    public int getSpaceVaryingLimitsCount()
    {
        return _spaceVaryingLimitsList.size();
    } //-- int getSpaceVaryingLimitsCount() 

    /**
     * Returns the value of field 'zeroMqModelStateExchangeItems'.
     * 
     * @return the value of field 'zeroMqModelStateExchangeItems'.
     */
    public org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML getZeroMqModelStateExchangeItems()
    {
        return this._zeroMqModelStateExchangeItems;
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML getZeroMqModelStateExchangeItems() 

    /**
     * Method hasFirstPortNumber
     */
    public boolean hasFirstPortNumber()
    {
        return this._has_firstPortNumber;
    } //-- boolean hasFirstPortNumber() 

    /**
     * Method hasMissingValue
     */
    public boolean hasMissingValue()
    {
        return this._has_missingValue;
    } //-- boolean hasMissingValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeModelForcings
     * 
     * @param vModelForcings
     */
    public boolean removeModelForcings(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vModelForcings)
    {
        boolean removed = _modelForcingsList.remove(vModelForcings);
        return removed;
    } //-- boolean removeModelForcings(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method removeSpaceVaryingLimits
     * 
     * @param vSpaceVaryingLimits
     */
    public boolean removeSpaceVaryingLimits(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vSpaceVaryingLimits)
    {
        boolean removed = _spaceVaryingLimitsList.remove(vSpaceVaryingLimits);
        return removed;
    } //-- boolean removeSpaceVaryingLimits(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Sets the value of field 'executable'. The field 'executable'
     * has the following description: Julia WFlow port number.
     * 
     * @param executable the value of field 'executable'.
     */
    public void setExecutable(java.lang.String executable)
    {
        this._executable = executable;
    } //-- void setExecutable(java.lang.String) 

    /**
     * Sets the value of field 'executableArguments'.
     * 
     * @param executableArguments the value of field
     * 'executableArguments'.
     */
    public void setExecutableArguments(org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments executableArguments)
    {
        this._executableArguments = executableArguments;
    } //-- void setExecutableArguments(org.openda.model_zero_mq.io.castorgenerated.ExecutableArguments) 

    /**
     * Sets the value of field 'firstPortNumber'. The field
     * 'firstPortNumber' has the following description: First
     * ZeroMQ port number, for each ensemble the port number will
     * be increased by 1.
     * 
     * @param firstPortNumber the value of field 'firstPortNumber'.
     */
    public void setFirstPortNumber(int firstPortNumber)
    {
        this._firstPortNumber = firstPortNumber;
        this._has_firstPortNumber = true;
    } //-- void setFirstPortNumber(int) 

    /**
     * Sets the value of field 'host'. The field 'host' has the
     * following description: Julia WFlow host.
     * 
     * @param host the value of field 'host'.
     */
    public void setHost(java.lang.String host)
    {
        this._host = host;
    } //-- void setHost(java.lang.String) 

    /**
     * Sets the value of field 'inputStateDirectory'. The field
     * 'inputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @param inputStateDirectory the value of field
     * 'inputStateDirectory'.
     */
    public void setInputStateDirectory(java.lang.String inputStateDirectory)
    {
        this._inputStateDirectory = inputStateDirectory;
    } //-- void setInputStateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'missingValue'. The field
     * 'missingValue' has the following description: NaN or a valid
     * double value, indicating a missing value in the model data.
     * Default: NaN
     * 
     * @param missingValue the value of field 'missingValue'.
     */
    public void setMissingValue(double missingValue)
    {
        this._missingValue = missingValue;
        this._has_missingValue = true;
    } //-- void setMissingValue(double) 

    /**
     * Sets the value of field 'modelConfigFile'. The field
     * 'modelConfigFile' has the following description: The path
     * and name of the model configuration file (relative to the
     * model template directory).
     * 
     * @param modelConfigFile the value of field 'modelConfigFile'.
     */
    public void setModelConfigFile(java.lang.String modelConfigFile)
    {
        this._modelConfigFile = modelConfigFile;
    } //-- void setModelConfigFile(java.lang.String) 

    /**
     * Method setModelForcings
     * 
     * @param index
     * @param vModelForcings
     */
    public void setModelForcings(int index, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vModelForcings)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _modelForcingsList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _modelForcingsList.set(index, vModelForcings);
    } //-- void setModelForcings(int, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method setModelForcings
     * 
     * @param modelForcingsArray
     */
    public void setModelForcings(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] modelForcingsArray)
    {
        //-- copy array
        _modelForcingsList.clear();
        for (int i = 0; i < modelForcingsArray.length; i++) {
            _modelForcingsList.add(modelForcingsArray[i]);
        }
    } //-- void setModelForcings(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Sets the value of field 'modelTemplateDirectory'. The field
     * 'modelTemplateDirectory' has the following description: Path
     * and name of the model template directory (relative to this
     * configuration file). This directory will be cloned to create
     * instance directories called work0, work1, work2, etc. The
     * work directories will be created next to the model template
     * directory, i.e. with the same parent directory. Before each
     * run, any work directories from previous runs will be
     * removed.
     * 
     * @param modelTemplateDirectory the value of field
     * 'modelTemplateDirectory'.
     */
    public void setModelTemplateDirectory(java.lang.String modelTemplateDirectory)
    {
        this._modelTemplateDirectory = modelTemplateDirectory;
    } //-- void setModelTemplateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'outputStateDirectory'. The field
     * 'outputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @param outputStateDirectory the value of field
     * 'outputStateDirectory'.
     */
    public void setOutputStateDirectory(java.lang.String outputStateDirectory)
    {
        this._outputStateDirectory = outputStateDirectory;
    } //-- void setOutputStateDirectory(java.lang.String) 

    /**
     * Method setSpaceVaryingLimits
     * 
     * @param index
     * @param vSpaceVaryingLimits
     */
    public void setSpaceVaryingLimits(int index, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML vSpaceVaryingLimits)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _spaceVaryingLimitsList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _spaceVaryingLimitsList.set(index, vSpaceVaryingLimits);
    } //-- void setSpaceVaryingLimits(int, org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Method setSpaceVaryingLimits
     * 
     * @param spaceVaryingLimitsArray
     */
    public void setSpaceVaryingLimits(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML[] spaceVaryingLimitsArray)
    {
        //-- copy array
        _spaceVaryingLimitsList.clear();
        for (int i = 0; i < spaceVaryingLimitsArray.length; i++) {
            _spaceVaryingLimitsList.add(spaceVaryingLimitsArray[i]);
        }
    } //-- void setSpaceVaryingLimits(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelForcingsConfigXML) 

    /**
     * Sets the value of field 'zeroMqModelStateExchangeItems'.
     * 
     * @param zeroMqModelStateExchangeItems the value of field
     * 'zeroMqModelStateExchangeItems'.
     */
    public void setZeroMqModelStateExchangeItems(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML zeroMqModelStateExchangeItems)
    {
        this._zeroMqModelStateExchangeItems = zeroMqModelStateExchangeItems;
    } //-- void setZeroMqModelStateExchangeItems(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelStateExchangeItemXML) 

    /**
     * Method unmarshalZeroMqModelFactoryConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML unmarshalZeroMqModelFactoryConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML) Unmarshaller.unmarshal(org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML.class, reader);
    } //-- org.openda.model_zero_mq.io.castorgenerated.ZeroMqModelFactoryConfigXML unmarshalZeroMqModelFactoryConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
