/* -*- Mode: C; c-basic-offset:4 ; -*- */
/*
 *
 *  (C) 2001 by Argonne National Laboratory.
 *      See COPYRIGHT in top-level directory.
 */
#define MPID_STATE_SYS_GETHOSTBYNAME 0
#define MPID_STATE_SYS_CONNECT 0
#define MPID_STATE_SYS_ACCEPT 0
