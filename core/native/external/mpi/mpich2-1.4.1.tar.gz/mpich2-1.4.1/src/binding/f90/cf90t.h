/* This is a dummy header file that is used to create the Fortran 
   interfaces for the Type_create_f90_xxx files */
/* Begin Prototypes */
int MPI_Type_create_f90_integer( int, MPI_Datatype * );
int MPI_Type_create_f90_real( int, int, MPI_Datatype * );
int MPI_Type_create_f90_complex( int, int, MPI_Datatype * );
/* End Prototypes */
