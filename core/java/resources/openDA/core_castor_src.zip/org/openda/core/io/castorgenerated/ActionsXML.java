/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ActionsXML.
 * 
 * @version $Revision$ $Date$
 */
public class ActionsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the consecutive actions by model executables or
     * classes to run, arguments to supply and fail/success checks
     * to perform
     */
    private java.util.ArrayList _actionList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ActionsXML() {
        super();
        _actionList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.ActionsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addAction
     * 
     * @param vAction
     */
    public void addAction(org.openda.core.io.castorgenerated.ActionXML vAction)
        throws java.lang.IndexOutOfBoundsException
    {
        _actionList.add(vAction);
    } //-- void addAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method addAction
     * 
     * @param index
     * @param vAction
     */
    public void addAction(int index, org.openda.core.io.castorgenerated.ActionXML vAction)
        throws java.lang.IndexOutOfBoundsException
    {
        _actionList.add(index, vAction);
    } //-- void addAction(int, org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method clearAction
     */
    public void clearAction()
    {
        _actionList.clear();
    } //-- void clearAction() 

    /**
     * Method enumerateAction
     */
    public java.util.Enumeration enumerateAction()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_actionList.iterator());
    } //-- java.util.Enumeration enumerateAction() 

    /**
     * Method getAction
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.ActionXML getAction(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _actionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.ActionXML) _actionList.get(index);
    } //-- org.openda.core.io.castorgenerated.ActionXML getAction(int) 

    /**
     * Method getAction
     */
    public org.openda.core.io.castorgenerated.ActionXML[] getAction()
    {
        int size = _actionList.size();
        org.openda.core.io.castorgenerated.ActionXML[] mArray = new org.openda.core.io.castorgenerated.ActionXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.ActionXML) _actionList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.ActionXML[] getAction() 

    /**
     * Method getActionCount
     */
    public int getActionCount()
    {
        return _actionList.size();
    } //-- int getActionCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAction
     * 
     * @param vAction
     */
    public boolean removeAction(org.openda.core.io.castorgenerated.ActionXML vAction)
    {
        boolean removed = _actionList.remove(vAction);
        return removed;
    } //-- boolean removeAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method setAction
     * 
     * @param index
     * @param vAction
     */
    public void setAction(int index, org.openda.core.io.castorgenerated.ActionXML vAction)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _actionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _actionList.set(index, vAction);
    } //-- void setAction(int, org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method setAction
     * 
     * @param actionArray
     */
    public void setAction(org.openda.core.io.castorgenerated.ActionXML[] actionArray)
    {
        //-- copy array
        _actionList.clear();
        for (int i = 0; i < actionArray.length; i++) {
            _actionList.add(actionArray[i]);
        }
    } //-- void setAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method unmarshalActionsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ActionsXML unmarshalActionsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ActionsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ActionsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ActionsXML unmarshalActionsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
