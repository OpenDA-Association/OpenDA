/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Type of operation to performed when noise is added to an
 * (parameter or state) exchange item: add the noise to the
 * exchange item's values, multiply the exchange item's values with
 * the noise, or set the values (used in those cases where the
 * noise in fact is a realization)
 * 
 * @version $Revision$ $Date$
 */
public class NoiseOperationTypesXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The add type
     */
    public static final int ADD_TYPE = 0;

    /**
     * The instance of the add type
     */
    public static final NoiseOperationTypesXML ADD = new NoiseOperationTypesXML(ADD_TYPE, "add");

    /**
     * The multiply type
     */
    public static final int MULTIPLY_TYPE = 1;

    /**
     * The instance of the multiply type
     */
    public static final NoiseOperationTypesXML MULTIPLY = new NoiseOperationTypesXML(MULTIPLY_TYPE, "multiply");

    /**
     * The set type
     */
    public static final int SET_TYPE = 2;

    /**
     * The instance of the set type
     */
    public static final NoiseOperationTypesXML SET = new NoiseOperationTypesXML(SET_TYPE, "set");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private NoiseOperationTypesXML(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of NoiseOperationTypesXML
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this NoiseOperationTypesXML
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("add", ADD);
        members.put("multiply", MULTIPLY);
        members.put("set", SET);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * NoiseOperationTypesXML
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new NoiseOperationTypesXML based on
     * the given String value.
     * 
     * @param string
     */
    public static org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid NoiseOperationTypesXML";
            throw new IllegalArgumentException(err);
        }
        return (NoiseOperationTypesXML) obj;
    } //-- org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML valueOf(java.lang.String) 

}
