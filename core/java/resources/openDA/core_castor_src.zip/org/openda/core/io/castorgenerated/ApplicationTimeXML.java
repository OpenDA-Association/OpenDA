/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ApplicationTimeXML.
 * 
 * @version $Revision$ $Date$
 */
public class ApplicationTimeXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Precision of handling time, treshold for comparing
     */
    private java.lang.String _precision;

    /**
     * Unit of precision supported values sec,min,hour,MJD
     */
    private java.lang.String _unit = "sec";


      //----------------/
     //- Constructors -/
    //----------------/

    public ApplicationTimeXML() {
        super();
        setUnit("sec");
    } //-- org.openda.core.io.castorgenerated.ApplicationTimeXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'precision'. The field
     * 'precision' has the following description: Precision of
     * handling time, treshold for comparing
     * 
     * @return the value of field 'precision'.
     */
    public java.lang.String getPrecision()
    {
        return this._precision;
    } //-- java.lang.String getPrecision() 

    /**
     * Returns the value of field 'unit'. The field 'unit' has the
     * following description: Unit of precision supported values
     * sec,min,hour,MJD
     * 
     * @return the value of field 'unit'.
     */
    public java.lang.String getUnit()
    {
        return this._unit;
    } //-- java.lang.String getUnit() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'precision'. The field 'precision'
     * has the following description: Precision of handling time,
     * treshold for comparing
     * 
     * @param precision the value of field 'precision'.
     */
    public void setPrecision(java.lang.String precision)
    {
        this._precision = precision;
    } //-- void setPrecision(java.lang.String) 

    /**
     * Sets the value of field 'unit'. The field 'unit' has the
     * following description: Unit of precision supported values
     * sec,min,hour,MJD
     * 
     * @param unit the value of field 'unit'.
     */
    public void setUnit(java.lang.String unit)
    {
        this._unit = unit;
    } //-- void setUnit(java.lang.String) 

    /**
     * Method unmarshalApplicationTimeXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ApplicationTimeXML unmarshalApplicationTimeXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ApplicationTimeXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ApplicationTimeXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ApplicationTimeXML unmarshalApplicationTimeXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
