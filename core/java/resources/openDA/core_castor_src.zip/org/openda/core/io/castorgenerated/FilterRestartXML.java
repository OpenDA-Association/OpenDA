/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.FilterNameXML;
import org.xml.sax.ContentHandler;

/**
 * Class FilterRestartXML.
 * 
 * @version $Revision$ $Date$
 */
public class FilterRestartXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _filterName
     */
    private org.openda.core.io.castorgenerated.types.FilterNameXML _filterName;

    /**
     * Field _comment
     */
    private java.lang.String _comment;

    /**
     * Field _ensemble
     */
    private org.openda.core.io.castorgenerated.EnsembleFiltersRestartXML _ensemble;


      //----------------/
     //- Constructors -/
    //----------------/

    public FilterRestartXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.FilterRestartXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'comment'.
     * 
     * @return the value of field 'comment'.
     */
    public java.lang.String getComment()
    {
        return this._comment;
    } //-- java.lang.String getComment() 

    /**
     * Returns the value of field 'ensemble'.
     * 
     * @return the value of field 'ensemble'.
     */
    public org.openda.core.io.castorgenerated.EnsembleFiltersRestartXML getEnsemble()
    {
        return this._ensemble;
    } //-- org.openda.core.io.castorgenerated.EnsembleFiltersRestartXML getEnsemble() 

    /**
     * Returns the value of field 'filterName'.
     * 
     * @return the value of field 'filterName'.
     */
    public org.openda.core.io.castorgenerated.types.FilterNameXML getFilterName()
    {
        return this._filterName;
    } //-- org.openda.core.io.castorgenerated.types.FilterNameXML getFilterName() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'comment'.
     * 
     * @param comment the value of field 'comment'.
     */
    public void setComment(java.lang.String comment)
    {
        this._comment = comment;
    } //-- void setComment(java.lang.String) 

    /**
     * Sets the value of field 'ensemble'.
     * 
     * @param ensemble the value of field 'ensemble'.
     */
    public void setEnsemble(org.openda.core.io.castorgenerated.EnsembleFiltersRestartXML ensemble)
    {
        this._ensemble = ensemble;
    } //-- void setEnsemble(org.openda.core.io.castorgenerated.EnsembleFiltersRestartXML) 

    /**
     * Sets the value of field 'filterName'.
     * 
     * @param filterName the value of field 'filterName'.
     */
    public void setFilterName(org.openda.core.io.castorgenerated.types.FilterNameXML filterName)
    {
        this._filterName = filterName;
    } //-- void setFilterName(org.openda.core.io.castorgenerated.types.FilterNameXML) 

    /**
     * Method unmarshalFilterRestartXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.FilterRestartXML unmarshalFilterRestartXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.FilterRestartXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.FilterRestartXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.FilterRestartXML unmarshalFilterRestartXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
