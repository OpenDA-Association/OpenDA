/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class StateNoiseXMLChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
public class StateNoiseXMLChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The model's vector that the noise will be added to.
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML _vector;

    /**
     * The model's vector that the noise will be added to.
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML _subVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public StateNoiseXMLChoiceItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.StateNoiseXMLChoiceItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'subVector'. The field
     * 'subVector' has the following description: The model's
     * vector that the noise will be added to.
     * 
     * @return the value of field 'subVector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML getSubVector()
    {
        return this._subVector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML getSubVector() 

    /**
     * Returns the value of field 'vector'. The field 'vector' has
     * the following description: The model's vector that the noise
     * will be added to.
     * 
     * @return the value of field 'vector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML getVector()
    {
        return this._vector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML getVector() 

    /**
     * Sets the value of field 'subVector'. The field 'subVector'
     * has the following description: The model's vector that the
     * noise will be added to.
     * 
     * @param subVector the value of field 'subVector'.
     */
    public void setSubVector(org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML subVector)
    {
        this._subVector = subVector;
    } //-- void setSubVector(org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML) 

    /**
     * Sets the value of field 'vector'. The field 'vector' has the
     * following description: The model's vector that the noise
     * will be added to.
     * 
     * @param vector the value of field 'vector'.
     */
    public void setVector(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML vector)
    {
        this._vector = vector;
    } //-- void setVector(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML) 

}
