/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class BlackBoxStochModelVectorsXMLItem.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelVectorsXMLItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Add a vector to the predictor
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML _vector;

    /**
     * Add a subvector to the predictor
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML _subVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelVectorsXMLItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'subVector'. The field
     * 'subVector' has the following description: Add a subvector
     * to the predictor
     * 
     * @return the value of field 'subVector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML getSubVector()
    {
        return this._subVector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML getSubVector() 

    /**
     * Returns the value of field 'vector'. The field 'vector' has
     * the following description: Add a vector to the predictor
     * 
     * @return the value of field 'vector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML getVector()
    {
        return this._vector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML getVector() 

    /**
     * Sets the value of field 'subVector'. The field 'subVector'
     * has the following description: Add a subvector to the
     * predictor
     * 
     * @param subVector the value of field 'subVector'.
     */
    public void setSubVector(org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML subVector)
    {
        this._subVector = subVector;
    } //-- void setSubVector(org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML) 

    /**
     * Sets the value of field 'vector'. The field 'vector' has the
     * following description: Add a vector to the predictor
     * 
     * @param vector the value of field 'vector'.
     */
    public void setVector(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML vector)
    {
        this._vector = vector;
    } //-- void setVector(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML) 

}
