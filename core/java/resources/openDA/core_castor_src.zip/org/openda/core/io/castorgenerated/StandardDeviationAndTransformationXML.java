/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class StandardDeviationAndTransformationXML.
 * 
 * @version $Revision$ $Date$
 */
public class StandardDeviationAndTransformationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The standard deviation value
     */
    private double _value;

    /**
     * keeps track of state for field: _value
     */
    private boolean _has_value;

    /**
     * Set the initial value of this parameter (optional)
     */
    private double _initial = 0;

    /**
     * keeps track of state for field: _initial
     */
    private boolean _has_initial;

    /**
     * Transformation of correction factor. 'identity' means that
     * the correction will be added directly without any
     * transformation to the adjusted parameter. 'ln' means that
     * the correction is transformed logarithmically before it is
     * added to the parameter; this gives a correction, which is a
     * fraction of the parameter value. 'set' will set the
     * correction directly as the parameter value
     */
    private org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML _transformation = org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML.valueOf("identity");


      //----------------/
     //- Constructors -/
    //----------------/

    public StandardDeviationAndTransformationXML() {
        super();
        setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML.valueOf("identity"));
    } //-- org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteInitial
     */
    public void deleteInitial()
    {
        this._has_initial= false;
    } //-- void deleteInitial() 

    /**
     * Returns the value of field 'initial'. The field 'initial'
     * has the following description: Set the initial value of this
     * parameter (optional)
     * 
     * @return the value of field 'initial'.
     */
    public double getInitial()
    {
        return this._initial;
    } //-- double getInitial() 

    /**
     * Returns the value of field 'transformation'. The field
     * 'transformation' has the following description:
     * Transformation of correction factor. 'identity' means that
     * the correction will be added directly without any
     * transformation to the adjusted parameter. 'ln' means that
     * the correction is transformed logarithmically before it is
     * added to the parameter; this gives a correction, which is a
     * fraction of the parameter value. 'set' will set the
     * correction directly as the parameter value
     * 
     * @return the value of field 'transformation'.
     */
    public org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML getTransformation()
    {
        return this._transformation;
    } //-- org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML getTransformation() 

    /**
     * Returns the value of field 'value'. The field 'value' has
     * the following description: The standard deviation value
     * 
     * @return the value of field 'value'.
     */
    public double getValue()
    {
        return this._value;
    } //-- double getValue() 

    /**
     * Method hasInitial
     */
    public boolean hasInitial()
    {
        return this._has_initial;
    } //-- boolean hasInitial() 

    /**
     * Method hasValue
     */
    public boolean hasValue()
    {
        return this._has_value;
    } //-- boolean hasValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'initial'. The field 'initial' has
     * the following description: Set the initial value of this
     * parameter (optional)
     * 
     * @param initial the value of field 'initial'.
     */
    public void setInitial(double initial)
    {
        this._initial = initial;
        this._has_initial = true;
    } //-- void setInitial(double) 

    /**
     * Sets the value of field 'transformation'. The field
     * 'transformation' has the following description:
     * Transformation of correction factor. 'identity' means that
     * the correction will be added directly without any
     * transformation to the adjusted parameter. 'ln' means that
     * the correction is transformed logarithmically before it is
     * added to the parameter; this gives a correction, which is a
     * fraction of the parameter value. 'set' will set the
     * correction directly as the parameter value
     * 
     * @param transformation the value of field 'transformation'.
     */
    public void setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML transformation)
    {
        this._transformation = transformation;
    } //-- void setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML) 

    /**
     * Sets the value of field 'value'. The field 'value' has the
     * following description: The standard deviation value
     * 
     * @param value the value of field 'value'.
     */
    public void setValue(double value)
    {
        this._value = value;
        this._has_value = true;
    } //-- void setValue(double) 

    /**
     * Method unmarshalStandardDeviationAndTransformationXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML unmarshalStandardDeviationAndTransformationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML unmarshalStandardDeviationAndTransformationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
