/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TNC_timeSeriesExchangeItem.
 * 
 * @version $Revision$ $Date$
 */
public class TNC_timeSeriesExchangeItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id
     */
    private org.openda.core.io.castorgenerated.TNC_id _id;

    /**
     * Field _meta
     */
    private org.openda.core.io.castorgenerated.TNC_meta _meta;

    /**
     * Field _times
     */
    private org.openda.core.io.castorgenerated.TNC_times _times;

    /**
     * Field _values
     */
    private org.openda.core.io.castorgenerated.TNC_values _values;


      //----------------/
     //- Constructors -/
    //----------------/

    public TNC_timeSeriesExchangeItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'id'.
     */
    public org.openda.core.io.castorgenerated.TNC_id getId()
    {
        return this._id;
    } //-- org.openda.core.io.castorgenerated.TNC_id getId() 

    /**
     * Returns the value of field 'meta'.
     * 
     * @return the value of field 'meta'.
     */
    public org.openda.core.io.castorgenerated.TNC_meta getMeta()
    {
        return this._meta;
    } //-- org.openda.core.io.castorgenerated.TNC_meta getMeta() 

    /**
     * Returns the value of field 'times'.
     * 
     * @return the value of field 'times'.
     */
    public org.openda.core.io.castorgenerated.TNC_times getTimes()
    {
        return this._times;
    } //-- org.openda.core.io.castorgenerated.TNC_times getTimes() 

    /**
     * Returns the value of field 'values'.
     * 
     * @return the value of field 'values'.
     */
    public org.openda.core.io.castorgenerated.TNC_values getValues()
    {
        return this._values;
    } //-- org.openda.core.io.castorgenerated.TNC_values getValues() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(org.openda.core.io.castorgenerated.TNC_id id)
    {
        this._id = id;
    } //-- void setId(org.openda.core.io.castorgenerated.TNC_id) 

    /**
     * Sets the value of field 'meta'.
     * 
     * @param meta the value of field 'meta'.
     */
    public void setMeta(org.openda.core.io.castorgenerated.TNC_meta meta)
    {
        this._meta = meta;
    } //-- void setMeta(org.openda.core.io.castorgenerated.TNC_meta) 

    /**
     * Sets the value of field 'times'.
     * 
     * @param times the value of field 'times'.
     */
    public void setTimes(org.openda.core.io.castorgenerated.TNC_times times)
    {
        this._times = times;
    } //-- void setTimes(org.openda.core.io.castorgenerated.TNC_times) 

    /**
     * Sets the value of field 'values'.
     * 
     * @param values the value of field 'values'.
     */
    public void setValues(org.openda.core.io.castorgenerated.TNC_values values)
    {
        this._values = values;
    } //-- void setValues(org.openda.core.io.castorgenerated.TNC_values) 

    /**
     * Method unmarshalTNC_timeSeriesExchangeItem
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem unmarshalTNC_timeSeriesExchangeItem(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem.class, reader);
    } //-- org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem unmarshalTNC_timeSeriesExchangeItem(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
