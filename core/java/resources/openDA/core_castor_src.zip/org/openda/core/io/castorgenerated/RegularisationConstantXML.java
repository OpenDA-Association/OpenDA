/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class RegularisationConstantXML.
 * 
 * @version $Revision$ $Date$
 */
public class RegularisationConstantXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Set the scaling factor for this parameter (optional)
     */
    private double _scale = 1;

    /**
     * keeps track of state for field: _scale
     */
    private boolean _has_scale;

    /**
     * Optional id for composed items that are all modified by the
     * same parameter.
     *  If omitted, the id's of the separate item will be
     * concatenated. Note: the (concatenated) id is mainly used by
     * the sparse dud algorithm
     */
    private java.lang.String _id;

    /**
     * Field _regularisationConstantXMLChoice
     */
    private org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice _regularisationConstantXMLChoice;

    /**
     * Select the parameter vector(s) and/or subvector(s) to adjust
     */
    private java.util.ArrayList _regularisationConstantXMLChoice2List;


      //----------------/
     //- Constructors -/
    //----------------/

    public RegularisationConstantXML() {
        super();
        _regularisationConstantXMLChoice2List = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addRegularisationConstantXMLChoice2
     * 
     * @param vRegularisationConstantXMLChoice2
     */
    public void addRegularisationConstantXMLChoice2(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2 vRegularisationConstantXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        _regularisationConstantXMLChoice2List.add(vRegularisationConstantXMLChoice2);
    } //-- void addRegularisationConstantXMLChoice2(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) 

    /**
     * Method addRegularisationConstantXMLChoice2
     * 
     * @param index
     * @param vRegularisationConstantXMLChoice2
     */
    public void addRegularisationConstantXMLChoice2(int index, org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2 vRegularisationConstantXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        _regularisationConstantXMLChoice2List.add(index, vRegularisationConstantXMLChoice2);
    } //-- void addRegularisationConstantXMLChoice2(int, org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) 

    /**
     * Method clearRegularisationConstantXMLChoice2
     */
    public void clearRegularisationConstantXMLChoice2()
    {
        _regularisationConstantXMLChoice2List.clear();
    } //-- void clearRegularisationConstantXMLChoice2() 

    /**
     * Method deleteScale
     */
    public void deleteScale()
    {
        this._has_scale= false;
    } //-- void deleteScale() 

    /**
     * Method enumerateRegularisationConstantXMLChoice2
     */
    public java.util.Enumeration enumerateRegularisationConstantXMLChoice2()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_regularisationConstantXMLChoice2List.iterator());
    } //-- java.util.Enumeration enumerateRegularisationConstantXMLChoice2() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Optional id for composed items that
     * are all modified by the same parameter.
     *  If omitted, the id's of the separate item will be
     * concatenated. Note: the (concatenated) id is mainly used by
     * the sparse dud algorithm
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field
     * 'regularisationConstantXMLChoice'.
     * 
     * @return the value of field 'regularisationConstantXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice getRegularisationConstantXMLChoice()
    {
        return this._regularisationConstantXMLChoice;
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice getRegularisationConstantXMLChoice() 

    /**
     * Method getRegularisationConstantXMLChoice2
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2 getRegularisationConstantXMLChoice2(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _regularisationConstantXMLChoice2List.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) _regularisationConstantXMLChoice2List.get(index);
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2 getRegularisationConstantXMLChoice2(int) 

    /**
     * Method getRegularisationConstantXMLChoice2
     */
    public org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2[] getRegularisationConstantXMLChoice2()
    {
        int size = _regularisationConstantXMLChoice2List.size();
        org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2[] mArray = new org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) _regularisationConstantXMLChoice2List.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2[] getRegularisationConstantXMLChoice2() 

    /**
     * Method getRegularisationConstantXMLChoice2Count
     */
    public int getRegularisationConstantXMLChoice2Count()
    {
        return _regularisationConstantXMLChoice2List.size();
    } //-- int getRegularisationConstantXMLChoice2Count() 

    /**
     * Returns the value of field 'scale'. The field 'scale' has
     * the following description: Set the scaling factor for this
     * parameter (optional)
     * 
     * @return the value of field 'scale'.
     */
    public double getScale()
    {
        return this._scale;
    } //-- double getScale() 

    /**
     * Method hasScale
     */
    public boolean hasScale()
    {
        return this._has_scale;
    } //-- boolean hasScale() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeRegularisationConstantXMLChoice2
     * 
     * @param vRegularisationConstantXMLChoice2
     */
    public boolean removeRegularisationConstantXMLChoice2(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2 vRegularisationConstantXMLChoice2)
    {
        boolean removed = _regularisationConstantXMLChoice2List.remove(vRegularisationConstantXMLChoice2);
        return removed;
    } //-- boolean removeRegularisationConstantXMLChoice2(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Optional id for composed items that
     * are all modified by the same parameter.
     *  If omitted, the id's of the separate item will be
     * concatenated. Note: the (concatenated) id is mainly used by
     * the sparse dud algorithm
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'regularisationConstantXMLChoice'.
     * 
     * @param regularisationConstantXMLChoice the value of field
     * 'regularisationConstantXMLChoice'.
     */
    public void setRegularisationConstantXMLChoice(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice regularisationConstantXMLChoice)
    {
        this._regularisationConstantXMLChoice = regularisationConstantXMLChoice;
    } //-- void setRegularisationConstantXMLChoice(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice) 

    /**
     * Method setRegularisationConstantXMLChoice2
     * 
     * @param index
     * @param vRegularisationConstantXMLChoice2
     */
    public void setRegularisationConstantXMLChoice2(int index, org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2 vRegularisationConstantXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _regularisationConstantXMLChoice2List.size())) {
            throw new IndexOutOfBoundsException();
        }
        _regularisationConstantXMLChoice2List.set(index, vRegularisationConstantXMLChoice2);
    } //-- void setRegularisationConstantXMLChoice2(int, org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) 

    /**
     * Method setRegularisationConstantXMLChoice2
     * 
     * @param regularisationConstantXMLChoice2Array
     */
    public void setRegularisationConstantXMLChoice2(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2[] regularisationConstantXMLChoice2Array)
    {
        //-- copy array
        _regularisationConstantXMLChoice2List.clear();
        for (int i = 0; i < regularisationConstantXMLChoice2Array.length; i++) {
            _regularisationConstantXMLChoice2List.add(regularisationConstantXMLChoice2Array[i]);
        }
    } //-- void setRegularisationConstantXMLChoice2(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2) 

    /**
     * Sets the value of field 'scale'. The field 'scale' has the
     * following description: Set the scaling factor for this
     * parameter (optional)
     * 
     * @param scale the value of field 'scale'.
     */
    public void setScale(double scale)
    {
        this._scale = scale;
        this._has_scale = true;
    } //-- void setScale(double) 

    /**
     * Method unmarshalRegularisationConstantXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.RegularisationConstantXML unmarshalRegularisationConstantXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.RegularisationConstantXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.RegularisationConstantXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXML unmarshalRegularisationConstantXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
