/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class RangeValidationConstantLimitsConstraintXML.
 * 
 * @version $Revision$ $Date$
 */
public class RangeValidationConstantLimitsConstraintXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Each sourceExchangeItem is wrapped in a new
     * targetExchangeItem. The targetExchangeItemId is the
     * sourceExchangeItemId with the configured suffix appended.
     * Use that id to refer to this targetExchangeItem in other
     * parts of the configuration.
     */
    private java.lang.String _targetExchangeItemIdSuffix;

    /**
     * One or more ids of exchange items to which this constraint
     * should be applied. This can e.g. be a modelExchangeItem or a
     * targetExchangeItem from another constraint.
     */
    private java.util.ArrayList _sourceExchangeItemIdList;

    /**
     * Optional. If the value of a model exchange item is below the
     * lower limit, then the value is changed to the lower limit.
     */
    private double _lowerLimit;

    /**
     * keeps track of state for field: _lowerLimit
     */
    private boolean _has_lowerLimit;

    /**
     * Optional. If the value of a model exchange item is above the
     * upper limit, then the value is changed to the upper limit. 
     */
    private double _upperLimit;

    /**
     * keeps track of state for field: _upperLimit
     */
    private boolean _has_upperLimit;


      //----------------/
     //- Constructors -/
    //----------------/

    public RangeValidationConstantLimitsConstraintXML() {
        super();
        _sourceExchangeItemIdList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addSourceExchangeItemId
     * 
     * @param vSourceExchangeItemId
     */
    public void addSourceExchangeItemId(java.lang.String vSourceExchangeItemId)
        throws java.lang.IndexOutOfBoundsException
    {
        _sourceExchangeItemIdList.add(vSourceExchangeItemId);
    } //-- void addSourceExchangeItemId(java.lang.String) 

    /**
     * Method addSourceExchangeItemId
     * 
     * @param index
     * @param vSourceExchangeItemId
     */
    public void addSourceExchangeItemId(int index, java.lang.String vSourceExchangeItemId)
        throws java.lang.IndexOutOfBoundsException
    {
        _sourceExchangeItemIdList.add(index, vSourceExchangeItemId);
    } //-- void addSourceExchangeItemId(int, java.lang.String) 

    /**
     * Method clearSourceExchangeItemId
     */
    public void clearSourceExchangeItemId()
    {
        _sourceExchangeItemIdList.clear();
    } //-- void clearSourceExchangeItemId() 

    /**
     * Method deleteLowerLimit
     */
    public void deleteLowerLimit()
    {
        this._has_lowerLimit= false;
    } //-- void deleteLowerLimit() 

    /**
     * Method deleteUpperLimit
     */
    public void deleteUpperLimit()
    {
        this._has_upperLimit= false;
    } //-- void deleteUpperLimit() 

    /**
     * Method enumerateSourceExchangeItemId
     */
    public java.util.Enumeration enumerateSourceExchangeItemId()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_sourceExchangeItemIdList.iterator());
    } //-- java.util.Enumeration enumerateSourceExchangeItemId() 

    /**
     * Returns the value of field 'lowerLimit'. The field
     * 'lowerLimit' has the following description: Optional. If the
     * value of a model exchange item is below the lower limit,
     * then the value is changed to the lower limit.
     * 
     * @return the value of field 'lowerLimit'.
     */
    public double getLowerLimit()
    {
        return this._lowerLimit;
    } //-- double getLowerLimit() 

    /**
     * Method getSourceExchangeItemId
     * 
     * @param index
     */
    public java.lang.String getSourceExchangeItemId(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _sourceExchangeItemIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_sourceExchangeItemIdList.get(index);
    } //-- java.lang.String getSourceExchangeItemId(int) 

    /**
     * Method getSourceExchangeItemId
     */
    public java.lang.String[] getSourceExchangeItemId()
    {
        int size = _sourceExchangeItemIdList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_sourceExchangeItemIdList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getSourceExchangeItemId() 

    /**
     * Method getSourceExchangeItemIdCount
     */
    public int getSourceExchangeItemIdCount()
    {
        return _sourceExchangeItemIdList.size();
    } //-- int getSourceExchangeItemIdCount() 

    /**
     * Returns the value of field 'targetExchangeItemIdSuffix'. The
     * field 'targetExchangeItemIdSuffix' has the following
     * description: Each sourceExchangeItem is wrapped in a new
     * targetExchangeItem. The targetExchangeItemId is the
     * sourceExchangeItemId with the configured suffix appended.
     * Use that id to refer to this targetExchangeItem in other
     * parts of the configuration.
     * 
     * @return the value of field 'targetExchangeItemIdSuffix'.
     */
    public java.lang.String getTargetExchangeItemIdSuffix()
    {
        return this._targetExchangeItemIdSuffix;
    } //-- java.lang.String getTargetExchangeItemIdSuffix() 

    /**
     * Returns the value of field 'upperLimit'. The field
     * 'upperLimit' has the following description: Optional. If the
     * value of a model exchange item is above the upper limit,
     * then the value is changed to the upper limit. 
     * 
     * @return the value of field 'upperLimit'.
     */
    public double getUpperLimit()
    {
        return this._upperLimit;
    } //-- double getUpperLimit() 

    /**
     * Method hasLowerLimit
     */
    public boolean hasLowerLimit()
    {
        return this._has_lowerLimit;
    } //-- boolean hasLowerLimit() 

    /**
     * Method hasUpperLimit
     */
    public boolean hasUpperLimit()
    {
        return this._has_upperLimit;
    } //-- boolean hasUpperLimit() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeSourceExchangeItemId
     * 
     * @param vSourceExchangeItemId
     */
    public boolean removeSourceExchangeItemId(java.lang.String vSourceExchangeItemId)
    {
        boolean removed = _sourceExchangeItemIdList.remove(vSourceExchangeItemId);
        return removed;
    } //-- boolean removeSourceExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'lowerLimit'. The field 'lowerLimit'
     * has the following description: Optional. If the value of a
     * model exchange item is below the lower limit, then the value
     * is changed to the lower limit.
     * 
     * @param lowerLimit the value of field 'lowerLimit'.
     */
    public void setLowerLimit(double lowerLimit)
    {
        this._lowerLimit = lowerLimit;
        this._has_lowerLimit = true;
    } //-- void setLowerLimit(double) 

    /**
     * Method setSourceExchangeItemId
     * 
     * @param index
     * @param vSourceExchangeItemId
     */
    public void setSourceExchangeItemId(int index, java.lang.String vSourceExchangeItemId)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _sourceExchangeItemIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _sourceExchangeItemIdList.set(index, vSourceExchangeItemId);
    } //-- void setSourceExchangeItemId(int, java.lang.String) 

    /**
     * Method setSourceExchangeItemId
     * 
     * @param sourceExchangeItemIdArray
     */
    public void setSourceExchangeItemId(java.lang.String[] sourceExchangeItemIdArray)
    {
        //-- copy array
        _sourceExchangeItemIdList.clear();
        for (int i = 0; i < sourceExchangeItemIdArray.length; i++) {
            _sourceExchangeItemIdList.add(sourceExchangeItemIdArray[i]);
        }
    } //-- void setSourceExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'targetExchangeItemIdSuffix'. The
     * field 'targetExchangeItemIdSuffix' has the following
     * description: Each sourceExchangeItem is wrapped in a new
     * targetExchangeItem. The targetExchangeItemId is the
     * sourceExchangeItemId with the configured suffix appended.
     * Use that id to refer to this targetExchangeItem in other
     * parts of the configuration.
     * 
     * @param targetExchangeItemIdSuffix the value of field
     * 'targetExchangeItemIdSuffix'.
     */
    public void setTargetExchangeItemIdSuffix(java.lang.String targetExchangeItemIdSuffix)
    {
        this._targetExchangeItemIdSuffix = targetExchangeItemIdSuffix;
    } //-- void setTargetExchangeItemIdSuffix(java.lang.String) 

    /**
     * Sets the value of field 'upperLimit'. The field 'upperLimit'
     * has the following description: Optional. If the value of a
     * model exchange item is above the upper limit, then the value
     * is changed to the upper limit. 
     * 
     * @param upperLimit the value of field 'upperLimit'.
     */
    public void setUpperLimit(double upperLimit)
    {
        this._upperLimit = upperLimit;
        this._has_upperLimit = true;
    } //-- void setUpperLimit(double) 

    /**
     * Method unmarshalRangeValidationConstantLimitsConstraintXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML unmarshalRangeValidationConstantLimitsConstraintXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML unmarshalRangeValidationConstantLimitsConstraintXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
