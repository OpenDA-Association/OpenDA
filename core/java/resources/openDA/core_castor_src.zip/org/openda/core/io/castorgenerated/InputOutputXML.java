/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class InputOutputXML.
 * 
 * @version $Revision$ $Date$
 */
public class InputOutputXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputOutputXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.InputOutputXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addInputOutputXMLItem
     * 
     * @param vInputOutputXMLItem
     */
    public void addInputOutputXMLItem(org.openda.core.io.castorgenerated.InputOutputXMLItem vInputOutputXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vInputOutputXMLItem);
    } //-- void addInputOutputXMLItem(org.openda.core.io.castorgenerated.InputOutputXMLItem) 

    /**
     * Method addInputOutputXMLItem
     * 
     * @param index
     * @param vInputOutputXMLItem
     */
    public void addInputOutputXMLItem(int index, org.openda.core.io.castorgenerated.InputOutputXMLItem vInputOutputXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vInputOutputXMLItem);
    } //-- void addInputOutputXMLItem(int, org.openda.core.io.castorgenerated.InputOutputXMLItem) 

    /**
     * Method clearInputOutputXMLItem
     */
    public void clearInputOutputXMLItem()
    {
        _items.clear();
    } //-- void clearInputOutputXMLItem() 

    /**
     * Method enumerateInputOutputXMLItem
     */
    public java.util.Enumeration enumerateInputOutputXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateInputOutputXMLItem() 

    /**
     * Method getInputOutputXMLItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.InputOutputXMLItem getInputOutputXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.InputOutputXMLItem) _items.get(index);
    } //-- org.openda.core.io.castorgenerated.InputOutputXMLItem getInputOutputXMLItem(int) 

    /**
     * Method getInputOutputXMLItem
     */
    public org.openda.core.io.castorgenerated.InputOutputXMLItem[] getInputOutputXMLItem()
    {
        int size = _items.size();
        org.openda.core.io.castorgenerated.InputOutputXMLItem[] mArray = new org.openda.core.io.castorgenerated.InputOutputXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.InputOutputXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.InputOutputXMLItem[] getInputOutputXMLItem() 

    /**
     * Method getInputOutputXMLItemCount
     */
    public int getInputOutputXMLItemCount()
    {
        return _items.size();
    } //-- int getInputOutputXMLItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeInputOutputXMLItem
     * 
     * @param vInputOutputXMLItem
     */
    public boolean removeInputOutputXMLItem(org.openda.core.io.castorgenerated.InputOutputXMLItem vInputOutputXMLItem)
    {
        boolean removed = _items.remove(vInputOutputXMLItem);
        return removed;
    } //-- boolean removeInputOutputXMLItem(org.openda.core.io.castorgenerated.InputOutputXMLItem) 

    /**
     * Method setInputOutputXMLItem
     * 
     * @param index
     * @param vInputOutputXMLItem
     */
    public void setInputOutputXMLItem(int index, org.openda.core.io.castorgenerated.InputOutputXMLItem vInputOutputXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vInputOutputXMLItem);
    } //-- void setInputOutputXMLItem(int, org.openda.core.io.castorgenerated.InputOutputXMLItem) 

    /**
     * Method setInputOutputXMLItem
     * 
     * @param inputOutputXMLItemArray
     */
    public void setInputOutputXMLItem(org.openda.core.io.castorgenerated.InputOutputXMLItem[] inputOutputXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < inputOutputXMLItemArray.length; i++) {
            _items.add(inputOutputXMLItemArray[i]);
        }
    } //-- void setInputOutputXMLItem(org.openda.core.io.castorgenerated.InputOutputXMLItem) 

    /**
     * Method unmarshalInputOutputXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.InputOutputXML unmarshalInputOutputXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.InputOutputXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.InputOutputXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.InputOutputXML unmarshalInputOutputXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
