/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class ResultWriterOutputLevelXML.
 * 
 * @version $Revision$ $Date$
 */
public class ResultWriterOutputLevelXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The None type
     */
    public static final int NONE_TYPE = 0;

    /**
     * The instance of the None type
     */
    public static final ResultWriterOutputLevelXML NONE = new ResultWriterOutputLevelXML(NONE_TYPE, "None");

    /**
     * The Essential type
     */
    public static final int ESSENTIAL_TYPE = 1;

    /**
     * The instance of the Essential type
     */
    public static final ResultWriterOutputLevelXML ESSENTIAL = new ResultWriterOutputLevelXML(ESSENTIAL_TYPE, "Essential");

    /**
     * The Normal type
     */
    public static final int NORMAL_TYPE = 2;

    /**
     * The instance of the Normal type
     */
    public static final ResultWriterOutputLevelXML NORMAL = new ResultWriterOutputLevelXML(NORMAL_TYPE, "Normal");

    /**
     * The Verbose type
     */
    public static final int VERBOSE_TYPE = 3;

    /**
     * The instance of the Verbose type
     */
    public static final ResultWriterOutputLevelXML VERBOSE = new ResultWriterOutputLevelXML(VERBOSE_TYPE, "Verbose");

    /**
     * The All type
     */
    public static final int ALL_TYPE = 4;

    /**
     * The instance of the All type
     */
    public static final ResultWriterOutputLevelXML ALL = new ResultWriterOutputLevelXML(ALL_TYPE, "All");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private ResultWriterOutputLevelXML(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterOutputLevelXML(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of ResultWriterOutputLevelXML
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this
     * ResultWriterOutputLevelXML
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("None", NONE);
        members.put("Essential", ESSENTIAL);
        members.put("Normal", NORMAL);
        members.put("Verbose", VERBOSE);
        members.put("All", ALL);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * ResultWriterOutputLevelXML
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new ResultWriterOutputLevelXML based
     * on the given String value.
     * 
     * @param string
     */
    public static org.openda.core.io.castorgenerated.types.ResultWriterOutputLevelXML valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid ResultWriterOutputLevelXML";
            throw new IllegalArgumentException(err);
        }
        return (ResultWriterOutputLevelXML) obj;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterOutputLevelXML valueOf(java.lang.String) 

}
