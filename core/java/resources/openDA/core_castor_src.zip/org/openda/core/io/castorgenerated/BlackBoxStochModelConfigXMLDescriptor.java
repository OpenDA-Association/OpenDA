/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.mapping.AccessMode;
import org.exolab.castor.xml.TypeValidator;
import org.exolab.castor.xml.XMLFieldDescriptor;
import org.exolab.castor.xml.validators.*;

/**
 * Class BlackBoxStochModelConfigXMLDescriptor.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelConfigXMLDescriptor extends org.exolab.castor.xml.util.XMLClassDescriptorImpl {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field nsPrefix
     */
    private java.lang.String nsPrefix;

    /**
     * Field nsURI
     */
    private java.lang.String nsURI;

    /**
     * Field xmlName
     */
    private java.lang.String xmlName;

    /**
     * Field identity
     */
    private org.exolab.castor.xml.XMLFieldDescriptor identity;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelConfigXMLDescriptor() {
        super();
        nsURI = "http://www.openda.org";
        xmlName = "BlackBoxStochModelConfigXML";
        
        //-- set grouping compositor
        setCompositorAsSequence();
        org.exolab.castor.xml.util.XMLFieldDescriptorImpl  desc           = null;
        org.exolab.castor.xml.XMLFieldHandler              handler        = null;
        org.exolab.castor.xml.FieldValidator               fieldValidator = null;
        //-- initialize attribute descriptors
        
        //-- initialize element descriptors
        
        //-- _blackBoxStochModelConfigXMLChoice
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice.class, "_blackBoxStochModelConfigXMLChoice", "-error-if-this-is-used-", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                return target.getBlackBoxStochModelConfigXMLChoice();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                    target.setBlackBoxStochModelConfigXMLChoice( (org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice();
            }
        } );
        desc.setHandler(handler);
        desc.setContainer(true);
        desc.setClassDescriptor(new org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoiceDescriptor());
        desc.setRequired(true);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _blackBoxStochModelConfigXMLChoice
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _uncertaintyModule
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.core.io.castorgenerated.ActionXML.class, "_uncertaintyModule", "uncertaintyModule", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                return target.getUncertaintyModule();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                    target.setUncertaintyModule( (org.openda.core.io.castorgenerated.ActionXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.core.io.castorgenerated.ActionXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _uncertaintyModule
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _rangeValidationConfigFile
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_rangeValidationConfigFile", "rangeValidationConfigFile", org.exolab.castor.xml.NodeType.Element);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                return target.getRangeValidationConfigFile();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                    target.setRangeValidationConfigFile( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _rangeValidationConfigFile
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _boundaryProviderList
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.core.io.castorgenerated.BoundaryProviderXML.class, "_boundaryProviderList", "boundaryProvider", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                return target.getBoundaryProvider();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                    target.addBoundaryProvider( (org.openda.core.io.castorgenerated.BoundaryProviderXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.core.io.castorgenerated.BoundaryProviderXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(true);
        addFieldDescriptor(desc);
        
        //-- validation code for: _boundaryProviderList
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(0);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _vectorSpecification
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML.class, "_vectorSpecification", "vectorSpecification", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                return target.getVectorSpecification();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                    target.setVectorSpecification( (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setRequired(true);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _vectorSpecification
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _restartInfo
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML.class, "_restartInfo", "restartInfo", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                return target.getRestartInfo();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BlackBoxStochModelConfigXML target = (BlackBoxStochModelConfigXML) object;
                    target.setRestartInfo( (org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _restartInfo
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLDescriptor()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getAccessMode
     */
    public org.exolab.castor.mapping.AccessMode getAccessMode()
    {
        return null;
    } //-- org.exolab.castor.mapping.AccessMode getAccessMode() 

    /**
     * Method getExtends
     */
    public org.exolab.castor.mapping.ClassDescriptor getExtends()
    {
        return null;
    } //-- org.exolab.castor.mapping.ClassDescriptor getExtends() 

    /**
     * Method getIdentity
     */
    public org.exolab.castor.mapping.FieldDescriptor getIdentity()
    {
        return identity;
    } //-- org.exolab.castor.mapping.FieldDescriptor getIdentity() 

    /**
     * Method getJavaClass
     */
    public java.lang.Class getJavaClass()
    {
        return org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML.class;
    } //-- java.lang.Class getJavaClass() 

    /**
     * Method getNameSpacePrefix
     */
    public java.lang.String getNameSpacePrefix()
    {
        return nsPrefix;
    } //-- java.lang.String getNameSpacePrefix() 

    /**
     * Method getNameSpaceURI
     */
    public java.lang.String getNameSpaceURI()
    {
        return nsURI;
    } //-- java.lang.String getNameSpaceURI() 

    /**
     * Method getValidator
     */
    public org.exolab.castor.xml.TypeValidator getValidator()
    {
        return this;
    } //-- org.exolab.castor.xml.TypeValidator getValidator() 

    /**
     * Method getXMLName
     */
    public java.lang.String getXMLName()
    {
        return xmlName;
    } //-- java.lang.String getXMLName() 

}
