/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Specify either a black box model or a black box model factory
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelConfigXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify a specific black box model configuration. This can
     * be either by writing directly the model configuration or by
     * referring to a black box model configuration file.
     */
    private org.openda.core.io.castorgenerated.BlackBoxModelConfigReferenceXML _modelConfig;

    /**
     * Define a model factory. Specify class or executable,
     * arguments to supply and fail/success checks to perform
     */
    private org.openda.core.io.castorgenerated.ActionXML _modelFactory;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelConfigXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'modelConfig'. The field
     * 'modelConfig' has the following description: Specify a
     * specific black box model configuration. This can be either
     * by writing directly the model configuration or by referring
     * to a black box model configuration file.
     * 
     * @return the value of field 'modelConfig'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxModelConfigReferenceXML getModelConfig()
    {
        return this._modelConfig;
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelConfigReferenceXML getModelConfig() 

    /**
     * Returns the value of field 'modelFactory'. The field
     * 'modelFactory' has the following description: Define a model
     * factory. Specify class or executable, arguments to supply
     * and fail/success checks to perform
     * 
     * @return the value of field 'modelFactory'.
     */
    public org.openda.core.io.castorgenerated.ActionXML getModelFactory()
    {
        return this._modelFactory;
    } //-- org.openda.core.io.castorgenerated.ActionXML getModelFactory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'modelConfig'. The field
     * 'modelConfig' has the following description: Specify a
     * specific black box model configuration. This can be either
     * by writing directly the model configuration or by referring
     * to a black box model configuration file.
     * 
     * @param modelConfig the value of field 'modelConfig'.
     */
    public void setModelConfig(org.openda.core.io.castorgenerated.BlackBoxModelConfigReferenceXML modelConfig)
    {
        this._modelConfig = modelConfig;
    } //-- void setModelConfig(org.openda.core.io.castorgenerated.BlackBoxModelConfigReferenceXML) 

    /**
     * Sets the value of field 'modelFactory'. The field
     * 'modelFactory' has the following description: Define a model
     * factory. Specify class or executable, arguments to supply
     * and fail/success checks to perform
     * 
     * @param modelFactory the value of field 'modelFactory'.
     */
    public void setModelFactory(org.openda.core.io.castorgenerated.ActionXML modelFactory)
    {
        this._modelFactory = modelFactory;
    } //-- void setModelFactory(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method unmarshalBlackBoxStochModelConfigXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice unmarshalBlackBoxStochModelConfigXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice unmarshalBlackBoxStochModelConfigXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
