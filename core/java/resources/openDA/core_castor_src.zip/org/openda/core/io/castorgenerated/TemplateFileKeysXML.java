/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TemplateFileKeysXML.
 * 
 * @version $Revision$ $Date$
 */
public class TemplateFileKeysXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the id of the key defined in the keyDefinitions
     * section.
     */
    private java.util.ArrayList _keyIdList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TemplateFileKeysXML() {
        super();
        _keyIdList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.TemplateFileKeysXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addKeyId
     * 
     * @param vKeyId
     */
    public void addKeyId(java.lang.String vKeyId)
        throws java.lang.IndexOutOfBoundsException
    {
        _keyIdList.add(vKeyId);
    } //-- void addKeyId(java.lang.String) 

    /**
     * Method addKeyId
     * 
     * @param index
     * @param vKeyId
     */
    public void addKeyId(int index, java.lang.String vKeyId)
        throws java.lang.IndexOutOfBoundsException
    {
        _keyIdList.add(index, vKeyId);
    } //-- void addKeyId(int, java.lang.String) 

    /**
     * Method clearKeyId
     */
    public void clearKeyId()
    {
        _keyIdList.clear();
    } //-- void clearKeyId() 

    /**
     * Method enumerateKeyId
     */
    public java.util.Enumeration enumerateKeyId()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_keyIdList.iterator());
    } //-- java.util.Enumeration enumerateKeyId() 

    /**
     * Method getKeyId
     * 
     * @param index
     */
    public java.lang.String getKeyId(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _keyIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_keyIdList.get(index);
    } //-- java.lang.String getKeyId(int) 

    /**
     * Method getKeyId
     */
    public java.lang.String[] getKeyId()
    {
        int size = _keyIdList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_keyIdList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getKeyId() 

    /**
     * Method getKeyIdCount
     */
    public int getKeyIdCount()
    {
        return _keyIdList.size();
    } //-- int getKeyIdCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeKeyId
     * 
     * @param vKeyId
     */
    public boolean removeKeyId(java.lang.String vKeyId)
    {
        boolean removed = _keyIdList.remove(vKeyId);
        return removed;
    } //-- boolean removeKeyId(java.lang.String) 

    /**
     * Method setKeyId
     * 
     * @param index
     * @param vKeyId
     */
    public void setKeyId(int index, java.lang.String vKeyId)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _keyIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _keyIdList.set(index, vKeyId);
    } //-- void setKeyId(int, java.lang.String) 

    /**
     * Method setKeyId
     * 
     * @param keyIdArray
     */
    public void setKeyId(java.lang.String[] keyIdArray)
    {
        //-- copy array
        _keyIdList.clear();
        for (int i = 0; i < keyIdArray.length; i++) {
            _keyIdList.add(keyIdArray[i]);
        }
    } //-- void setKeyId(java.lang.String) 

    /**
     * Method unmarshalTemplateFileKeysXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TemplateFileKeysXML unmarshalTemplateFileKeysXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TemplateFileKeysXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TemplateFileKeysXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TemplateFileKeysXML unmarshalTemplateFileKeysXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
