/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class OpenDaResultWriterXML.
 * 
 * @version $Revision$ $Date$
 */
public class OpenDaResultWriterXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the openda class name of the result writer
     */
    private java.lang.String _className;

    /**
     * Specify the working directory where the results file should
     * be stored
     */
    private java.lang.String _workingDirectory;

    /**
     * Select one of the options
     */
    private org.openda.core.io.castorgenerated.OpenDaResultWriterXMLChoice _openDaResultWriterXMLChoice;

    /**
     * Specify subselection of output sources and items to be writte
     */
    private org.openda.core.io.castorgenerated.ResultSelectionXML _selection;


      //----------------/
     //- Constructors -/
    //----------------/

    public OpenDaResultWriterXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWriterXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: Specify the
     * openda class name of the result writer
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'openDaResultWriterXMLChoice'.
     * The field 'openDaResultWriterXMLChoice' has the following
     * description: Select one of the options
     * 
     * @return the value of field 'openDaResultWriterXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.OpenDaResultWriterXMLChoice getOpenDaResultWriterXMLChoice()
    {
        return this._openDaResultWriterXMLChoice;
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWriterXMLChoice getOpenDaResultWriterXMLChoice() 

    /**
     * Returns the value of field 'selection'. The field
     * 'selection' has the following description: Specify
     * subselection of output sources and items to be written
     * 
     * @return the value of field 'selection'.
     */
    public org.openda.core.io.castorgenerated.ResultSelectionXML getSelection()
    {
        return this._selection;
    } //-- org.openda.core.io.castorgenerated.ResultSelectionXML getSelection() 

    /**
     * Returns the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: Specify
     * the working directory where the results file should be
     * stored
     * 
     * @return the value of field 'workingDirectory'.
     */
    public java.lang.String getWorkingDirectory()
    {
        return this._workingDirectory;
    } //-- java.lang.String getWorkingDirectory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: Specify the openda class name
     * of the result writer
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'openDaResultWriterXMLChoice'. The
     * field 'openDaResultWriterXMLChoice' has the following
     * description: Select one of the options
     * 
     * @param openDaResultWriterXMLChoice the value of field
     * 'openDaResultWriterXMLChoice'.
     */
    public void setOpenDaResultWriterXMLChoice(org.openda.core.io.castorgenerated.OpenDaResultWriterXMLChoice openDaResultWriterXMLChoice)
    {
        this._openDaResultWriterXMLChoice = openDaResultWriterXMLChoice;
    } //-- void setOpenDaResultWriterXMLChoice(org.openda.core.io.castorgenerated.OpenDaResultWriterXMLChoice) 

    /**
     * Sets the value of field 'selection'. The field 'selection'
     * has the following description: Specify subselection of
     * output sources and items to be written
     * 
     * @param selection the value of field 'selection'.
     */
    public void setSelection(org.openda.core.io.castorgenerated.ResultSelectionXML selection)
    {
        this._selection = selection;
    } //-- void setSelection(org.openda.core.io.castorgenerated.ResultSelectionXML) 

    /**
     * Sets the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: Specify
     * the working directory where the results file should be
     * stored
     * 
     * @param workingDirectory the value of field 'workingDirectory'
     */
    public void setWorkingDirectory(java.lang.String workingDirectory)
    {
        this._workingDirectory = workingDirectory;
    } //-- void setWorkingDirectory(java.lang.String) 

    /**
     * Method unmarshalOpenDaResultWriterXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.OpenDaResultWriterXML unmarshalOpenDaResultWriterXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.OpenDaResultWriterXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.OpenDaResultWriterXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWriterXML unmarshalOpenDaResultWriterXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
