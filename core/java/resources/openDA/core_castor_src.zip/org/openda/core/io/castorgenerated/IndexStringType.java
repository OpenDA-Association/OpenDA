/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * index (e.g. 12) or index line (e.g. 11:18) in an array
 * 
 * @version $Revision$ $Date$
 */
public class IndexStringType implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public IndexStringType() {
        super();
    } //-- org.openda.core.io.castorgenerated.IndexStringType()

}
