/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class TreeVectorXMLChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
public class TreeVectorXMLChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _treeVectorLeaf
     */
    private org.openda.core.io.castorgenerated.TreeVectorLeafXML _treeVectorLeaf;

    /**
     * Field _subTreeVector
     */
    private org.openda.core.io.castorgenerated.TreeVectorXML _subTreeVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public TreeVectorXMLChoiceItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.TreeVectorXMLChoiceItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'subTreeVector'.
     * 
     * @return the value of field 'subTreeVector'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXML getSubTreeVector()
    {
        return this._subTreeVector;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML getSubTreeVector() 

    /**
     * Returns the value of field 'treeVectorLeaf'.
     * 
     * @return the value of field 'treeVectorLeaf'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorLeafXML getTreeVectorLeaf()
    {
        return this._treeVectorLeaf;
    } //-- org.openda.core.io.castorgenerated.TreeVectorLeafXML getTreeVectorLeaf() 

    /**
     * Sets the value of field 'subTreeVector'.
     * 
     * @param subTreeVector the value of field 'subTreeVector'.
     */
    public void setSubTreeVector(org.openda.core.io.castorgenerated.TreeVectorXML subTreeVector)
    {
        this._subTreeVector = subTreeVector;
    } //-- void setSubTreeVector(org.openda.core.io.castorgenerated.TreeVectorXML) 

    /**
     * Sets the value of field 'treeVectorLeaf'.
     * 
     * @param treeVectorLeaf the value of field 'treeVectorLeaf'.
     */
    public void setTreeVectorLeaf(org.openda.core.io.castorgenerated.TreeVectorLeafXML treeVectorLeaf)
    {
        this._treeVectorLeaf = treeVectorLeaf;
    } //-- void setTreeVectorLeaf(org.openda.core.io.castorgenerated.TreeVectorLeafXML) 

}
