/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ExchangeItemXML.
 * 
 * @version $Revision$ $Date$
 */
public class ExchangeItemXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public ExchangeItemXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.ExchangeItemXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addExchangeItemXMLItem
     * 
     * @param vExchangeItemXMLItem
     */
    public void addExchangeItemXMLItem(org.openda.core.io.castorgenerated.ExchangeItemXMLItem vExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vExchangeItemXMLItem);
    } //-- void addExchangeItemXMLItem(org.openda.core.io.castorgenerated.ExchangeItemXMLItem) 

    /**
     * Method addExchangeItemXMLItem
     * 
     * @param index
     * @param vExchangeItemXMLItem
     */
    public void addExchangeItemXMLItem(int index, org.openda.core.io.castorgenerated.ExchangeItemXMLItem vExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vExchangeItemXMLItem);
    } //-- void addExchangeItemXMLItem(int, org.openda.core.io.castorgenerated.ExchangeItemXMLItem) 

    /**
     * Method clearExchangeItemXMLItem
     */
    public void clearExchangeItemXMLItem()
    {
        _items.clear();
    } //-- void clearExchangeItemXMLItem() 

    /**
     * Method enumerateExchangeItemXMLItem
     */
    public java.util.Enumeration enumerateExchangeItemXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateExchangeItemXMLItem() 

    /**
     * Method getExchangeItemXMLItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.ExchangeItemXMLItem getExchangeItemXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.ExchangeItemXMLItem) _items.get(index);
    } //-- org.openda.core.io.castorgenerated.ExchangeItemXMLItem getExchangeItemXMLItem(int) 

    /**
     * Method getExchangeItemXMLItem
     */
    public org.openda.core.io.castorgenerated.ExchangeItemXMLItem[] getExchangeItemXMLItem()
    {
        int size = _items.size();
        org.openda.core.io.castorgenerated.ExchangeItemXMLItem[] mArray = new org.openda.core.io.castorgenerated.ExchangeItemXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.ExchangeItemXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.ExchangeItemXMLItem[] getExchangeItemXMLItem() 

    /**
     * Method getExchangeItemXMLItemCount
     */
    public int getExchangeItemXMLItemCount()
    {
        return _items.size();
    } //-- int getExchangeItemXMLItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeExchangeItemXMLItem
     * 
     * @param vExchangeItemXMLItem
     */
    public boolean removeExchangeItemXMLItem(org.openda.core.io.castorgenerated.ExchangeItemXMLItem vExchangeItemXMLItem)
    {
        boolean removed = _items.remove(vExchangeItemXMLItem);
        return removed;
    } //-- boolean removeExchangeItemXMLItem(org.openda.core.io.castorgenerated.ExchangeItemXMLItem) 

    /**
     * Method setExchangeItemXMLItem
     * 
     * @param index
     * @param vExchangeItemXMLItem
     */
    public void setExchangeItemXMLItem(int index, org.openda.core.io.castorgenerated.ExchangeItemXMLItem vExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vExchangeItemXMLItem);
    } //-- void setExchangeItemXMLItem(int, org.openda.core.io.castorgenerated.ExchangeItemXMLItem) 

    /**
     * Method setExchangeItemXMLItem
     * 
     * @param exchangeItemXMLItemArray
     */
    public void setExchangeItemXMLItem(org.openda.core.io.castorgenerated.ExchangeItemXMLItem[] exchangeItemXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < exchangeItemXMLItemArray.length; i++) {
            _items.add(exchangeItemXMLItemArray[i]);
        }
    } //-- void setExchangeItemXMLItem(org.openda.core.io.castorgenerated.ExchangeItemXMLItem) 

    /**
     * Method unmarshalExchangeItemXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ExchangeItemXML unmarshalExchangeItemXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ExchangeItemXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ExchangeItemXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ExchangeItemXML unmarshalExchangeItemXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
