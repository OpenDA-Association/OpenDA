/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class DateXML.
 * 
 * @version $Revision$ $Date$
 */
public class DateXML implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public DateXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.DateXML()

}
