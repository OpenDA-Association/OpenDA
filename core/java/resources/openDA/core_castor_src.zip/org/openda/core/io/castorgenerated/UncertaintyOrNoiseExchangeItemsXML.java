/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class UncertaintyOrNoiseExchangeItemsXML.
 * 
 * @version $Revision$ $Date$
 */
public class UncertaintyOrNoiseExchangeItemsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The list of relations
     */
    private java.util.ArrayList _exchangeItemList;


      //----------------/
     //- Constructors -/
    //----------------/

    public UncertaintyOrNoiseExchangeItemsXML() {
        super();
        _exchangeItemList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addExchangeItem
     * 
     * @param vExchangeItem
     */
    public void addExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _exchangeItemList.add(vExchangeItem);
    } //-- void addExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) 

    /**
     * Method addExchangeItem
     * 
     * @param index
     * @param vExchangeItem
     */
    public void addExchangeItem(int index, org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _exchangeItemList.add(index, vExchangeItem);
    } //-- void addExchangeItem(int, org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) 

    /**
     * Method clearExchangeItem
     */
    public void clearExchangeItem()
    {
        _exchangeItemList.clear();
    } //-- void clearExchangeItem() 

    /**
     * Method enumerateExchangeItem
     */
    public java.util.Enumeration enumerateExchangeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_exchangeItemList.iterator());
    } //-- java.util.Enumeration enumerateExchangeItem() 

    /**
     * Method getExchangeItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML getExchangeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _exchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) _exchangeItemList.get(index);
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML getExchangeItem(int) 

    /**
     * Method getExchangeItem
     */
    public org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML[] getExchangeItem()
    {
        int size = _exchangeItemList.size();
        org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML[] mArray = new org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) _exchangeItemList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML[] getExchangeItem() 

    /**
     * Method getExchangeItemCount
     */
    public int getExchangeItemCount()
    {
        return _exchangeItemList.size();
    } //-- int getExchangeItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeExchangeItem
     * 
     * @param vExchangeItem
     */
    public boolean removeExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML vExchangeItem)
    {
        boolean removed = _exchangeItemList.remove(vExchangeItem);
        return removed;
    } //-- boolean removeExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) 

    /**
     * Method setExchangeItem
     * 
     * @param index
     * @param vExchangeItem
     */
    public void setExchangeItem(int index, org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _exchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _exchangeItemList.set(index, vExchangeItem);
    } //-- void setExchangeItem(int, org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) 

    /**
     * Method setExchangeItem
     * 
     * @param exchangeItemArray
     */
    public void setExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML[] exchangeItemArray)
    {
        //-- copy array
        _exchangeItemList.clear();
        for (int i = 0; i < exchangeItemArray.length; i++) {
            _exchangeItemList.add(exchangeItemArray[i]);
        }
    } //-- void setExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) 

    /**
     * Method unmarshalUncertaintyOrNoiseExchangeItemsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML unmarshalUncertaintyOrNoiseExchangeItemsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML unmarshalUncertaintyOrNoiseExchangeItemsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
