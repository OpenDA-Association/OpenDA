/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Tranformation of correction factor. Two values are possible:
 * 'identity' and 'ln'. The 'identity' means that the correction
 * will be added directly without any transformation to the
 * adjusted parameter. On the other hand, 'ln' means that
 * correction is transformed logarithmically before it is added to
 * the parameter; this gives a correction, which is a fraction of
 * the parameter value. 
 * 
 * @version $Revision$ $Date$
 */
public class ParameterTransformationTypesXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The identity type
     */
    public static final int IDENTITY_TYPE = 0;

    /**
     * The instance of the identity type
     */
    public static final ParameterTransformationTypesXML IDENTITY = new ParameterTransformationTypesXML(IDENTITY_TYPE, "identity");

    /**
     * The ln type
     */
    public static final int LN_TYPE = 1;

    /**
     * The instance of the ln type
     */
    public static final ParameterTransformationTypesXML LN = new ParameterTransformationTypesXML(LN_TYPE, "ln");

    /**
     * The set type
     */
    public static final int SET_TYPE = 2;

    /**
     * The instance of the set type
     */
    public static final ParameterTransformationTypesXML SET = new ParameterTransformationTypesXML(SET_TYPE, "set");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private ParameterTransformationTypesXML(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of ParameterTransformationTypesXML
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this
     * ParameterTransformationTypesXML
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("identity", IDENTITY);
        members.put("ln", LN);
        members.put("set", SET);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * ParameterTransformationTypesXML
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new ParameterTransformationTypesXML
     * based on the given String value.
     * 
     * @param string
     */
    public static org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid ParameterTransformationTypesXML";
            throw new IllegalArgumentException(err);
        }
        return (ParameterTransformationTypesXML) obj;
    } //-- org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML valueOf(java.lang.String) 

}
