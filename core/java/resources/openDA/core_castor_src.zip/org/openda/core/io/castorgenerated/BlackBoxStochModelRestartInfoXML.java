/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelRestartInfoXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelRestartInfoXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the model directory that will contain a set of
     * restart files for a certain time stamp
     *  (written when the algorithm requests to store states, read
     * when the algorithm asks to restore a state)
     */
    private java.lang.String _dirPrefix = "./savedStochModelState_";

    /**
     * Specify the file name prefix for storing the state of the
     * noise model(s)
     */
    private java.lang.String _noiseModelPrefix = "./noiseModel_";

    /**
     * Specify the file name prefix for storing the model state
     * (must end with .zip)
     */
    private java.lang.String _modelStateFile = "./modelState.zip";


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelRestartInfoXML() {
        super();
        setDirPrefix("./savedStochModelState_");
        setNoiseModelPrefix("./noiseModel_");
        setModelStateFile("./modelState.zip");
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dirPrefix'. The field
     * 'dirPrefix' has the following description: Specify the model
     * directory that will contain a set of restart files for a
     * certain time stamp
     *  (written when the algorithm requests to store states, read
     * when the algorithm asks to restore a state)
     * 
     * @return the value of field 'dirPrefix'.
     */
    public java.lang.String getDirPrefix()
    {
        return this._dirPrefix;
    } //-- java.lang.String getDirPrefix() 

    /**
     * Returns the value of field 'modelStateFile'. The field
     * 'modelStateFile' has the following description: Specify the
     * file name prefix for storing the model state (must end with
     * .zip)
     * 
     * @return the value of field 'modelStateFile'.
     */
    public java.lang.String getModelStateFile()
    {
        return this._modelStateFile;
    } //-- java.lang.String getModelStateFile() 

    /**
     * Returns the value of field 'noiseModelPrefix'. The field
     * 'noiseModelPrefix' has the following description: Specify
     * the file name prefix for storing the state of the noise
     * model(s)
     * 
     * @return the value of field 'noiseModelPrefix'.
     */
    public java.lang.String getNoiseModelPrefix()
    {
        return this._noiseModelPrefix;
    } //-- java.lang.String getNoiseModelPrefix() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dirPrefix'. The field 'dirPrefix'
     * has the following description: Specify the model directory
     * that will contain a set of restart files for a certain time
     * stamp
     *  (written when the algorithm requests to store states, read
     * when the algorithm asks to restore a state)
     * 
     * @param dirPrefix the value of field 'dirPrefix'.
     */
    public void setDirPrefix(java.lang.String dirPrefix)
    {
        this._dirPrefix = dirPrefix;
    } //-- void setDirPrefix(java.lang.String) 

    /**
     * Sets the value of field 'modelStateFile'. The field
     * 'modelStateFile' has the following description: Specify the
     * file name prefix for storing the model state (must end with
     * .zip)
     * 
     * @param modelStateFile the value of field 'modelStateFile'.
     */
    public void setModelStateFile(java.lang.String modelStateFile)
    {
        this._modelStateFile = modelStateFile;
    } //-- void setModelStateFile(java.lang.String) 

    /**
     * Sets the value of field 'noiseModelPrefix'. The field
     * 'noiseModelPrefix' has the following description: Specify
     * the file name prefix for storing the state of the noise
     * model(s)
     * 
     * @param noiseModelPrefix the value of field 'noiseModelPrefix'
     */
    public void setNoiseModelPrefix(java.lang.String noiseModelPrefix)
    {
        this._noiseModelPrefix = noiseModelPrefix;
    } //-- void setNoiseModelPrefix(java.lang.String) 

    /**
     * Method unmarshalBlackBoxStochModelRestartInfoXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML unmarshalBlackBoxStochModelRestartInfoXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML unmarshalBlackBoxStochModelRestartInfoXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
