/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxWrapperConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxWrapperConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Define aliases for specific model information (directory
     * names, file names etc.). Specify the prefix and suffix for
     * the alias keys.
     */
    private org.openda.core.io.castorgenerated.AliasDefinitionsXML _aliasDefinitions;

    /**
     * Specify the initialize, compute and finalize actions that
     * direct the model
     */
    private org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML _run;

    /**
     * Specify the list of input/output objects
     */
    private org.openda.core.io.castorgenerated.InputOutputXML _inputOutput;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxWrapperConfigXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'aliasDefinitions'. The field
     * 'aliasDefinitions' has the following description: Define
     * aliases for specific model information (directory names,
     * file names etc.). Specify the prefix and suffix for the
     * alias keys.
     * 
     * @return the value of field 'aliasDefinitions'.
     */
    public org.openda.core.io.castorgenerated.AliasDefinitionsXML getAliasDefinitions()
    {
        return this._aliasDefinitions;
    } //-- org.openda.core.io.castorgenerated.AliasDefinitionsXML getAliasDefinitions() 

    /**
     * Returns the value of field 'inputOutput'. The field
     * 'inputOutput' has the following description: Specify the
     * list of input/output objects
     * 
     * @return the value of field 'inputOutput'.
     */
    public org.openda.core.io.castorgenerated.InputOutputXML getInputOutput()
    {
        return this._inputOutput;
    } //-- org.openda.core.io.castorgenerated.InputOutputXML getInputOutput() 

    /**
     * Returns the value of field 'run'. The field 'run' has the
     * following description: Specify the initialize, compute and
     * finalize actions that direct the model
     * 
     * @return the value of field 'run'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML getRun()
    {
        return this._run;
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML getRun() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'aliasDefinitions'. The field
     * 'aliasDefinitions' has the following description: Define
     * aliases for specific model information (directory names,
     * file names etc.). Specify the prefix and suffix for the
     * alias keys.
     * 
     * @param aliasDefinitions the value of field 'aliasDefinitions'
     */
    public void setAliasDefinitions(org.openda.core.io.castorgenerated.AliasDefinitionsXML aliasDefinitions)
    {
        this._aliasDefinitions = aliasDefinitions;
    } //-- void setAliasDefinitions(org.openda.core.io.castorgenerated.AliasDefinitionsXML) 

    /**
     * Sets the value of field 'inputOutput'. The field
     * 'inputOutput' has the following description: Specify the
     * list of input/output objects
     * 
     * @param inputOutput the value of field 'inputOutput'.
     */
    public void setInputOutput(org.openda.core.io.castorgenerated.InputOutputXML inputOutput)
    {
        this._inputOutput = inputOutput;
    } //-- void setInputOutput(org.openda.core.io.castorgenerated.InputOutputXML) 

    /**
     * Sets the value of field 'run'. The field 'run' has the
     * following description: Specify the initialize, compute and
     * finalize actions that direct the model
     * 
     * @param run the value of field 'run'.
     */
    public void setRun(org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML run)
    {
        this._run = run;
    } //-- void setRun(org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML) 

    /**
     * Method unmarshalBlackBoxWrapperConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxWrapperConfigXML unmarshalBlackBoxWrapperConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxWrapperConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxWrapperConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperConfigXML unmarshalBlackBoxWrapperConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
