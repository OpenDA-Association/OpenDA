/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxTemplateConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxTemplateConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Define keys which need to be substituted by valiues in the
     * template files. Specify the prefix and suffix for the keys.
     */
    private org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML _keyDefinitions;

    /**
     * Specify the files with template definitions.
     */
    private org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML _files;

    /**
     * Specify the file containing the KEY and VALUE pairs.
     */
    private java.lang.String _valuesFile;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxTemplateConfigXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxTemplateConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'files'. The field 'files' has
     * the following description: Specify the files with template
     * definitions.
     * 
     * @return the value of field 'files'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML getFiles()
    {
        return this._files;
    } //-- org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML getFiles() 

    /**
     * Returns the value of field 'keyDefinitions'. The field
     * 'keyDefinitions' has the following description: Define keys
     * which need to be substituted by valiues in the template
     * files. Specify the prefix and suffix for the keys.
     * 
     * @return the value of field 'keyDefinitions'.
     */
    public org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML getKeyDefinitions()
    {
        return this._keyDefinitions;
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML getKeyDefinitions() 

    /**
     * Returns the value of field 'valuesFile'. The field
     * 'valuesFile' has the following description: Specify the file
     * containing the KEY and VALUE pairs.
     * 
     * @return the value of field 'valuesFile'.
     */
    public java.lang.String getValuesFile()
    {
        return this._valuesFile;
    } //-- java.lang.String getValuesFile() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'files'. The field 'files' has the
     * following description: Specify the files with template
     * definitions.
     * 
     * @param files the value of field 'files'.
     */
    public void setFiles(org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML files)
    {
        this._files = files;
    } //-- void setFiles(org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML) 

    /**
     * Sets the value of field 'keyDefinitions'. The field
     * 'keyDefinitions' has the following description: Define keys
     * which need to be substituted by valiues in the template
     * files. Specify the prefix and suffix for the keys.
     * 
     * @param keyDefinitions the value of field 'keyDefinitions'.
     */
    public void setKeyDefinitions(org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML keyDefinitions)
    {
        this._keyDefinitions = keyDefinitions;
    } //-- void setKeyDefinitions(org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML) 

    /**
     * Sets the value of field 'valuesFile'. The field 'valuesFile'
     * has the following description: Specify the file containing
     * the KEY and VALUE pairs.
     * 
     * @param valuesFile the value of field 'valuesFile'.
     */
    public void setValuesFile(java.lang.String valuesFile)
    {
        this._valuesFile = valuesFile;
    } //-- void setValuesFile(java.lang.String) 

    /**
     * Method unmarshalBlackBoxTemplateConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxTemplateConfigXML unmarshalBlackBoxTemplateConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxTemplateConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxTemplateConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxTemplateConfigXML unmarshalBlackBoxTemplateConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
