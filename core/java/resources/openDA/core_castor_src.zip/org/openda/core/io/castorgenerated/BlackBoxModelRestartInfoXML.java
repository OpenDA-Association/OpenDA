/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxModelRestartInfoXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxModelRestartInfoXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the prefix of model directory name that will contain
     * a set of restart files for a certain time stamp
     *  (written when the stoch model level requests to store
     * states, read when the algorithm asks to restore a state)
     */
    private java.lang.String _dirPrefix = "./savedModelState_";

    /**
     * Specify the file name(s) containing the model state
     */
    private java.util.ArrayList _modelStateFileList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxModelRestartInfoXML() {
        super();
        setDirPrefix("./savedModelState_");
        _modelStateFileList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addModelStateFile
     * 
     * @param vModelStateFile
     */
    public void addModelStateFile(java.lang.String vModelStateFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _modelStateFileList.add(vModelStateFile);
    } //-- void addModelStateFile(java.lang.String) 

    /**
     * Method addModelStateFile
     * 
     * @param index
     * @param vModelStateFile
     */
    public void addModelStateFile(int index, java.lang.String vModelStateFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _modelStateFileList.add(index, vModelStateFile);
    } //-- void addModelStateFile(int, java.lang.String) 

    /**
     * Method clearModelStateFile
     */
    public void clearModelStateFile()
    {
        _modelStateFileList.clear();
    } //-- void clearModelStateFile() 

    /**
     * Method enumerateModelStateFile
     */
    public java.util.Enumeration enumerateModelStateFile()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_modelStateFileList.iterator());
    } //-- java.util.Enumeration enumerateModelStateFile() 

    /**
     * Returns the value of field 'dirPrefix'. The field
     * 'dirPrefix' has the following description: Specify the
     * prefix of model directory name that will contain a set of
     * restart files for a certain time stamp
     *  (written when the stoch model level requests to store
     * states, read when the algorithm asks to restore a state)
     * 
     * @return the value of field 'dirPrefix'.
     */
    public java.lang.String getDirPrefix()
    {
        return this._dirPrefix;
    } //-- java.lang.String getDirPrefix() 

    /**
     * Method getModelStateFile
     * 
     * @param index
     */
    public java.lang.String getModelStateFile(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _modelStateFileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_modelStateFileList.get(index);
    } //-- java.lang.String getModelStateFile(int) 

    /**
     * Method getModelStateFile
     */
    public java.lang.String[] getModelStateFile()
    {
        int size = _modelStateFileList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_modelStateFileList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getModelStateFile() 

    /**
     * Method getModelStateFileCount
     */
    public int getModelStateFileCount()
    {
        return _modelStateFileList.size();
    } //-- int getModelStateFileCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeModelStateFile
     * 
     * @param vModelStateFile
     */
    public boolean removeModelStateFile(java.lang.String vModelStateFile)
    {
        boolean removed = _modelStateFileList.remove(vModelStateFile);
        return removed;
    } //-- boolean removeModelStateFile(java.lang.String) 

    /**
     * Sets the value of field 'dirPrefix'. The field 'dirPrefix'
     * has the following description: Specify the prefix of model
     * directory name that will contain a set of restart files for
     * a certain time stamp
     *  (written when the stoch model level requests to store
     * states, read when the algorithm asks to restore a state)
     * 
     * @param dirPrefix the value of field 'dirPrefix'.
     */
    public void setDirPrefix(java.lang.String dirPrefix)
    {
        this._dirPrefix = dirPrefix;
    } //-- void setDirPrefix(java.lang.String) 

    /**
     * Method setModelStateFile
     * 
     * @param index
     * @param vModelStateFile
     */
    public void setModelStateFile(int index, java.lang.String vModelStateFile)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _modelStateFileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _modelStateFileList.set(index, vModelStateFile);
    } //-- void setModelStateFile(int, java.lang.String) 

    /**
     * Method setModelStateFile
     * 
     * @param modelStateFileArray
     */
    public void setModelStateFile(java.lang.String[] modelStateFileArray)
    {
        //-- copy array
        _modelStateFileList.clear();
        for (int i = 0; i < modelStateFileArray.length; i++) {
            _modelStateFileList.add(modelStateFileArray[i]);
        }
    } //-- void setModelStateFile(java.lang.String) 

    /**
     * Method unmarshalBlackBoxModelRestartInfoXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML unmarshalBlackBoxModelRestartInfoXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML unmarshalBlackBoxModelRestartInfoXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
