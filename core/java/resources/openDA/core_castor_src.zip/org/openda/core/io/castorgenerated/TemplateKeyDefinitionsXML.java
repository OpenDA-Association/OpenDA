/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TemplateKeyDefinitionsXML.
 * 
 * @version $Revision$ $Date$
 */
public class TemplateKeyDefinitionsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the default prefix for the alias keys.
     */
    private java.lang.String _defaultKeyPrefix;

    /**
     * Specify the default suffix for the alias keys.
     */
    private java.lang.String _defaultKeySuffix;

    /**
     * Create list of keys, stating their id, name and targetType.
     * The id is to be used in the file definition section. The
     * name is the "KEY" - string to be placed in the template file.
     */
    private java.util.ArrayList _keyList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TemplateKeyDefinitionsXML() {
        super();
        _keyList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addKey
     * 
     * @param vKey
     */
    public void addKey(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML vKey)
        throws java.lang.IndexOutOfBoundsException
    {
        _keyList.add(vKey);
    } //-- void addKey(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) 

    /**
     * Method addKey
     * 
     * @param index
     * @param vKey
     */
    public void addKey(int index, org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML vKey)
        throws java.lang.IndexOutOfBoundsException
    {
        _keyList.add(index, vKey);
    } //-- void addKey(int, org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) 

    /**
     * Method clearKey
     */
    public void clearKey()
    {
        _keyList.clear();
    } //-- void clearKey() 

    /**
     * Method enumerateKey
     */
    public java.util.Enumeration enumerateKey()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_keyList.iterator());
    } //-- java.util.Enumeration enumerateKey() 

    /**
     * Returns the value of field 'defaultKeyPrefix'. The field
     * 'defaultKeyPrefix' has the following description: Specify
     * the default prefix for the alias keys.
     * 
     * @return the value of field 'defaultKeyPrefix'.
     */
    public java.lang.String getDefaultKeyPrefix()
    {
        return this._defaultKeyPrefix;
    } //-- java.lang.String getDefaultKeyPrefix() 

    /**
     * Returns the value of field 'defaultKeySuffix'. The field
     * 'defaultKeySuffix' has the following description: Specify
     * the default suffix for the alias keys.
     * 
     * @return the value of field 'defaultKeySuffix'.
     */
    public java.lang.String getDefaultKeySuffix()
    {
        return this._defaultKeySuffix;
    } //-- java.lang.String getDefaultKeySuffix() 

    /**
     * Method getKey
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML getKey(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _keyList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) _keyList.get(index);
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML getKey(int) 

    /**
     * Method getKey
     */
    public org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML[] getKey()
    {
        int size = _keyList.size();
        org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML[] mArray = new org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) _keyList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML[] getKey() 

    /**
     * Method getKeyCount
     */
    public int getKeyCount()
    {
        return _keyList.size();
    } //-- int getKeyCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeKey
     * 
     * @param vKey
     */
    public boolean removeKey(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML vKey)
    {
        boolean removed = _keyList.remove(vKey);
        return removed;
    } //-- boolean removeKey(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) 

    /**
     * Sets the value of field 'defaultKeyPrefix'. The field
     * 'defaultKeyPrefix' has the following description: Specify
     * the default prefix for the alias keys.
     * 
     * @param defaultKeyPrefix the value of field 'defaultKeyPrefix'
     */
    public void setDefaultKeyPrefix(java.lang.String defaultKeyPrefix)
    {
        this._defaultKeyPrefix = defaultKeyPrefix;
    } //-- void setDefaultKeyPrefix(java.lang.String) 

    /**
     * Sets the value of field 'defaultKeySuffix'. The field
     * 'defaultKeySuffix' has the following description: Specify
     * the default suffix for the alias keys.
     * 
     * @param defaultKeySuffix the value of field 'defaultKeySuffix'
     */
    public void setDefaultKeySuffix(java.lang.String defaultKeySuffix)
    {
        this._defaultKeySuffix = defaultKeySuffix;
    } //-- void setDefaultKeySuffix(java.lang.String) 

    /**
     * Method setKey
     * 
     * @param index
     * @param vKey
     */
    public void setKey(int index, org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML vKey)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _keyList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _keyList.set(index, vKey);
    } //-- void setKey(int, org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) 

    /**
     * Method setKey
     * 
     * @param keyArray
     */
    public void setKey(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML[] keyArray)
    {
        //-- copy array
        _keyList.clear();
        for (int i = 0; i < keyArray.length; i++) {
            _keyList.add(keyArray[i]);
        }
    } //-- void setKey(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) 

    /**
     * Method unmarshalTemplateKeyDefinitionsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML unmarshalTemplateKeyDefinitionsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionsXML unmarshalTemplateKeyDefinitionsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
