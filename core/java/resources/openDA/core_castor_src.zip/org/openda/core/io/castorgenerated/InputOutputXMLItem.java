/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class InputOutputXMLItem.
 * 
 * @version $Revision$ $Date$
 */
public class InputOutputXMLItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * element ioObject is obsolete, please use dataObject
     */
    private org.openda.core.io.castorgenerated.DataObjectXML _ioObject;

    /**
     * Specify the input/output data object
     */
    private org.openda.core.io.castorgenerated.DataObjectXML _dataObject;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputOutputXMLItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.InputOutputXMLItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dataObject'. The field
     * 'dataObject' has the following description: Specify the
     * input/output data object
     * 
     * @return the value of field 'dataObject'.
     */
    public org.openda.core.io.castorgenerated.DataObjectXML getDataObject()
    {
        return this._dataObject;
    } //-- org.openda.core.io.castorgenerated.DataObjectXML getDataObject() 

    /**
     * Returns the value of field 'ioObject'. The field 'ioObject'
     * has the following description: element ioObject is obsolete,
     * please use dataObject
     * 
     * @return the value of field 'ioObject'.
     */
    public org.openda.core.io.castorgenerated.DataObjectXML getIoObject()
    {
        return this._ioObject;
    } //-- org.openda.core.io.castorgenerated.DataObjectXML getIoObject() 

    /**
     * Sets the value of field 'dataObject'. The field 'dataObject'
     * has the following description: Specify the input/output data
     * object
     * 
     * @param dataObject the value of field 'dataObject'.
     */
    public void setDataObject(org.openda.core.io.castorgenerated.DataObjectXML dataObject)
    {
        this._dataObject = dataObject;
    } //-- void setDataObject(org.openda.core.io.castorgenerated.DataObjectXML) 

    /**
     * Sets the value of field 'ioObject'. The field 'ioObject' has
     * the following description: element ioObject is obsolete,
     * please use dataObject
     * 
     * @param ioObject the value of field 'ioObject'.
     */
    public void setIoObject(org.openda.core.io.castorgenerated.DataObjectXML ioObject)
    {
        this._ioObject = ioObject;
    } //-- void setIoObject(org.openda.core.io.castorgenerated.DataObjectXML) 

}
