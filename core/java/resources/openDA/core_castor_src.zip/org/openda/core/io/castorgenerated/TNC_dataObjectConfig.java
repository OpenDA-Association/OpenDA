/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TNC_dataObjectConfig.
 * 
 * @version $Revision$ $Date$
 */
public class TNC_dataObjectConfig implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _arrayExchangeItemList
     */
    private java.util.ArrayList _arrayExchangeItemList;

    /**
     * Field _timeSeriesExchangeItemList
     */
    private java.util.ArrayList _timeSeriesExchangeItemList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TNC_dataObjectConfig() {
        super();
        _arrayExchangeItemList = new ArrayList();
        _timeSeriesExchangeItemList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.TNC_dataObjectConfig()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addArrayExchangeItem
     * 
     * @param vArrayExchangeItem
     */
    public void addArrayExchangeItem(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem vArrayExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _arrayExchangeItemList.add(vArrayExchangeItem);
    } //-- void addArrayExchangeItem(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) 

    /**
     * Method addArrayExchangeItem
     * 
     * @param index
     * @param vArrayExchangeItem
     */
    public void addArrayExchangeItem(int index, org.openda.core.io.castorgenerated.TNC_arrayExchangeItem vArrayExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _arrayExchangeItemList.add(index, vArrayExchangeItem);
    } //-- void addArrayExchangeItem(int, org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) 

    /**
     * Method addTimeSeriesExchangeItem
     * 
     * @param vTimeSeriesExchangeItem
     */
    public void addTimeSeriesExchangeItem(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem vTimeSeriesExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _timeSeriesExchangeItemList.add(vTimeSeriesExchangeItem);
    } //-- void addTimeSeriesExchangeItem(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) 

    /**
     * Method addTimeSeriesExchangeItem
     * 
     * @param index
     * @param vTimeSeriesExchangeItem
     */
    public void addTimeSeriesExchangeItem(int index, org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem vTimeSeriesExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _timeSeriesExchangeItemList.add(index, vTimeSeriesExchangeItem);
    } //-- void addTimeSeriesExchangeItem(int, org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) 

    /**
     * Method clearArrayExchangeItem
     */
    public void clearArrayExchangeItem()
    {
        _arrayExchangeItemList.clear();
    } //-- void clearArrayExchangeItem() 

    /**
     * Method clearTimeSeriesExchangeItem
     */
    public void clearTimeSeriesExchangeItem()
    {
        _timeSeriesExchangeItemList.clear();
    } //-- void clearTimeSeriesExchangeItem() 

    /**
     * Method enumerateArrayExchangeItem
     */
    public java.util.Enumeration enumerateArrayExchangeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_arrayExchangeItemList.iterator());
    } //-- java.util.Enumeration enumerateArrayExchangeItem() 

    /**
     * Method enumerateTimeSeriesExchangeItem
     */
    public java.util.Enumeration enumerateTimeSeriesExchangeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_timeSeriesExchangeItemList.iterator());
    } //-- java.util.Enumeration enumerateTimeSeriesExchangeItem() 

    /**
     * Method getArrayExchangeItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TNC_arrayExchangeItem getArrayExchangeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _arrayExchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) _arrayExchangeItemList.get(index);
    } //-- org.openda.core.io.castorgenerated.TNC_arrayExchangeItem getArrayExchangeItem(int) 

    /**
     * Method getArrayExchangeItem
     */
    public org.openda.core.io.castorgenerated.TNC_arrayExchangeItem[] getArrayExchangeItem()
    {
        int size = _arrayExchangeItemList.size();
        org.openda.core.io.castorgenerated.TNC_arrayExchangeItem[] mArray = new org.openda.core.io.castorgenerated.TNC_arrayExchangeItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) _arrayExchangeItemList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TNC_arrayExchangeItem[] getArrayExchangeItem() 

    /**
     * Method getArrayExchangeItemCount
     */
    public int getArrayExchangeItemCount()
    {
        return _arrayExchangeItemList.size();
    } //-- int getArrayExchangeItemCount() 

    /**
     * Method getTimeSeriesExchangeItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem getTimeSeriesExchangeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _timeSeriesExchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) _timeSeriesExchangeItemList.get(index);
    } //-- org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem getTimeSeriesExchangeItem(int) 

    /**
     * Method getTimeSeriesExchangeItem
     */
    public org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem[] getTimeSeriesExchangeItem()
    {
        int size = _timeSeriesExchangeItemList.size();
        org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem[] mArray = new org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) _timeSeriesExchangeItemList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem[] getTimeSeriesExchangeItem() 

    /**
     * Method getTimeSeriesExchangeItemCount
     */
    public int getTimeSeriesExchangeItemCount()
    {
        return _timeSeriesExchangeItemList.size();
    } //-- int getTimeSeriesExchangeItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeArrayExchangeItem
     * 
     * @param vArrayExchangeItem
     */
    public boolean removeArrayExchangeItem(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem vArrayExchangeItem)
    {
        boolean removed = _arrayExchangeItemList.remove(vArrayExchangeItem);
        return removed;
    } //-- boolean removeArrayExchangeItem(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) 

    /**
     * Method removeTimeSeriesExchangeItem
     * 
     * @param vTimeSeriesExchangeItem
     */
    public boolean removeTimeSeriesExchangeItem(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem vTimeSeriesExchangeItem)
    {
        boolean removed = _timeSeriesExchangeItemList.remove(vTimeSeriesExchangeItem);
        return removed;
    } //-- boolean removeTimeSeriesExchangeItem(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) 

    /**
     * Method setArrayExchangeItem
     * 
     * @param index
     * @param vArrayExchangeItem
     */
    public void setArrayExchangeItem(int index, org.openda.core.io.castorgenerated.TNC_arrayExchangeItem vArrayExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _arrayExchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _arrayExchangeItemList.set(index, vArrayExchangeItem);
    } //-- void setArrayExchangeItem(int, org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) 

    /**
     * Method setArrayExchangeItem
     * 
     * @param arrayExchangeItemArray
     */
    public void setArrayExchangeItem(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem[] arrayExchangeItemArray)
    {
        //-- copy array
        _arrayExchangeItemList.clear();
        for (int i = 0; i < arrayExchangeItemArray.length; i++) {
            _arrayExchangeItemList.add(arrayExchangeItemArray[i]);
        }
    } //-- void setArrayExchangeItem(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) 

    /**
     * Method setTimeSeriesExchangeItem
     * 
     * @param index
     * @param vTimeSeriesExchangeItem
     */
    public void setTimeSeriesExchangeItem(int index, org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem vTimeSeriesExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _timeSeriesExchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _timeSeriesExchangeItemList.set(index, vTimeSeriesExchangeItem);
    } //-- void setTimeSeriesExchangeItem(int, org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) 

    /**
     * Method setTimeSeriesExchangeItem
     * 
     * @param timeSeriesExchangeItemArray
     */
    public void setTimeSeriesExchangeItem(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem[] timeSeriesExchangeItemArray)
    {
        //-- copy array
        _timeSeriesExchangeItemList.clear();
        for (int i = 0; i < timeSeriesExchangeItemArray.length; i++) {
            _timeSeriesExchangeItemList.add(timeSeriesExchangeItemArray[i]);
        }
    } //-- void setTimeSeriesExchangeItem(org.openda.core.io.castorgenerated.TNC_timeSeriesExchangeItem) 

    /**
     * Method unmarshalTNC_dataObjectConfig
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TNC_dataObjectConfig unmarshalTNC_dataObjectConfig(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TNC_dataObjectConfig) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TNC_dataObjectConfig.class, reader);
    } //-- org.openda.core.io.castorgenerated.TNC_dataObjectConfig unmarshalTNC_dataObjectConfig(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
