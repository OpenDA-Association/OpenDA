/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify either a black box model or a black box model factory
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice _blackBoxStochModelConfigXMLChoice;

    /**
     * DEPRECATED. Use of this element is discouraged, use
     * vectorSpecification -> parameters -> uncertaintyModule
     * instead. Define stochastic model through an uncertainty
     * module. Specify class or executable file, arguments to
     * supply and fail/success checks to perform. 
     */
    private org.openda.core.io.castorgenerated.ActionXML _uncertaintyModule;

    /**
     * Optional. Path and name of a range validation config file
     * (relative to this configuration file) that contains range
     * validation constraints for exchange items.
     */
    private java.lang.String _rangeValidationConfigFile;

    /**
     * Specify external forcings, being either boundaries, noise on
     * boundaries or boundaries including noise.
     */
    private java.util.ArrayList _boundaryProviderList;

    /**
     * Define stochastic model by specifying the vectors of
     * parameters, state, and/or predictor
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML _vectorSpecification;

    /**
     * Restart dir./files information
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML _restartInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelConfigXML() {
        super();
        _boundaryProviderList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBoundaryProvider
     * 
     * @param vBoundaryProvider
     */
    public void addBoundaryProvider(org.openda.core.io.castorgenerated.BoundaryProviderXML vBoundaryProvider)
        throws java.lang.IndexOutOfBoundsException
    {
        _boundaryProviderList.add(vBoundaryProvider);
    } //-- void addBoundaryProvider(org.openda.core.io.castorgenerated.BoundaryProviderXML) 

    /**
     * Method addBoundaryProvider
     * 
     * @param index
     * @param vBoundaryProvider
     */
    public void addBoundaryProvider(int index, org.openda.core.io.castorgenerated.BoundaryProviderXML vBoundaryProvider)
        throws java.lang.IndexOutOfBoundsException
    {
        _boundaryProviderList.add(index, vBoundaryProvider);
    } //-- void addBoundaryProvider(int, org.openda.core.io.castorgenerated.BoundaryProviderXML) 

    /**
     * Method clearBoundaryProvider
     */
    public void clearBoundaryProvider()
    {
        _boundaryProviderList.clear();
    } //-- void clearBoundaryProvider() 

    /**
     * Method enumerateBoundaryProvider
     */
    public java.util.Enumeration enumerateBoundaryProvider()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_boundaryProviderList.iterator());
    } //-- java.util.Enumeration enumerateBoundaryProvider() 

    /**
     * Returns the value of field
     * 'blackBoxStochModelConfigXMLChoice'. The field
     * 'blackBoxStochModelConfigXMLChoice' has the following
     * description: Specify either a black box model or a black box
     * model factory
     * 
     * @return the value of field
     * 'blackBoxStochModelConfigXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice getBlackBoxStochModelConfigXMLChoice()
    {
        return this._blackBoxStochModelConfigXMLChoice;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice getBlackBoxStochModelConfigXMLChoice() 

    /**
     * Method getBoundaryProvider
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BoundaryProviderXML getBoundaryProvider(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _boundaryProviderList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BoundaryProviderXML) _boundaryProviderList.get(index);
    } //-- org.openda.core.io.castorgenerated.BoundaryProviderXML getBoundaryProvider(int) 

    /**
     * Method getBoundaryProvider
     */
    public org.openda.core.io.castorgenerated.BoundaryProviderXML[] getBoundaryProvider()
    {
        int size = _boundaryProviderList.size();
        org.openda.core.io.castorgenerated.BoundaryProviderXML[] mArray = new org.openda.core.io.castorgenerated.BoundaryProviderXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BoundaryProviderXML) _boundaryProviderList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BoundaryProviderXML[] getBoundaryProvider() 

    /**
     * Method getBoundaryProviderCount
     */
    public int getBoundaryProviderCount()
    {
        return _boundaryProviderList.size();
    } //-- int getBoundaryProviderCount() 

    /**
     * Returns the value of field 'rangeValidationConfigFile'. The
     * field 'rangeValidationConfigFile' has the following
     * description: Optional. Path and name of a range validation
     * config file (relative to this configuration file) that
     * contains range validation constraints for exchange items.
     * 
     * @return the value of field 'rangeValidationConfigFile'.
     */
    public java.lang.String getRangeValidationConfigFile()
    {
        return this._rangeValidationConfigFile;
    } //-- java.lang.String getRangeValidationConfigFile() 

    /**
     * Returns the value of field 'restartInfo'. The field
     * 'restartInfo' has the following description: Restart
     * dir./files information
     * 
     * @return the value of field 'restartInfo'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML getRestartInfo()
    {
        return this._restartInfo;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML getRestartInfo() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description:
     * DEPRECATED. Use of this element is discouraged, use
     * vectorSpecification -> parameters -> uncertaintyModule
     * instead. Define stochastic model through an uncertainty
     * module. Specify class or executable file, arguments to
     * supply and fail/success checks to perform. 
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public org.openda.core.io.castorgenerated.ActionXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- org.openda.core.io.castorgenerated.ActionXML getUncertaintyModule() 

    /**
     * Returns the value of field 'vectorSpecification'. The field
     * 'vectorSpecification' has the following description: Define
     * stochastic model by specifying the vectors of parameters,
     * state, and/or predictor
     * 
     * @return the value of field 'vectorSpecification'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML getVectorSpecification()
    {
        return this._vectorSpecification;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML getVectorSpecification() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBoundaryProvider
     * 
     * @param vBoundaryProvider
     */
    public boolean removeBoundaryProvider(org.openda.core.io.castorgenerated.BoundaryProviderXML vBoundaryProvider)
    {
        boolean removed = _boundaryProviderList.remove(vBoundaryProvider);
        return removed;
    } //-- boolean removeBoundaryProvider(org.openda.core.io.castorgenerated.BoundaryProviderXML) 

    /**
     * Sets the value of field 'blackBoxStochModelConfigXMLChoice'.
     * The field 'blackBoxStochModelConfigXMLChoice' has the
     * following description: Specify either a black box model or a
     * black box model factory
     * 
     * @param blackBoxStochModelConfigXMLChoice the value of field
     * 'blackBoxStochModelConfigXMLChoice'.
     */
    public void setBlackBoxStochModelConfigXMLChoice(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice blackBoxStochModelConfigXMLChoice)
    {
        this._blackBoxStochModelConfigXMLChoice = blackBoxStochModelConfigXMLChoice;
    } //-- void setBlackBoxStochModelConfigXMLChoice(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice) 

    /**
     * Method setBoundaryProvider
     * 
     * @param index
     * @param vBoundaryProvider
     */
    public void setBoundaryProvider(int index, org.openda.core.io.castorgenerated.BoundaryProviderXML vBoundaryProvider)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _boundaryProviderList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _boundaryProviderList.set(index, vBoundaryProvider);
    } //-- void setBoundaryProvider(int, org.openda.core.io.castorgenerated.BoundaryProviderXML) 

    /**
     * Method setBoundaryProvider
     * 
     * @param boundaryProviderArray
     */
    public void setBoundaryProvider(org.openda.core.io.castorgenerated.BoundaryProviderXML[] boundaryProviderArray)
    {
        //-- copy array
        _boundaryProviderList.clear();
        for (int i = 0; i < boundaryProviderArray.length; i++) {
            _boundaryProviderList.add(boundaryProviderArray[i]);
        }
    } //-- void setBoundaryProvider(org.openda.core.io.castorgenerated.BoundaryProviderXML) 

    /**
     * Sets the value of field 'rangeValidationConfigFile'. The
     * field 'rangeValidationConfigFile' has the following
     * description: Optional. Path and name of a range validation
     * config file (relative to this configuration file) that
     * contains range validation constraints for exchange items.
     * 
     * @param rangeValidationConfigFile the value of field
     * 'rangeValidationConfigFile'.
     */
    public void setRangeValidationConfigFile(java.lang.String rangeValidationConfigFile)
    {
        this._rangeValidationConfigFile = rangeValidationConfigFile;
    } //-- void setRangeValidationConfigFile(java.lang.String) 

    /**
     * Sets the value of field 'restartInfo'. The field
     * 'restartInfo' has the following description: Restart
     * dir./files information
     * 
     * @param restartInfo the value of field 'restartInfo'.
     */
    public void setRestartInfo(org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML restartInfo)
    {
        this._restartInfo = restartInfo;
    } //-- void setRestartInfo(org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description:
     * DEPRECATED. Use of this element is discouraged, use
     * vectorSpecification -> parameters -> uncertaintyModule
     * instead. Define stochastic model through an uncertainty
     * module. Specify class or executable file, arguments to
     * supply and fail/success checks to perform. 
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(org.openda.core.io.castorgenerated.ActionXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Sets the value of field 'vectorSpecification'. The field
     * 'vectorSpecification' has the following description: Define
     * stochastic model by specifying the vectors of parameters,
     * state, and/or predictor
     * 
     * @param vectorSpecification the value of field
     * 'vectorSpecification'.
     */
    public void setVectorSpecification(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML vectorSpecification)
    {
        this._vectorSpecification = vectorSpecification;
    } //-- void setVectorSpecification(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML) 

    /**
     * Method unmarshalBlackBoxStochModelConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML unmarshalBlackBoxStochModelConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML unmarshalBlackBoxStochModelConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
