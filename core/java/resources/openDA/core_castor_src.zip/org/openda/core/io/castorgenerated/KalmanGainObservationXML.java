/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class KalmanGainObservationXML.
 * 
 * @version $Revision$ $Date$
 */
public class KalmanGainObservationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The identifier for the observation (unique with the list of
     * stored observations)
     */
    private java.lang.String _id;

    /**
     * The time offset of the observation, expressed in days,
     * relative to the time stamp for this kalman gain (0 means:
     * same time stamp as the gain, negative means before the
     * kalman gain time stamp)
     */
    private double _timeOffsetInDays;

    /**
     * keeps track of state for field: _timeOffsetInDays
     */
    private boolean _has_timeOffsetInDays;

    /**
     * Field _kalmanGainObservationXMLChoice
     */
    private org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice _kalmanGainObservationXMLChoice;


      //----------------/
     //- Constructors -/
    //----------------/

    public KalmanGainObservationXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: The identifier for the observation
     * (unique with the list of stored observations)
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'kalmanGainObservationXMLChoice'.
     * 
     * @return the value of field 'kalmanGainObservationXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice getKalmanGainObservationXMLChoice()
    {
        return this._kalmanGainObservationXMLChoice;
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice getKalmanGainObservationXMLChoice() 

    /**
     * Returns the value of field 'timeOffsetInDays'. The field
     * 'timeOffsetInDays' has the following description: The time
     * offset of the observation, expressed in days, relative to
     * the time stamp for this kalman gain (0 means: same time
     * stamp as the gain, negative means before the kalman gain
     * time stamp)
     * 
     * @return the value of field 'timeOffsetInDays'.
     */
    public double getTimeOffsetInDays()
    {
        return this._timeOffsetInDays;
    } //-- double getTimeOffsetInDays() 

    /**
     * Method hasTimeOffsetInDays
     */
    public boolean hasTimeOffsetInDays()
    {
        return this._has_timeOffsetInDays;
    } //-- boolean hasTimeOffsetInDays() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: The identifier for the observation
     * (unique with the list of stored observations)
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'kalmanGainObservationXMLChoice'.
     * 
     * @param kalmanGainObservationXMLChoice the value of field
     * 'kalmanGainObservationXMLChoice'.
     */
    public void setKalmanGainObservationXMLChoice(org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice kalmanGainObservationXMLChoice)
    {
        this._kalmanGainObservationXMLChoice = kalmanGainObservationXMLChoice;
    } //-- void setKalmanGainObservationXMLChoice(org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice) 

    /**
     * Sets the value of field 'timeOffsetInDays'. The field
     * 'timeOffsetInDays' has the following description: The time
     * offset of the observation, expressed in days, relative to
     * the time stamp for this kalman gain (0 means: same time
     * stamp as the gain, negative means before the kalman gain
     * time stamp)
     * 
     * @param timeOffsetInDays the value of field 'timeOffsetInDays'
     */
    public void setTimeOffsetInDays(double timeOffsetInDays)
    {
        this._timeOffsetInDays = timeOffsetInDays;
        this._has_timeOffsetInDays = true;
    } //-- void setTimeOffsetInDays(double) 

    /**
     * Method unmarshalKalmanGainObservationXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.KalmanGainObservationXML unmarshalKalmanGainObservationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.KalmanGainObservationXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.KalmanGainObservationXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXML unmarshalKalmanGainObservationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
