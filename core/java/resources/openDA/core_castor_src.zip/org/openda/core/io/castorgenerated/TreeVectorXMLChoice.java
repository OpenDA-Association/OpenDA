/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TreeVectorXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class TreeVectorXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field treeVectorXMLChoiceItem
     */
    private org.openda.core.io.castorgenerated.TreeVectorXMLChoiceItem treeVectorXMLChoiceItem;


      //----------------/
     //- Constructors -/
    //----------------/

    public TreeVectorXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.TreeVectorXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'treeVectorXMLChoiceItem'.
     * 
     * @return the value of field 'treeVectorXMLChoiceItem'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXMLChoiceItem getTreeVectorXMLChoiceItem()
    {
        return this.treeVectorXMLChoiceItem;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXMLChoiceItem getTreeVectorXMLChoiceItem() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'treeVectorXMLChoiceItem'.
     * 
     * @param treeVectorXMLChoiceItem the value of field
     * 'treeVectorXMLChoiceItem'.
     */
    public void setTreeVectorXMLChoiceItem(org.openda.core.io.castorgenerated.TreeVectorXMLChoiceItem treeVectorXMLChoiceItem)
    {
        this.treeVectorXMLChoiceItem = treeVectorXMLChoiceItem;
    } //-- void setTreeVectorXMLChoiceItem(org.openda.core.io.castorgenerated.TreeVectorXMLChoiceItem) 

    /**
     * Method unmarshalTreeVectorXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TreeVectorXMLChoice unmarshalTreeVectorXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TreeVectorXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TreeVectorXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.TreeVectorXMLChoice unmarshalTreeVectorXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
