/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class PowellXMLChoice2Item.
 * 
 * @version $Revision$ $Date$
 */
public class PowellXMLChoice2Item implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _searchDirParams
     */
    private org.openda.core.io.castorgenerated.TreeVectorXML _searchDirParams;

    /**
     * Field _searchDirParamVector
     */
    private java.lang.String _searchDirParamVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public PowellXMLChoice2Item() {
        super();
    } //-- org.openda.core.io.castorgenerated.PowellXMLChoice2Item()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'searchDirParamVector'.
     * 
     * @return the value of field 'searchDirParamVector'.
     */
    public java.lang.String getSearchDirParamVector()
    {
        return this._searchDirParamVector;
    } //-- java.lang.String getSearchDirParamVector() 

    /**
     * Returns the value of field 'searchDirParams'.
     * 
     * @return the value of field 'searchDirParams'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXML getSearchDirParams()
    {
        return this._searchDirParams;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML getSearchDirParams() 

    /**
     * Sets the value of field 'searchDirParamVector'.
     * 
     * @param searchDirParamVector the value of field
     * 'searchDirParamVector'.
     */
    public void setSearchDirParamVector(java.lang.String searchDirParamVector)
    {
        this._searchDirParamVector = searchDirParamVector;
    } //-- void setSearchDirParamVector(java.lang.String) 

    /**
     * Sets the value of field 'searchDirParams'.
     * 
     * @param searchDirParams the value of field 'searchDirParams'.
     */
    public void setSearchDirParams(org.openda.core.io.castorgenerated.TreeVectorXML searchDirParams)
    {
        this._searchDirParams = searchDirParams;
    } //-- void setSearchDirParams(org.openda.core.io.castorgenerated.TreeVectorXML) 

}
