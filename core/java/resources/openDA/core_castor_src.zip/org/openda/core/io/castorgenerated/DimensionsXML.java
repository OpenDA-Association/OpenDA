/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DimensionsXML.
 * 
 * @version $Revision$ $Date$
 */
public class DimensionsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _dimSize1
     */
    private java.lang.String _dimSize1;

    /**
     * Field _dimSize2
     */
    private java.lang.String _dimSize2;

    /**
     * Field _dimSize3
     */
    private java.lang.String _dimSize3;


      //----------------/
     //- Constructors -/
    //----------------/

    public DimensionsXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.DimensionsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dimSize1'.
     * 
     * @return the value of field 'dimSize1'.
     */
    public java.lang.String getDimSize1()
    {
        return this._dimSize1;
    } //-- java.lang.String getDimSize1() 

    /**
     * Returns the value of field 'dimSize2'.
     * 
     * @return the value of field 'dimSize2'.
     */
    public java.lang.String getDimSize2()
    {
        return this._dimSize2;
    } //-- java.lang.String getDimSize2() 

    /**
     * Returns the value of field 'dimSize3'.
     * 
     * @return the value of field 'dimSize3'.
     */
    public java.lang.String getDimSize3()
    {
        return this._dimSize3;
    } //-- java.lang.String getDimSize3() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dimSize1'.
     * 
     * @param dimSize1 the value of field 'dimSize1'.
     */
    public void setDimSize1(java.lang.String dimSize1)
    {
        this._dimSize1 = dimSize1;
    } //-- void setDimSize1(java.lang.String) 

    /**
     * Sets the value of field 'dimSize2'.
     * 
     * @param dimSize2 the value of field 'dimSize2'.
     */
    public void setDimSize2(java.lang.String dimSize2)
    {
        this._dimSize2 = dimSize2;
    } //-- void setDimSize2(java.lang.String) 

    /**
     * Sets the value of field 'dimSize3'.
     * 
     * @param dimSize3 the value of field 'dimSize3'.
     */
    public void setDimSize3(java.lang.String dimSize3)
    {
        this._dimSize3 = dimSize3;
    } //-- void setDimSize3(java.lang.String) 

    /**
     * Method unmarshalDimensionsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.DimensionsXML unmarshalDimensionsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.DimensionsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.DimensionsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.DimensionsXML unmarshalDimensionsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
