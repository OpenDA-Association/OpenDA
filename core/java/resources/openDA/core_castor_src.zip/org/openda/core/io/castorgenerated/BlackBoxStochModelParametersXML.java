/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelParametersXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelParametersXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelParametersXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBlackBoxStochModelParametersXMLItem
     * 
     * @param vBlackBoxStochModelParametersXMLItem
     */
    public void addBlackBoxStochModelParametersXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem vBlackBoxStochModelParametersXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vBlackBoxStochModelParametersXMLItem);
    } //-- void addBlackBoxStochModelParametersXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) 

    /**
     * Method addBlackBoxStochModelParametersXMLItem
     * 
     * @param index
     * @param vBlackBoxStochModelParametersXMLItem
     */
    public void addBlackBoxStochModelParametersXMLItem(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem vBlackBoxStochModelParametersXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vBlackBoxStochModelParametersXMLItem);
    } //-- void addBlackBoxStochModelParametersXMLItem(int, org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) 

    /**
     * Method clearBlackBoxStochModelParametersXMLItem
     */
    public void clearBlackBoxStochModelParametersXMLItem()
    {
        _items.clear();
    } //-- void clearBlackBoxStochModelParametersXMLItem() 

    /**
     * Method enumerateBlackBoxStochModelParametersXMLItem
     */
    public java.util.Enumeration enumerateBlackBoxStochModelParametersXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateBlackBoxStochModelParametersXMLItem() 

    /**
     * Method getBlackBoxStochModelParametersXMLItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem getBlackBoxStochModelParametersXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) _items.get(index);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem getBlackBoxStochModelParametersXMLItem(int) 

    /**
     * Method getBlackBoxStochModelParametersXMLItem
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem[] getBlackBoxStochModelParametersXMLItem()
    {
        int size = _items.size();
        org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem[] mArray = new org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem[] getBlackBoxStochModelParametersXMLItem() 

    /**
     * Method getBlackBoxStochModelParametersXMLItemCount
     */
    public int getBlackBoxStochModelParametersXMLItemCount()
    {
        return _items.size();
    } //-- int getBlackBoxStochModelParametersXMLItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBlackBoxStochModelParametersXMLItem
     * 
     * @param vBlackBoxStochModelParametersXMLItem
     */
    public boolean removeBlackBoxStochModelParametersXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem vBlackBoxStochModelParametersXMLItem)
    {
        boolean removed = _items.remove(vBlackBoxStochModelParametersXMLItem);
        return removed;
    } //-- boolean removeBlackBoxStochModelParametersXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) 

    /**
     * Method setBlackBoxStochModelParametersXMLItem
     * 
     * @param index
     * @param vBlackBoxStochModelParametersXMLItem
     */
    public void setBlackBoxStochModelParametersXMLItem(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem vBlackBoxStochModelParametersXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vBlackBoxStochModelParametersXMLItem);
    } //-- void setBlackBoxStochModelParametersXMLItem(int, org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) 

    /**
     * Method setBlackBoxStochModelParametersXMLItem
     * 
     * @param blackBoxStochModelParametersXMLItemArray
     */
    public void setBlackBoxStochModelParametersXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem[] blackBoxStochModelParametersXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < blackBoxStochModelParametersXMLItemArray.length; i++) {
            _items.add(blackBoxStochModelParametersXMLItemArray[i]);
        }
    } //-- void setBlackBoxStochModelParametersXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem) 

    /**
     * Method unmarshalBlackBoxStochModelParametersXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML unmarshalBlackBoxStochModelParametersXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML unmarshalBlackBoxStochModelParametersXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
