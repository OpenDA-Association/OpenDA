/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class StateNoiseXML.
 * 
 * @version $Revision$ $Date$
 */
public class StateNoiseXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the identity of the noise model vector. It is
     * required if the noise model contains more than one source
     * vectors. If the noise model contains one subvector, it may
     * be omitted. In that case the source (sub-)vector's id is used
     */
    private java.lang.String _id;

    /**
     * The class that implements the noise model
     */
    private java.lang.String _className;

    /**
     * The working directory where the noise model is started
     */
    private java.lang.String _workingDirectory;

    /**
     * Specify name of xml file containing configuration of the
     * noise model. File format depends on class.
     */
    private java.lang.String _configFile;

    /**
     * The relations between the noise model's exchange items and
     * the model's exchange items
     */
    private org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML _exchangeItems;

    /**
     * Field _stateNoiseXMLChoiceList
     */
    private java.util.ArrayList _stateNoiseXMLChoiceList;

    /**
     * Field _stateNoiseXMLChoice2
     */
    private org.openda.core.io.castorgenerated.StateNoiseXMLChoice2 _stateNoiseXMLChoice2;


      //----------------/
     //- Constructors -/
    //----------------/

    public StateNoiseXML() {
        super();
        _stateNoiseXMLChoiceList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.StateNoiseXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addStateNoiseXMLChoice
     * 
     * @param vStateNoiseXMLChoice
     */
    public void addStateNoiseXMLChoice(org.openda.core.io.castorgenerated.StateNoiseXMLChoice vStateNoiseXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _stateNoiseXMLChoiceList.add(vStateNoiseXMLChoice);
    } //-- void addStateNoiseXMLChoice(org.openda.core.io.castorgenerated.StateNoiseXMLChoice) 

    /**
     * Method addStateNoiseXMLChoice
     * 
     * @param index
     * @param vStateNoiseXMLChoice
     */
    public void addStateNoiseXMLChoice(int index, org.openda.core.io.castorgenerated.StateNoiseXMLChoice vStateNoiseXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _stateNoiseXMLChoiceList.add(index, vStateNoiseXMLChoice);
    } //-- void addStateNoiseXMLChoice(int, org.openda.core.io.castorgenerated.StateNoiseXMLChoice) 

    /**
     * Method clearStateNoiseXMLChoice
     */
    public void clearStateNoiseXMLChoice()
    {
        _stateNoiseXMLChoiceList.clear();
    } //-- void clearStateNoiseXMLChoice() 

    /**
     * Method enumerateStateNoiseXMLChoice
     */
    public java.util.Enumeration enumerateStateNoiseXMLChoice()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_stateNoiseXMLChoiceList.iterator());
    } //-- java.util.Enumeration enumerateStateNoiseXMLChoice() 

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: The class that
     * implements the noise model
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'configFile'. The field
     * 'configFile' has the following description: Specify name of
     * xml file containing configuration of the noise model. File
     * format depends on class.
     * 
     * @return the value of field 'configFile'.
     */
    public java.lang.String getConfigFile()
    {
        return this._configFile;
    } //-- java.lang.String getConfigFile() 

    /**
     * Returns the value of field 'exchangeItems'. The field
     * 'exchangeItems' has the following description: The relations
     * between the noise model's exchange items and the model's
     * exchange items
     * 
     * @return the value of field 'exchangeItems'.
     */
    public org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML getExchangeItems()
    {
        return this._exchangeItems;
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML getExchangeItems() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Specify the identity of the noise
     * model vector. It is required if the noise model contains
     * more than one source vectors. If the noise model contains
     * one subvector, it may be omitted. In that case the source
     * (sub-)vector's id is used.
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Method getStateNoiseXMLChoice
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.StateNoiseXMLChoice getStateNoiseXMLChoice(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _stateNoiseXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.StateNoiseXMLChoice) _stateNoiseXMLChoiceList.get(index);
    } //-- org.openda.core.io.castorgenerated.StateNoiseXMLChoice getStateNoiseXMLChoice(int) 

    /**
     * Method getStateNoiseXMLChoice
     */
    public org.openda.core.io.castorgenerated.StateNoiseXMLChoice[] getStateNoiseXMLChoice()
    {
        int size = _stateNoiseXMLChoiceList.size();
        org.openda.core.io.castorgenerated.StateNoiseXMLChoice[] mArray = new org.openda.core.io.castorgenerated.StateNoiseXMLChoice[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.StateNoiseXMLChoice) _stateNoiseXMLChoiceList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.StateNoiseXMLChoice[] getStateNoiseXMLChoice() 

    /**
     * Returns the value of field 'stateNoiseXMLChoice2'.
     * 
     * @return the value of field 'stateNoiseXMLChoice2'.
     */
    public org.openda.core.io.castorgenerated.StateNoiseXMLChoice2 getStateNoiseXMLChoice2()
    {
        return this._stateNoiseXMLChoice2;
    } //-- org.openda.core.io.castorgenerated.StateNoiseXMLChoice2 getStateNoiseXMLChoice2() 

    /**
     * Method getStateNoiseXMLChoiceCount
     */
    public int getStateNoiseXMLChoiceCount()
    {
        return _stateNoiseXMLChoiceList.size();
    } //-- int getStateNoiseXMLChoiceCount() 

    /**
     * Returns the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: The
     * working directory where the noise model is started
     * 
     * @return the value of field 'workingDirectory'.
     */
    public java.lang.String getWorkingDirectory()
    {
        return this._workingDirectory;
    } //-- java.lang.String getWorkingDirectory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeStateNoiseXMLChoice
     * 
     * @param vStateNoiseXMLChoice
     */
    public boolean removeStateNoiseXMLChoice(org.openda.core.io.castorgenerated.StateNoiseXMLChoice vStateNoiseXMLChoice)
    {
        boolean removed = _stateNoiseXMLChoiceList.remove(vStateNoiseXMLChoice);
        return removed;
    } //-- boolean removeStateNoiseXMLChoice(org.openda.core.io.castorgenerated.StateNoiseXMLChoice) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: The class that implements the
     * noise model
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'configFile'. The field 'configFile'
     * has the following description: Specify name of xml file
     * containing configuration of the noise model. File format
     * depends on class.
     * 
     * @param configFile the value of field 'configFile'.
     */
    public void setConfigFile(java.lang.String configFile)
    {
        this._configFile = configFile;
    } //-- void setConfigFile(java.lang.String) 

    /**
     * Sets the value of field 'exchangeItems'. The field
     * 'exchangeItems' has the following description: The relations
     * between the noise model's exchange items and the model's
     * exchange items
     * 
     * @param exchangeItems the value of field 'exchangeItems'.
     */
    public void setExchangeItems(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML exchangeItems)
    {
        this._exchangeItems = exchangeItems;
    } //-- void setExchangeItems(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemsXML) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Specify the identity of the noise
     * model vector. It is required if the noise model contains
     * more than one source vectors. If the noise model contains
     * one subvector, it may be omitted. In that case the source
     * (sub-)vector's id is used.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Method setStateNoiseXMLChoice
     * 
     * @param index
     * @param vStateNoiseXMLChoice
     */
    public void setStateNoiseXMLChoice(int index, org.openda.core.io.castorgenerated.StateNoiseXMLChoice vStateNoiseXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _stateNoiseXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _stateNoiseXMLChoiceList.set(index, vStateNoiseXMLChoice);
    } //-- void setStateNoiseXMLChoice(int, org.openda.core.io.castorgenerated.StateNoiseXMLChoice) 

    /**
     * Method setStateNoiseXMLChoice
     * 
     * @param stateNoiseXMLChoiceArray
     */
    public void setStateNoiseXMLChoice(org.openda.core.io.castorgenerated.StateNoiseXMLChoice[] stateNoiseXMLChoiceArray)
    {
        //-- copy array
        _stateNoiseXMLChoiceList.clear();
        for (int i = 0; i < stateNoiseXMLChoiceArray.length; i++) {
            _stateNoiseXMLChoiceList.add(stateNoiseXMLChoiceArray[i]);
        }
    } //-- void setStateNoiseXMLChoice(org.openda.core.io.castorgenerated.StateNoiseXMLChoice) 

    /**
     * Sets the value of field 'stateNoiseXMLChoice2'.
     * 
     * @param stateNoiseXMLChoice2 the value of field
     * 'stateNoiseXMLChoice2'.
     */
    public void setStateNoiseXMLChoice2(org.openda.core.io.castorgenerated.StateNoiseXMLChoice2 stateNoiseXMLChoice2)
    {
        this._stateNoiseXMLChoice2 = stateNoiseXMLChoice2;
    } //-- void setStateNoiseXMLChoice2(org.openda.core.io.castorgenerated.StateNoiseXMLChoice2) 

    /**
     * Sets the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: The
     * working directory where the noise model is started
     * 
     * @param workingDirectory the value of field 'workingDirectory'
     */
    public void setWorkingDirectory(java.lang.String workingDirectory)
    {
        this._workingDirectory = workingDirectory;
    } //-- void setWorkingDirectory(java.lang.String) 

    /**
     * Method unmarshalStateNoiseXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.StateNoiseXML unmarshalStateNoiseXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.StateNoiseXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.StateNoiseXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.StateNoiseXML unmarshalStateNoiseXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
