/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class RangeValidationConstraintXML.
 * 
 * @version $Revision$ $Date$
 */
public class RangeValidationConstraintXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Id of this constraint. This is only used to refer to this
     * constraint in log messages.
     */
    private java.lang.String _id;

    /**
     * Constraint that limits the range of the specified exchange
     * item using the specified lower and/or upper limit. If the
     * value of the exchange item is below the lower limit, then
     * the value is changed to the lower limit. If the value of a
     * model exchange item is above the upper limit, then the value
     * is changed to the upper limit. If an exchange item has more
     * than one value (e.g. a 2D grid), then the specified limits
     * are applied to all values in the exchange item.
     */
    private org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML _constantLimits;


      //----------------/
     //- Constructors -/
    //----------------/

    public RangeValidationConstraintXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstraintXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'constantLimits'. The field
     * 'constantLimits' has the following description: Constraint
     * that limits the range of the specified exchange item using
     * the specified lower and/or upper limit. If the value of the
     * exchange item is below the lower limit, then the value is
     * changed to the lower limit. If the value of a model exchange
     * item is above the upper limit, then the value is changed to
     * the upper limit. If an exchange item has more than one value
     * (e.g. a 2D grid), then the specified limits are applied to
     * all values in the exchange item.
     * 
     * @return the value of field 'constantLimits'.
     */
    public org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML getConstantLimits()
    {
        return this._constantLimits;
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML getConstantLimits() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Id of this constraint. This is only
     * used to refer to this constraint in log messages.
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'constantLimits'. The field
     * 'constantLimits' has the following description: Constraint
     * that limits the range of the specified exchange item using
     * the specified lower and/or upper limit. If the value of the
     * exchange item is below the lower limit, then the value is
     * changed to the lower limit. If the value of a model exchange
     * item is above the upper limit, then the value is changed to
     * the upper limit. If an exchange item has more than one value
     * (e.g. a 2D grid), then the specified limits are applied to
     * all values in the exchange item.
     * 
     * @param constantLimits the value of field 'constantLimits'.
     */
    public void setConstantLimits(org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML constantLimits)
    {
        this._constantLimits = constantLimits;
    } //-- void setConstantLimits(org.openda.core.io.castorgenerated.RangeValidationConstantLimitsConstraintXML) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Id of this constraint. This is only
     * used to refer to this constraint in log messages.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Method unmarshalRangeValidationConstraintXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.RangeValidationConstraintXML unmarshalRangeValidationConstraintXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.RangeValidationConstraintXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.RangeValidationConstraintXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstraintXML unmarshalRangeValidationConstraintXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
