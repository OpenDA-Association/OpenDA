/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML;
import org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class UncertaintyOrNoiseExchangeItemXML.
 * 
 * @version $Revision$ $Date$
 */
public class UncertaintyOrNoiseExchangeItemXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Identity of this noise model's exchange item
     */
    private java.lang.String _id;

    /**
     * Identity of model's exchange item on which to impose this
     * noise model's exchange item 
     */
    private java.lang.String _modelExchangeItemId;

    /**
     * Deprecated, use attribute "transformation" instead. Type of
     * operation to performed when noise is added to an (parameter
     * or state) exchange item: 'add' the noise to the exchange
     * item's values, 'multiply' the exchange item's values with
     * the noise, or 'set' the values (used in those cases where
     * the noise in fact is a realization).
     */
    private org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML _operation = org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML.valueOf("add");

    /**
     * Transformation of noise variable. 'identity' means that the
     * value will be added directly without any transformation to
     * the adjusted parameter. 'ln' means that the value is
     * transformed logarithmically before it is added to the
     * parameter; this gives a correction, which is a fraction of
     * the parameter value.
     */
    private org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML _transformation = org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML.valueOf("identity");

    /**
     * When adding noise to a time dependent exchange item for the
     * next (e.g. EnKF) time slice, skip the first time step
     * (because is was already modified in the previous time slice)
     */
    private boolean _skipFirstTimeStep = false;

    /**
     * keeps track of state for field: _skipFirstTimeStep
     */
    private boolean _has_skipFirstTimeStep;

    /**
     * When adding noise to a state exchange time, add the
     * difference between the current noise and the previous noise,
     * instead of adding the full noise.
     */
    private boolean _addOnlyNoiseDifference = false;

    /**
     * keeps track of state for field: _addOnlyNoiseDifference
     */
    private boolean _has_addOnlyNoiseDifference;

    /**
     * Integer ratio between the size of the model state and the
     * noise model state (1 noise model value will be applied to
     * "stateSizeNoiseSizeRatio" model values)
     */
    private int _stateSizeNoiseSizeRatio = 1;

    /**
     * keeps track of state for field: _stateSizeNoiseSizeRatio
     */
    private boolean _has_stateSizeNoiseSizeRatio;

    /**
     * When true, state noise will be added after compute instead
     * of before
     */
    private boolean _addStateNoiseAfterCompute = false;

    /**
     * keeps track of state for field: _addStateNoiseAfterCompute
     */
    private boolean _has_addStateNoiseAfterCompute;

    /**
     * When true, adding noise for a time step will not be skipped
     * if for that time step noise has already been added before.
     * For example for overlapping time steps add the end of a
     * forecast period and at the beginning of a forecast period
     */
    private boolean _allowAddNoiseMultipleTimesForTimeSteps = false;

    /**
     * keeps track of state for field:
     * _allowAddNoiseMultipleTimesForTimeSteps
     */
    private boolean _has_allowAddNoiseMultipleTimesForTimeSteps;

    /**
     * Specify one or more model exchange items on which to impose
     * noise defined by this noise model's exchange item (for a
     * single model ExchangeItem, use modelExchangeItemId in the
     * attributes instead of this list)
     */
    private java.util.ArrayList _modelExchangeItemList;


      //----------------/
     //- Constructors -/
    //----------------/

    public UncertaintyOrNoiseExchangeItemXML() {
        super();
        setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML.valueOf("add"));
        setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML.valueOf("identity"));
        _modelExchangeItemList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addModelExchangeItem
     * 
     * @param vModelExchangeItem
     */
    public void addModelExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML vModelExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _modelExchangeItemList.add(vModelExchangeItem);
    } //-- void addModelExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) 

    /**
     * Method addModelExchangeItem
     * 
     * @param index
     * @param vModelExchangeItem
     */
    public void addModelExchangeItem(int index, org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML vModelExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _modelExchangeItemList.add(index, vModelExchangeItem);
    } //-- void addModelExchangeItem(int, org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) 

    /**
     * Method clearModelExchangeItem
     */
    public void clearModelExchangeItem()
    {
        _modelExchangeItemList.clear();
    } //-- void clearModelExchangeItem() 

    /**
     * Method deleteAddOnlyNoiseDifference
     */
    public void deleteAddOnlyNoiseDifference()
    {
        this._has_addOnlyNoiseDifference= false;
    } //-- void deleteAddOnlyNoiseDifference() 

    /**
     * Method deleteAddStateNoiseAfterCompute
     */
    public void deleteAddStateNoiseAfterCompute()
    {
        this._has_addStateNoiseAfterCompute= false;
    } //-- void deleteAddStateNoiseAfterCompute() 

    /**
     * Method deleteAllowAddNoiseMultipleTimesForTimeSteps
     */
    public void deleteAllowAddNoiseMultipleTimesForTimeSteps()
    {
        this._has_allowAddNoiseMultipleTimesForTimeSteps= false;
    } //-- void deleteAllowAddNoiseMultipleTimesForTimeSteps() 

    /**
     * Method deleteSkipFirstTimeStep
     */
    public void deleteSkipFirstTimeStep()
    {
        this._has_skipFirstTimeStep= false;
    } //-- void deleteSkipFirstTimeStep() 

    /**
     * Method deleteStateSizeNoiseSizeRatio
     */
    public void deleteStateSizeNoiseSizeRatio()
    {
        this._has_stateSizeNoiseSizeRatio= false;
    } //-- void deleteStateSizeNoiseSizeRatio() 

    /**
     * Method enumerateModelExchangeItem
     */
    public java.util.Enumeration enumerateModelExchangeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_modelExchangeItemList.iterator());
    } //-- java.util.Enumeration enumerateModelExchangeItem() 

    /**
     * Returns the value of field 'addOnlyNoiseDifference'. The
     * field 'addOnlyNoiseDifference' has the following
     * description: When adding noise to a state exchange time, add
     * the difference between the current noise and the previous
     * noise, instead of adding the full noise.
     * 
     * @return the value of field 'addOnlyNoiseDifference'.
     */
    public boolean getAddOnlyNoiseDifference()
    {
        return this._addOnlyNoiseDifference;
    } //-- boolean getAddOnlyNoiseDifference() 

    /**
     * Returns the value of field 'addStateNoiseAfterCompute'. The
     * field 'addStateNoiseAfterCompute' has the following
     * description: When true, state noise will be added after
     * compute instead of before
     * 
     * @return the value of field 'addStateNoiseAfterCompute'.
     */
    public boolean getAddStateNoiseAfterCompute()
    {
        return this._addStateNoiseAfterCompute;
    } //-- boolean getAddStateNoiseAfterCompute() 

    /**
     * Returns the value of field
     * 'allowAddNoiseMultipleTimesForTimeSteps'. The field
     * 'allowAddNoiseMultipleTimesForTimeSteps' has the following
     * description: When true, adding noise for a time step will
     * not be skipped if for that time step noise has already been
     * added before. For example for overlapping time steps add the
     * end of a forecast period and at the beginning of a forecast
     * period
     * 
     * @return the value of field
     * 'allowAddNoiseMultipleTimesForTimeSteps'.
     */
    public boolean getAllowAddNoiseMultipleTimesForTimeSteps()
    {
        return this._allowAddNoiseMultipleTimesForTimeSteps;
    } //-- boolean getAllowAddNoiseMultipleTimesForTimeSteps() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Identity of this noise model's
     * exchange item
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Method getModelExchangeItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML getModelExchangeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _modelExchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) _modelExchangeItemList.get(index);
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML getModelExchangeItem(int) 

    /**
     * Method getModelExchangeItem
     */
    public org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML[] getModelExchangeItem()
    {
        int size = _modelExchangeItemList.size();
        org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML[] mArray = new org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) _modelExchangeItemList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML[] getModelExchangeItem() 

    /**
     * Method getModelExchangeItemCount
     */
    public int getModelExchangeItemCount()
    {
        return _modelExchangeItemList.size();
    } //-- int getModelExchangeItemCount() 

    /**
     * Returns the value of field 'modelExchangeItemId'. The field
     * 'modelExchangeItemId' has the following description:
     * Identity of model's exchange item on which to impose this
     * noise model's exchange item 
     * 
     * @return the value of field 'modelExchangeItemId'.
     */
    public java.lang.String getModelExchangeItemId()
    {
        return this._modelExchangeItemId;
    } //-- java.lang.String getModelExchangeItemId() 

    /**
     * Returns the value of field 'operation'. The field
     * 'operation' has the following description: Deprecated, use
     * attribute "transformation" instead. Type of operation to
     * performed when noise is added to an (parameter or state)
     * exchange item: 'add' the noise to the exchange item's
     * values, 'multiply' the exchange item's values with the
     * noise, or 'set' the values (used in those cases where the
     * noise in fact is a realization).
     * 
     * @return the value of field 'operation'.
     */
    public org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML getOperation()
    {
        return this._operation;
    } //-- org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML getOperation() 

    /**
     * Returns the value of field 'skipFirstTimeStep'. The field
     * 'skipFirstTimeStep' has the following description: When
     * adding noise to a time dependent exchange item for the next
     * (e.g. EnKF) time slice, skip the first time step (because is
     * was already modified in the previous time slice)
     * 
     * @return the value of field 'skipFirstTimeStep'.
     */
    public boolean getSkipFirstTimeStep()
    {
        return this._skipFirstTimeStep;
    } //-- boolean getSkipFirstTimeStep() 

    /**
     * Returns the value of field 'stateSizeNoiseSizeRatio'. The
     * field 'stateSizeNoiseSizeRatio' has the following
     * description: Integer ratio between the size of the model
     * state and the noise model state (1 noise model value will be
     * applied to "stateSizeNoiseSizeRatio" model values)
     * 
     * @return the value of field 'stateSizeNoiseSizeRatio'.
     */
    public int getStateSizeNoiseSizeRatio()
    {
        return this._stateSizeNoiseSizeRatio;
    } //-- int getStateSizeNoiseSizeRatio() 

    /**
     * Returns the value of field 'transformation'. The field
     * 'transformation' has the following description:
     * Transformation of noise variable. 'identity' means that the
     * value will be added directly without any transformation to
     * the adjusted parameter. 'ln' means that the value is
     * transformed logarithmically before it is added to the
     * parameter; this gives a correction, which is a fraction of
     * the parameter value.
     * 
     * @return the value of field 'transformation'.
     */
    public org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML getTransformation()
    {
        return this._transformation;
    } //-- org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML getTransformation() 

    /**
     * Method hasAddOnlyNoiseDifference
     */
    public boolean hasAddOnlyNoiseDifference()
    {
        return this._has_addOnlyNoiseDifference;
    } //-- boolean hasAddOnlyNoiseDifference() 

    /**
     * Method hasAddStateNoiseAfterCompute
     */
    public boolean hasAddStateNoiseAfterCompute()
    {
        return this._has_addStateNoiseAfterCompute;
    } //-- boolean hasAddStateNoiseAfterCompute() 

    /**
     * Method hasAllowAddNoiseMultipleTimesForTimeSteps
     */
    public boolean hasAllowAddNoiseMultipleTimesForTimeSteps()
    {
        return this._has_allowAddNoiseMultipleTimesForTimeSteps;
    } //-- boolean hasAllowAddNoiseMultipleTimesForTimeSteps() 

    /**
     * Method hasSkipFirstTimeStep
     */
    public boolean hasSkipFirstTimeStep()
    {
        return this._has_skipFirstTimeStep;
    } //-- boolean hasSkipFirstTimeStep() 

    /**
     * Method hasStateSizeNoiseSizeRatio
     */
    public boolean hasStateSizeNoiseSizeRatio()
    {
        return this._has_stateSizeNoiseSizeRatio;
    } //-- boolean hasStateSizeNoiseSizeRatio() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeModelExchangeItem
     * 
     * @param vModelExchangeItem
     */
    public boolean removeModelExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML vModelExchangeItem)
    {
        boolean removed = _modelExchangeItemList.remove(vModelExchangeItem);
        return removed;
    } //-- boolean removeModelExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) 

    /**
     * Sets the value of field 'addOnlyNoiseDifference'. The field
     * 'addOnlyNoiseDifference' has the following description: When
     * adding noise to a state exchange time, add the difference
     * between the current noise and the previous noise, instead of
     * adding the full noise.
     * 
     * @param addOnlyNoiseDifference the value of field
     * 'addOnlyNoiseDifference'.
     */
    public void setAddOnlyNoiseDifference(boolean addOnlyNoiseDifference)
    {
        this._addOnlyNoiseDifference = addOnlyNoiseDifference;
        this._has_addOnlyNoiseDifference = true;
    } //-- void setAddOnlyNoiseDifference(boolean) 

    /**
     * Sets the value of field 'addStateNoiseAfterCompute'. The
     * field 'addStateNoiseAfterCompute' has the following
     * description: When true, state noise will be added after
     * compute instead of before
     * 
     * @param addStateNoiseAfterCompute the value of field
     * 'addStateNoiseAfterCompute'.
     */
    public void setAddStateNoiseAfterCompute(boolean addStateNoiseAfterCompute)
    {
        this._addStateNoiseAfterCompute = addStateNoiseAfterCompute;
        this._has_addStateNoiseAfterCompute = true;
    } //-- void setAddStateNoiseAfterCompute(boolean) 

    /**
     * Sets the value of field
     * 'allowAddNoiseMultipleTimesForTimeSteps'. The field
     * 'allowAddNoiseMultipleTimesForTimeSteps' has the following
     * description: When true, adding noise for a time step will
     * not be skipped if for that time step noise has already been
     * added before. For example for overlapping time steps add the
     * end of a forecast period and at the beginning of a forecast
     * period
     * 
     * @param allowAddNoiseMultipleTimesForTimeSteps the value of
     * field 'allowAddNoiseMultipleTimesForTimeSteps'.
     */
    public void setAllowAddNoiseMultipleTimesForTimeSteps(boolean allowAddNoiseMultipleTimesForTimeSteps)
    {
        this._allowAddNoiseMultipleTimesForTimeSteps = allowAddNoiseMultipleTimesForTimeSteps;
        this._has_allowAddNoiseMultipleTimesForTimeSteps = true;
    } //-- void setAllowAddNoiseMultipleTimesForTimeSteps(boolean) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Identity of this noise model's
     * exchange item
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Method setModelExchangeItem
     * 
     * @param index
     * @param vModelExchangeItem
     */
    public void setModelExchangeItem(int index, org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML vModelExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _modelExchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _modelExchangeItemList.set(index, vModelExchangeItem);
    } //-- void setModelExchangeItem(int, org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) 

    /**
     * Method setModelExchangeItem
     * 
     * @param modelExchangeItemArray
     */
    public void setModelExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML[] modelExchangeItemArray)
    {
        //-- copy array
        _modelExchangeItemList.clear();
        for (int i = 0; i < modelExchangeItemArray.length; i++) {
            _modelExchangeItemList.add(modelExchangeItemArray[i]);
        }
    } //-- void setModelExchangeItem(org.openda.core.io.castorgenerated.UncertaintyOrNoiseModelExchangeItemXML) 

    /**
     * Sets the value of field 'modelExchangeItemId'. The field
     * 'modelExchangeItemId' has the following description:
     * Identity of model's exchange item on which to impose this
     * noise model's exchange item 
     * 
     * @param modelExchangeItemId the value of field
     * 'modelExchangeItemId'.
     */
    public void setModelExchangeItemId(java.lang.String modelExchangeItemId)
    {
        this._modelExchangeItemId = modelExchangeItemId;
    } //-- void setModelExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'operation'. The field 'operation'
     * has the following description: Deprecated, use attribute
     * "transformation" instead. Type of operation to performed
     * when noise is added to an (parameter or state) exchange
     * item: 'add' the noise to the exchange item's values,
     * 'multiply' the exchange item's values with the noise, or
     * 'set' the values (used in those cases where the noise in
     * fact is a realization).
     * 
     * @param operation the value of field 'operation'.
     */
    public void setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML operation)
    {
        this._operation = operation;
    } //-- void setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML) 

    /**
     * Sets the value of field 'skipFirstTimeStep'. The field
     * 'skipFirstTimeStep' has the following description: When
     * adding noise to a time dependent exchange item for the next
     * (e.g. EnKF) time slice, skip the first time step (because is
     * was already modified in the previous time slice)
     * 
     * @param skipFirstTimeStep the value of field
     * 'skipFirstTimeStep'.
     */
    public void setSkipFirstTimeStep(boolean skipFirstTimeStep)
    {
        this._skipFirstTimeStep = skipFirstTimeStep;
        this._has_skipFirstTimeStep = true;
    } //-- void setSkipFirstTimeStep(boolean) 

    /**
     * Sets the value of field 'stateSizeNoiseSizeRatio'. The field
     * 'stateSizeNoiseSizeRatio' has the following description:
     * Integer ratio between the size of the model state and the
     * noise model state (1 noise model value will be applied to
     * "stateSizeNoiseSizeRatio" model values)
     * 
     * @param stateSizeNoiseSizeRatio the value of field
     * 'stateSizeNoiseSizeRatio'.
     */
    public void setStateSizeNoiseSizeRatio(int stateSizeNoiseSizeRatio)
    {
        this._stateSizeNoiseSizeRatio = stateSizeNoiseSizeRatio;
        this._has_stateSizeNoiseSizeRatio = true;
    } //-- void setStateSizeNoiseSizeRatio(int) 

    /**
     * Sets the value of field 'transformation'. The field
     * 'transformation' has the following description:
     * Transformation of noise variable. 'identity' means that the
     * value will be added directly without any transformation to
     * the adjusted parameter. 'ln' means that the value is
     * transformed logarithmically before it is added to the
     * parameter; this gives a correction, which is a fraction of
     * the parameter value.
     * 
     * @param transformation the value of field 'transformation'.
     */
    public void setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML transformation)
    {
        this._transformation = transformation;
    } //-- void setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML) 

    /**
     * Method unmarshalUncertaintyOrNoiseExchangeItemXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML unmarshalUncertaintyOrNoiseExchangeItemXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseExchangeItemXML unmarshalUncertaintyOrNoiseExchangeItemXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
