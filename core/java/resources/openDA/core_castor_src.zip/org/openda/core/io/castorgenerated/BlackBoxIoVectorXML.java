/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxIoVectorXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxIoVectorXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Identity of the exchange item vector to be used in the
     * stochastic model configuration. Note: by using the reserved
     * id "allElementsFromIoObject" all the elements in the data/io
     * object are exposed as exchange items (with the element id in
     * the data/io object as id)
     */
    private java.lang.String _id;

    /**
     * Obsolete, please use dataObjectId. The corresponding object
     * identity of the exchange item
     */
    private java.lang.String _ioObjectId;

    /**
     * The corresponding object identity of the exchange item
     */
    private java.lang.String _dataObjectId;

    /**
     * The corresponding identity of the exchange item as used
     * internally within the model. If this is not specified, then
     * the elementId will be equal to the specified id.
     */
    private java.lang.String _elementId;

    /**
     * The corresponding role type of the exchange item, choose
     * "Input", "Output" or "InOut"
     */
    private org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML _role = org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML.valueOf("InOut");

    /**
     * Optional. This suffix will be appended to the specified id.
     * If elementId not specified, then the elementId will still be
     * equal to the specified id without this suffix. If
     * id="allElementsFromIoObject", then this suffix will be
     * appended to the ids of all exchangeItems of elements in the
     * ioObject. In that case the elementIds will still be equal to
     * the original ids of the elements in the ioObject, i.e.
     * without this suffix.
     */
    private java.lang.String _idSuffix;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxIoVectorXML() {
        super();
        setRole(org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML.valueOf("InOut"));
    } //-- org.openda.core.io.castorgenerated.BlackBoxIoVectorXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dataObjectId'. The field
     * 'dataObjectId' has the following description: The
     * corresponding object identity of the exchange item
     * 
     * @return the value of field 'dataObjectId'.
     */
    public java.lang.String getDataObjectId()
    {
        return this._dataObjectId;
    } //-- java.lang.String getDataObjectId() 

    /**
     * Returns the value of field 'elementId'. The field
     * 'elementId' has the following description: The corresponding
     * identity of the exchange item as used internally within the
     * model. If this is not specified, then the elementId will be
     * equal to the specified id.
     * 
     * @return the value of field 'elementId'.
     */
    public java.lang.String getElementId()
    {
        return this._elementId;
    } //-- java.lang.String getElementId() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Identity of the exchange item vector
     * to be used in the stochastic model configuration. Note: by
     * using the reserved id "allElementsFromIoObject" all the
     * elements in the data/io object are exposed as exchange items
     * (with the element id in the data/io object as id)
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'idSuffix'. The field 'idSuffix'
     * has the following description: Optional. This suffix will be
     * appended to the specified id. If elementId not specified,
     * then the elementId will still be equal to the specified id
     * without this suffix. If id="allElementsFromIoObject", then
     * this suffix will be appended to the ids of all exchangeItems
     * of elements in the ioObject. In that case the elementIds
     * will still be equal to the original ids of the elements in
     * the ioObject, i.e. without this suffix.
     * 
     * @return the value of field 'idSuffix'.
     */
    public java.lang.String getIdSuffix()
    {
        return this._idSuffix;
    } //-- java.lang.String getIdSuffix() 

    /**
     * Returns the value of field 'ioObjectId'. The field
     * 'ioObjectId' has the following description: Obsolete, please
     * use dataObjectId. The corresponding object identity of the
     * exchange item
     * 
     * @return the value of field 'ioObjectId'.
     */
    public java.lang.String getIoObjectId()
    {
        return this._ioObjectId;
    } //-- java.lang.String getIoObjectId() 

    /**
     * Returns the value of field 'role'. The field 'role' has the
     * following description: The corresponding role type of the
     * exchange item, choose "Input", "Output" or "InOut"
     * 
     * @return the value of field 'role'.
     */
    public org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML getRole()
    {
        return this._role;
    } //-- org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML getRole() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dataObjectId'. The field
     * 'dataObjectId' has the following description: The
     * corresponding object identity of the exchange item
     * 
     * @param dataObjectId the value of field 'dataObjectId'.
     */
    public void setDataObjectId(java.lang.String dataObjectId)
    {
        this._dataObjectId = dataObjectId;
    } //-- void setDataObjectId(java.lang.String) 

    /**
     * Sets the value of field 'elementId'. The field 'elementId'
     * has the following description: The corresponding identity of
     * the exchange item as used internally within the model. If
     * this is not specified, then the elementId will be equal to
     * the specified id.
     * 
     * @param elementId the value of field 'elementId'.
     */
    public void setElementId(java.lang.String elementId)
    {
        this._elementId = elementId;
    } //-- void setElementId(java.lang.String) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Identity of the exchange item vector
     * to be used in the stochastic model configuration. Note: by
     * using the reserved id "allElementsFromIoObject" all the
     * elements in the data/io object are exposed as exchange items
     * (with the element id in the data/io object as id)
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'idSuffix'. The field 'idSuffix' has
     * the following description: Optional. This suffix will be
     * appended to the specified id. If elementId not specified,
     * then the elementId will still be equal to the specified id
     * without this suffix. If id="allElementsFromIoObject", then
     * this suffix will be appended to the ids of all exchangeItems
     * of elements in the ioObject. In that case the elementIds
     * will still be equal to the original ids of the elements in
     * the ioObject, i.e. without this suffix.
     * 
     * @param idSuffix the value of field 'idSuffix'.
     */
    public void setIdSuffix(java.lang.String idSuffix)
    {
        this._idSuffix = idSuffix;
    } //-- void setIdSuffix(java.lang.String) 

    /**
     * Sets the value of field 'ioObjectId'. The field 'ioObjectId'
     * has the following description: Obsolete, please use
     * dataObjectId. The corresponding object identity of the
     * exchange item
     * 
     * @param ioObjectId the value of field 'ioObjectId'.
     */
    public void setIoObjectId(java.lang.String ioObjectId)
    {
        this._ioObjectId = ioObjectId;
    } //-- void setIoObjectId(java.lang.String) 

    /**
     * Sets the value of field 'role'. The field 'role' has the
     * following description: The corresponding role type of the
     * exchange item, choose "Input", "Output" or "InOut"
     * 
     * @param role the value of field 'role'.
     */
    public void setRole(org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML role)
    {
        this._role = role;
    } //-- void setRole(org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML) 

    /**
     * Method unmarshalBlackBoxIoVectorXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxIoVectorXML unmarshalBlackBoxIoVectorXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxIoVectorXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxIoVectorXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxIoVectorXML unmarshalBlackBoxIoVectorXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
