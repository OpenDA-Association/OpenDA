/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class BoundaryMappingXML.
 * 
 * @version $Revision$ $Date$
 */
public class BoundaryMappingXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * (set): Replace model ExchangeItem's content by forcing
     * ExchangeItem's content. (add): Add the forcing
     * ExchangeItem's content to the model ExchangeItem's content.
     * (multiply): Multiply the model ExchangeItem's content by the
     * forcing ExchangeItem's content.
     */
    private org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML _operation;

    /**
     * List the forcing ExchangeItems for which to apply this
     * mapping's operation. If this list is not specified, then the
     * specified operation will be used for all forcing
     * ExchangeItems from the specified file (in that case the
     * model ExchangeItems must have the same ids as the forcing
     * ExchangeItems).
     */
    private java.util.ArrayList _exchangeItemList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BoundaryMappingXML() {
        super();
        _exchangeItemList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BoundaryMappingXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addExchangeItem
     * 
     * @param vExchangeItem
     */
    public void addExchangeItem(org.openda.core.io.castorgenerated.BoundaryExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _exchangeItemList.add(vExchangeItem);
    } //-- void addExchangeItem(org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) 

    /**
     * Method addExchangeItem
     * 
     * @param index
     * @param vExchangeItem
     */
    public void addExchangeItem(int index, org.openda.core.io.castorgenerated.BoundaryExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _exchangeItemList.add(index, vExchangeItem);
    } //-- void addExchangeItem(int, org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) 

    /**
     * Method clearExchangeItem
     */
    public void clearExchangeItem()
    {
        _exchangeItemList.clear();
    } //-- void clearExchangeItem() 

    /**
     * Method enumerateExchangeItem
     */
    public java.util.Enumeration enumerateExchangeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_exchangeItemList.iterator());
    } //-- java.util.Enumeration enumerateExchangeItem() 

    /**
     * Method getExchangeItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BoundaryExchangeItemXML getExchangeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _exchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) _exchangeItemList.get(index);
    } //-- org.openda.core.io.castorgenerated.BoundaryExchangeItemXML getExchangeItem(int) 

    /**
     * Method getExchangeItem
     */
    public org.openda.core.io.castorgenerated.BoundaryExchangeItemXML[] getExchangeItem()
    {
        int size = _exchangeItemList.size();
        org.openda.core.io.castorgenerated.BoundaryExchangeItemXML[] mArray = new org.openda.core.io.castorgenerated.BoundaryExchangeItemXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) _exchangeItemList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BoundaryExchangeItemXML[] getExchangeItem() 

    /**
     * Method getExchangeItemCount
     */
    public int getExchangeItemCount()
    {
        return _exchangeItemList.size();
    } //-- int getExchangeItemCount() 

    /**
     * Returns the value of field 'operation'. The field
     * 'operation' has the following description: (set): Replace
     * model ExchangeItem's content by forcing ExchangeItem's
     * content. (add): Add the forcing ExchangeItem's content to
     * the model ExchangeItem's content. (multiply): Multiply the
     * model ExchangeItem's content by the forcing ExchangeItem's
     * content.
     * 
     * @return the value of field 'operation'.
     */
    public org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML getOperation()
    {
        return this._operation;
    } //-- org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML getOperation() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeExchangeItem
     * 
     * @param vExchangeItem
     */
    public boolean removeExchangeItem(org.openda.core.io.castorgenerated.BoundaryExchangeItemXML vExchangeItem)
    {
        boolean removed = _exchangeItemList.remove(vExchangeItem);
        return removed;
    } //-- boolean removeExchangeItem(org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) 

    /**
     * Method setExchangeItem
     * 
     * @param index
     * @param vExchangeItem
     */
    public void setExchangeItem(int index, org.openda.core.io.castorgenerated.BoundaryExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _exchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _exchangeItemList.set(index, vExchangeItem);
    } //-- void setExchangeItem(int, org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) 

    /**
     * Method setExchangeItem
     * 
     * @param exchangeItemArray
     */
    public void setExchangeItem(org.openda.core.io.castorgenerated.BoundaryExchangeItemXML[] exchangeItemArray)
    {
        //-- copy array
        _exchangeItemList.clear();
        for (int i = 0; i < exchangeItemArray.length; i++) {
            _exchangeItemList.add(exchangeItemArray[i]);
        }
    } //-- void setExchangeItem(org.openda.core.io.castorgenerated.BoundaryExchangeItemXML) 

    /**
     * Sets the value of field 'operation'. The field 'operation'
     * has the following description: (set): Replace model
     * ExchangeItem's content by forcing ExchangeItem's content.
     * (add): Add the forcing ExchangeItem's content to the model
     * ExchangeItem's content. (multiply): Multiply the model
     * ExchangeItem's content by the forcing ExchangeItem's
     * content.
     * 
     * @param operation the value of field 'operation'.
     */
    public void setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML operation)
    {
        this._operation = operation;
    } //-- void setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML) 

    /**
     * Method unmarshalBoundaryMappingXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BoundaryMappingXML unmarshalBoundaryMappingXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BoundaryMappingXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BoundaryMappingXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BoundaryMappingXML unmarshalBoundaryMappingXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
