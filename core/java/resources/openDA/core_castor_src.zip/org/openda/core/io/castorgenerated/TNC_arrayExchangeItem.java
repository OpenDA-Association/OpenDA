/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TNC_arrayExchangeItem.
 * 
 * @version $Revision$ $Date$
 */
public class TNC_arrayExchangeItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id
     */
    private org.openda.core.io.castorgenerated.TNC_id _id;

    /**
     * Field _values
     */
    private org.openda.core.io.castorgenerated.TNC_values _values;


      //----------------/
     //- Constructors -/
    //----------------/

    public TNC_arrayExchangeItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.TNC_arrayExchangeItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'id'.
     */
    public org.openda.core.io.castorgenerated.TNC_id getId()
    {
        return this._id;
    } //-- org.openda.core.io.castorgenerated.TNC_id getId() 

    /**
     * Returns the value of field 'values'.
     * 
     * @return the value of field 'values'.
     */
    public org.openda.core.io.castorgenerated.TNC_values getValues()
    {
        return this._values;
    } //-- org.openda.core.io.castorgenerated.TNC_values getValues() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(org.openda.core.io.castorgenerated.TNC_id id)
    {
        this._id = id;
    } //-- void setId(org.openda.core.io.castorgenerated.TNC_id) 

    /**
     * Sets the value of field 'values'.
     * 
     * @param values the value of field 'values'.
     */
    public void setValues(org.openda.core.io.castorgenerated.TNC_values values)
    {
        this._values = values;
    } //-- void setValues(org.openda.core.io.castorgenerated.TNC_values) 

    /**
     * Method unmarshalTNC_arrayExchangeItem
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TNC_arrayExchangeItem unmarshalTNC_arrayExchangeItem(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TNC_arrayExchangeItem) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TNC_arrayExchangeItem.class, reader);
    } //-- org.openda.core.io.castorgenerated.TNC_arrayExchangeItem unmarshalTNC_arrayExchangeItem(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
