/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TreeVectorLeafXML.
 * 
 * @version $Revision$ $Date$
 */
public class TreeVectorLeafXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id
     */
    private java.lang.String _id;

    /**
     * Field _caption
     */
    private java.lang.String _caption;

    /**
     * Field _excludeFromVector
     */
    private boolean _excludeFromVector;

    /**
     * keeps track of state for field: _excludeFromVector
     */
    private boolean _has_excludeFromVector;

    /**
     * Field _className
     */
    private java.lang.String _className;

    /**
     * Field _unit
     */
    private java.lang.String _unit;

    /**
     * Field _missingValue
     */
    private double _missingValue;

    /**
     * keeps track of state for field: _missingValue
     */
    private boolean _has_missingValue;

    /**
     * Field _treeVectorLeafXMLChoice
     */
    private org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice _treeVectorLeafXMLChoice;

    /**
     * Field _vector
     */
    private java.lang.String _vector;


      //----------------/
     //- Constructors -/
    //----------------/

    public TreeVectorLeafXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.TreeVectorLeafXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteExcludeFromVector
     */
    public void deleteExcludeFromVector()
    {
        this._has_excludeFromVector= false;
    } //-- void deleteExcludeFromVector() 

    /**
     * Method deleteMissingValue
     */
    public void deleteMissingValue()
    {
        this._has_missingValue= false;
    } //-- void deleteMissingValue() 

    /**
     * Returns the value of field 'caption'.
     * 
     * @return the value of field 'caption'.
     */
    public java.lang.String getCaption()
    {
        return this._caption;
    } //-- java.lang.String getCaption() 

    /**
     * Returns the value of field 'className'.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'excludeFromVector'.
     * 
     * @return the value of field 'excludeFromVector'.
     */
    public boolean getExcludeFromVector()
    {
        return this._excludeFromVector;
    } //-- boolean getExcludeFromVector() 

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'missingValue'.
     * 
     * @return the value of field 'missingValue'.
     */
    public double getMissingValue()
    {
        return this._missingValue;
    } //-- double getMissingValue() 

    /**
     * Returns the value of field 'treeVectorLeafXMLChoice'.
     * 
     * @return the value of field 'treeVectorLeafXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice getTreeVectorLeafXMLChoice()
    {
        return this._treeVectorLeafXMLChoice;
    } //-- org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice getTreeVectorLeafXMLChoice() 

    /**
     * Returns the value of field 'unit'.
     * 
     * @return the value of field 'unit'.
     */
    public java.lang.String getUnit()
    {
        return this._unit;
    } //-- java.lang.String getUnit() 

    /**
     * Returns the value of field 'vector'.
     * 
     * @return the value of field 'vector'.
     */
    public java.lang.String getVector()
    {
        return this._vector;
    } //-- java.lang.String getVector() 

    /**
     * Method hasExcludeFromVector
     */
    public boolean hasExcludeFromVector()
    {
        return this._has_excludeFromVector;
    } //-- boolean hasExcludeFromVector() 

    /**
     * Method hasMissingValue
     */
    public boolean hasMissingValue()
    {
        return this._has_missingValue;
    } //-- boolean hasMissingValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'caption'.
     * 
     * @param caption the value of field 'caption'.
     */
    public void setCaption(java.lang.String caption)
    {
        this._caption = caption;
    } //-- void setCaption(java.lang.String) 

    /**
     * Sets the value of field 'className'.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'excludeFromVector'.
     * 
     * @param excludeFromVector the value of field
     * 'excludeFromVector'.
     */
    public void setExcludeFromVector(boolean excludeFromVector)
    {
        this._excludeFromVector = excludeFromVector;
        this._has_excludeFromVector = true;
    } //-- void setExcludeFromVector(boolean) 

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'missingValue'.
     * 
     * @param missingValue the value of field 'missingValue'.
     */
    public void setMissingValue(double missingValue)
    {
        this._missingValue = missingValue;
        this._has_missingValue = true;
    } //-- void setMissingValue(double) 

    /**
     * Sets the value of field 'treeVectorLeafXMLChoice'.
     * 
     * @param treeVectorLeafXMLChoice the value of field
     * 'treeVectorLeafXMLChoice'.
     */
    public void setTreeVectorLeafXMLChoice(org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice treeVectorLeafXMLChoice)
    {
        this._treeVectorLeafXMLChoice = treeVectorLeafXMLChoice;
    } //-- void setTreeVectorLeafXMLChoice(org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice) 

    /**
     * Sets the value of field 'unit'.
     * 
     * @param unit the value of field 'unit'.
     */
    public void setUnit(java.lang.String unit)
    {
        this._unit = unit;
    } //-- void setUnit(java.lang.String) 

    /**
     * Sets the value of field 'vector'.
     * 
     * @param vector the value of field 'vector'.
     */
    public void setVector(java.lang.String vector)
    {
        this._vector = vector;
    } //-- void setVector(java.lang.String) 

    /**
     * Method unmarshalTreeVectorLeafXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TreeVectorLeafXML unmarshalTreeVectorLeafXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TreeVectorLeafXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TreeVectorLeafXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TreeVectorLeafXML unmarshalTreeVectorLeafXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
