/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.RestartFormatTypesXML;
import org.xml.sax.ContentHandler;

/**
 * A list of one or more times separated by comma's ','
 *  Eg. 201012312359,201101012359
 *  or 1.0,2.0,...,10.0
 *  Formatted dates require format YYYMMDDhhmm.
 *  Three dots can be used to shorten a regular list
 *  
 * 
 * @version $Revision$ $Date$
 */
public class RestartOutFileTimesXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * internal content storage
     */
    private java.lang.String _content = "";

    /**
     * Specify the time format: 'mjd' (Modified Julian Day) or
     * date/time string (formatted as yyyymmddhhmm)
     * 'dateTimeString'.
     *  
     */
    private org.openda.core.io.castorgenerated.types.RestartFormatTypesXML _timeFormat = org.openda.core.io.castorgenerated.types.RestartFormatTypesXML.valueOf("dateTimeString");


      //----------------/
     //- Constructors -/
    //----------------/

    public RestartOutFileTimesXML() {
        super();
        setContent("");
        setTimeFormat(org.openda.core.io.castorgenerated.types.RestartFormatTypesXML.valueOf("dateTimeString"));
    } //-- org.openda.core.io.castorgenerated.RestartOutFileTimesXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'content'. The field 'content'
     * has the following description: internal content storage
     * 
     * @return the value of field 'content'.
     */
    public java.lang.String getContent()
    {
        return this._content;
    } //-- java.lang.String getContent() 

    /**
     * Returns the value of field 'timeFormat'. The field
     * 'timeFormat' has the following description: Specify the time
     * format: 'mjd' (Modified Julian Day) or date/time string
     * (formatted as yyyymmddhhmm) 'dateTimeString'.
     *  
     * 
     * @return the value of field 'timeFormat'.
     */
    public org.openda.core.io.castorgenerated.types.RestartFormatTypesXML getTimeFormat()
    {
        return this._timeFormat;
    } //-- org.openda.core.io.castorgenerated.types.RestartFormatTypesXML getTimeFormat() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'content'. The field 'content' has
     * the following description: internal content storage
     * 
     * @param content the value of field 'content'.
     */
    public void setContent(java.lang.String content)
    {
        this._content = content;
    } //-- void setContent(java.lang.String) 

    /**
     * Sets the value of field 'timeFormat'. The field 'timeFormat'
     * has the following description: Specify the time format:
     * 'mjd' (Modified Julian Day) or date/time string (formatted
     * as yyyymmddhhmm) 'dateTimeString'.
     *  
     * 
     * @param timeFormat the value of field 'timeFormat'.
     */
    public void setTimeFormat(org.openda.core.io.castorgenerated.types.RestartFormatTypesXML timeFormat)
    {
        this._timeFormat = timeFormat;
    } //-- void setTimeFormat(org.openda.core.io.castorgenerated.types.RestartFormatTypesXML) 

    /**
     * Method unmarshalRestartOutFileTimesXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.RestartOutFileTimesXML unmarshalRestartOutFileTimesXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.RestartOutFileTimesXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.RestartOutFileTimesXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.RestartOutFileTimesXML unmarshalRestartOutFileTimesXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
