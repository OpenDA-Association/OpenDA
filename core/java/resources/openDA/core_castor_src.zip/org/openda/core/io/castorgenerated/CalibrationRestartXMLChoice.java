/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class CalibrationRestartXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class CalibrationRestartXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _dud
     */
    private org.openda.core.io.castorgenerated.DudXML _dud;

    /**
     * Field _powell
     */
    private org.openda.core.io.castorgenerated.PowellXML _powell;

    /**
     * Field _simplex
     */
    private org.openda.core.io.castorgenerated.SimplexXML _simplex;


      //----------------/
     //- Constructors -/
    //----------------/

    public CalibrationRestartXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.CalibrationRestartXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dud'.
     * 
     * @return the value of field 'dud'.
     */
    public org.openda.core.io.castorgenerated.DudXML getDud()
    {
        return this._dud;
    } //-- org.openda.core.io.castorgenerated.DudXML getDud() 

    /**
     * Returns the value of field 'powell'.
     * 
     * @return the value of field 'powell'.
     */
    public org.openda.core.io.castorgenerated.PowellXML getPowell()
    {
        return this._powell;
    } //-- org.openda.core.io.castorgenerated.PowellXML getPowell() 

    /**
     * Returns the value of field 'simplex'.
     * 
     * @return the value of field 'simplex'.
     */
    public org.openda.core.io.castorgenerated.SimplexXML getSimplex()
    {
        return this._simplex;
    } //-- org.openda.core.io.castorgenerated.SimplexXML getSimplex() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dud'.
     * 
     * @param dud the value of field 'dud'.
     */
    public void setDud(org.openda.core.io.castorgenerated.DudXML dud)
    {
        this._dud = dud;
    } //-- void setDud(org.openda.core.io.castorgenerated.DudXML) 

    /**
     * Sets the value of field 'powell'.
     * 
     * @param powell the value of field 'powell'.
     */
    public void setPowell(org.openda.core.io.castorgenerated.PowellXML powell)
    {
        this._powell = powell;
    } //-- void setPowell(org.openda.core.io.castorgenerated.PowellXML) 

    /**
     * Sets the value of field 'simplex'.
     * 
     * @param simplex the value of field 'simplex'.
     */
    public void setSimplex(org.openda.core.io.castorgenerated.SimplexXML simplex)
    {
        this._simplex = simplex;
    } //-- void setSimplex(org.openda.core.io.castorgenerated.SimplexXML) 

    /**
     * Method unmarshalCalibrationRestartXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.CalibrationRestartXMLChoice unmarshalCalibrationRestartXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.CalibrationRestartXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.CalibrationRestartXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.CalibrationRestartXMLChoice unmarshalCalibrationRestartXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
