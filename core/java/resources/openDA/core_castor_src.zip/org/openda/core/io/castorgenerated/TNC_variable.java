/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TNC_variable.
 * 
 * @version $Revision$ $Date$
 */
public class TNC_variable implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _name
     */
    private java.lang.String _name;

    /**
     * Field _value
     */
    private java.lang.String _value;

    /**
     * Field _dimensionList
     */
    private java.util.ArrayList _dimensionList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TNC_variable() {
        super();
        _dimensionList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.TNC_variable()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addDimension
     * 
     * @param vDimension
     */
    public void addDimension(org.openda.core.io.castorgenerated.TNC_dimension vDimension)
        throws java.lang.IndexOutOfBoundsException
    {
        _dimensionList.add(vDimension);
    } //-- void addDimension(org.openda.core.io.castorgenerated.TNC_dimension) 

    /**
     * Method addDimension
     * 
     * @param index
     * @param vDimension
     */
    public void addDimension(int index, org.openda.core.io.castorgenerated.TNC_dimension vDimension)
        throws java.lang.IndexOutOfBoundsException
    {
        _dimensionList.add(index, vDimension);
    } //-- void addDimension(int, org.openda.core.io.castorgenerated.TNC_dimension) 

    /**
     * Method clearDimension
     */
    public void clearDimension()
    {
        _dimensionList.clear();
    } //-- void clearDimension() 

    /**
     * Method enumerateDimension
     */
    public java.util.Enumeration enumerateDimension()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_dimensionList.iterator());
    } //-- java.util.Enumeration enumerateDimension() 

    /**
     * Method getDimension
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TNC_dimension getDimension(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dimensionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TNC_dimension) _dimensionList.get(index);
    } //-- org.openda.core.io.castorgenerated.TNC_dimension getDimension(int) 

    /**
     * Method getDimension
     */
    public org.openda.core.io.castorgenerated.TNC_dimension[] getDimension()
    {
        int size = _dimensionList.size();
        org.openda.core.io.castorgenerated.TNC_dimension[] mArray = new org.openda.core.io.castorgenerated.TNC_dimension[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TNC_dimension) _dimensionList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TNC_dimension[] getDimension() 

    /**
     * Method getDimensionCount
     */
    public int getDimensionCount()
    {
        return _dimensionList.size();
    } //-- int getDimensionCount() 

    /**
     * Returns the value of field 'name'.
     * 
     * @return the value of field 'name'.
     */
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName() 

    /**
     * Returns the value of field 'value'.
     * 
     * @return the value of field 'value'.
     */
    public java.lang.String getValue()
    {
        return this._value;
    } //-- java.lang.String getValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeDimension
     * 
     * @param vDimension
     */
    public boolean removeDimension(org.openda.core.io.castorgenerated.TNC_dimension vDimension)
    {
        boolean removed = _dimensionList.remove(vDimension);
        return removed;
    } //-- boolean removeDimension(org.openda.core.io.castorgenerated.TNC_dimension) 

    /**
     * Method setDimension
     * 
     * @param index
     * @param vDimension
     */
    public void setDimension(int index, org.openda.core.io.castorgenerated.TNC_dimension vDimension)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dimensionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _dimensionList.set(index, vDimension);
    } //-- void setDimension(int, org.openda.core.io.castorgenerated.TNC_dimension) 

    /**
     * Method setDimension
     * 
     * @param dimensionArray
     */
    public void setDimension(org.openda.core.io.castorgenerated.TNC_dimension[] dimensionArray)
    {
        //-- copy array
        _dimensionList.clear();
        for (int i = 0; i < dimensionArray.length; i++) {
            _dimensionList.add(dimensionArray[i]);
        }
    } //-- void setDimension(org.openda.core.io.castorgenerated.TNC_dimension) 

    /**
     * Sets the value of field 'name'.
     * 
     * @param name the value of field 'name'.
     */
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String) 

    /**
     * Sets the value of field 'value'.
     * 
     * @param value the value of field 'value'.
     */
    public void setValue(java.lang.String value)
    {
        this._value = value;
    } //-- void setValue(java.lang.String) 

    /**
     * Method unmarshalTNC_variable
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TNC_variable unmarshalTNC_variable(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TNC_variable) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TNC_variable.class, reader);
    } //-- org.openda.core.io.castorgenerated.TNC_variable unmarshalTNC_variable(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
