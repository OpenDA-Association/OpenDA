/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class RangeValidationConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class RangeValidationConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * One or more constraints that constrain the values of certain
     * exchange items. If a constraint is applied on a given
     * sourceExchangeItem, then a new targetExchangeIitem is
     * created with the specified constraint and an id that is the
     * sourceExchangeItemId with the configured suffix appended. To
     * use the targetExchangeItem in other parts of the
     * configuration refer to it using its own id. It is also
     * possible to apply multiple constraints on a given
     * exchangeItem recursively. This can be done by configuring a
     * constraint that works on a targetExchangeItem from another
     * constraint. If multiple constraints are applied to a given
     * exchangeItem recursively, then the outermost constraint is
     * applied first.
     */
    private java.util.ArrayList _constraintList;


      //----------------/
     //- Constructors -/
    //----------------/

    public RangeValidationConfigXML() {
        super();
        _constraintList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.RangeValidationConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addConstraint
     * 
     * @param vConstraint
     */
    public void addConstraint(org.openda.core.io.castorgenerated.RangeValidationConstraintXML vConstraint)
        throws java.lang.IndexOutOfBoundsException
    {
        _constraintList.add(vConstraint);
    } //-- void addConstraint(org.openda.core.io.castorgenerated.RangeValidationConstraintXML) 

    /**
     * Method addConstraint
     * 
     * @param index
     * @param vConstraint
     */
    public void addConstraint(int index, org.openda.core.io.castorgenerated.RangeValidationConstraintXML vConstraint)
        throws java.lang.IndexOutOfBoundsException
    {
        _constraintList.add(index, vConstraint);
    } //-- void addConstraint(int, org.openda.core.io.castorgenerated.RangeValidationConstraintXML) 

    /**
     * Method clearConstraint
     */
    public void clearConstraint()
    {
        _constraintList.clear();
    } //-- void clearConstraint() 

    /**
     * Method enumerateConstraint
     */
    public java.util.Enumeration enumerateConstraint()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_constraintList.iterator());
    } //-- java.util.Enumeration enumerateConstraint() 

    /**
     * Method getConstraint
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.RangeValidationConstraintXML getConstraint(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _constraintList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.RangeValidationConstraintXML) _constraintList.get(index);
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstraintXML getConstraint(int) 

    /**
     * Method getConstraint
     */
    public org.openda.core.io.castorgenerated.RangeValidationConstraintXML[] getConstraint()
    {
        int size = _constraintList.size();
        org.openda.core.io.castorgenerated.RangeValidationConstraintXML[] mArray = new org.openda.core.io.castorgenerated.RangeValidationConstraintXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.RangeValidationConstraintXML) _constraintList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.RangeValidationConstraintXML[] getConstraint() 

    /**
     * Method getConstraintCount
     */
    public int getConstraintCount()
    {
        return _constraintList.size();
    } //-- int getConstraintCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeConstraint
     * 
     * @param vConstraint
     */
    public boolean removeConstraint(org.openda.core.io.castorgenerated.RangeValidationConstraintXML vConstraint)
    {
        boolean removed = _constraintList.remove(vConstraint);
        return removed;
    } //-- boolean removeConstraint(org.openda.core.io.castorgenerated.RangeValidationConstraintXML) 

    /**
     * Method setConstraint
     * 
     * @param index
     * @param vConstraint
     */
    public void setConstraint(int index, org.openda.core.io.castorgenerated.RangeValidationConstraintXML vConstraint)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _constraintList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _constraintList.set(index, vConstraint);
    } //-- void setConstraint(int, org.openda.core.io.castorgenerated.RangeValidationConstraintXML) 

    /**
     * Method setConstraint
     * 
     * @param constraintArray
     */
    public void setConstraint(org.openda.core.io.castorgenerated.RangeValidationConstraintXML[] constraintArray)
    {
        //-- copy array
        _constraintList.clear();
        for (int i = 0; i < constraintArray.length; i++) {
            _constraintList.add(constraintArray[i]);
        }
    } //-- void setConstraint(org.openda.core.io.castorgenerated.RangeValidationConstraintXML) 

    /**
     * Method unmarshalRangeValidationConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.RangeValidationConfigXML unmarshalRangeValidationConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.RangeValidationConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.RangeValidationConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.RangeValidationConfigXML unmarshalRangeValidationConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
