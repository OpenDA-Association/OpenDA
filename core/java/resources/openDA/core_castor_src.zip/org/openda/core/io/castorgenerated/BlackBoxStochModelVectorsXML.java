/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelVectorsXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelVectorsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * A flag for indicating whether predictor timeseries should be
     * kept in the memory during simulation.
     */
    private boolean _collectTimeSeries = false;

    /**
     * keeps track of state for field: _collectTimeSeries
     */
    private boolean _has_collectTimeSeries;

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelVectorsXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBlackBoxStochModelVectorsXMLItem
     * 
     * @param vBlackBoxStochModelVectorsXMLItem
     */
    public void addBlackBoxStochModelVectorsXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem vBlackBoxStochModelVectorsXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vBlackBoxStochModelVectorsXMLItem);
    } //-- void addBlackBoxStochModelVectorsXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) 

    /**
     * Method addBlackBoxStochModelVectorsXMLItem
     * 
     * @param index
     * @param vBlackBoxStochModelVectorsXMLItem
     */
    public void addBlackBoxStochModelVectorsXMLItem(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem vBlackBoxStochModelVectorsXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vBlackBoxStochModelVectorsXMLItem);
    } //-- void addBlackBoxStochModelVectorsXMLItem(int, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) 

    /**
     * Method clearBlackBoxStochModelVectorsXMLItem
     */
    public void clearBlackBoxStochModelVectorsXMLItem()
    {
        _items.clear();
    } //-- void clearBlackBoxStochModelVectorsXMLItem() 

    /**
     * Method deleteCollectTimeSeries
     */
    public void deleteCollectTimeSeries()
    {
        this._has_collectTimeSeries= false;
    } //-- void deleteCollectTimeSeries() 

    /**
     * Method enumerateBlackBoxStochModelVectorsXMLItem
     */
    public java.util.Enumeration enumerateBlackBoxStochModelVectorsXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateBlackBoxStochModelVectorsXMLItem() 

    /**
     * Method getBlackBoxStochModelVectorsXMLItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem getBlackBoxStochModelVectorsXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) _items.get(index);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem getBlackBoxStochModelVectorsXMLItem(int) 

    /**
     * Method getBlackBoxStochModelVectorsXMLItem
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem[] getBlackBoxStochModelVectorsXMLItem()
    {
        int size = _items.size();
        org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem[] mArray = new org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem[] getBlackBoxStochModelVectorsXMLItem() 

    /**
     * Method getBlackBoxStochModelVectorsXMLItemCount
     */
    public int getBlackBoxStochModelVectorsXMLItemCount()
    {
        return _items.size();
    } //-- int getBlackBoxStochModelVectorsXMLItemCount() 

    /**
     * Returns the value of field 'collectTimeSeries'. The field
     * 'collectTimeSeries' has the following description: A flag
     * for indicating whether predictor timeseries should be kept
     * in the memory during simulation.
     * 
     * @return the value of field 'collectTimeSeries'.
     */
    public boolean getCollectTimeSeries()
    {
        return this._collectTimeSeries;
    } //-- boolean getCollectTimeSeries() 

    /**
     * Method hasCollectTimeSeries
     */
    public boolean hasCollectTimeSeries()
    {
        return this._has_collectTimeSeries;
    } //-- boolean hasCollectTimeSeries() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBlackBoxStochModelVectorsXMLItem
     * 
     * @param vBlackBoxStochModelVectorsXMLItem
     */
    public boolean removeBlackBoxStochModelVectorsXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem vBlackBoxStochModelVectorsXMLItem)
    {
        boolean removed = _items.remove(vBlackBoxStochModelVectorsXMLItem);
        return removed;
    } //-- boolean removeBlackBoxStochModelVectorsXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) 

    /**
     * Method setBlackBoxStochModelVectorsXMLItem
     * 
     * @param index
     * @param vBlackBoxStochModelVectorsXMLItem
     */
    public void setBlackBoxStochModelVectorsXMLItem(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem vBlackBoxStochModelVectorsXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vBlackBoxStochModelVectorsXMLItem);
    } //-- void setBlackBoxStochModelVectorsXMLItem(int, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) 

    /**
     * Method setBlackBoxStochModelVectorsXMLItem
     * 
     * @param blackBoxStochModelVectorsXMLItemArray
     */
    public void setBlackBoxStochModelVectorsXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem[] blackBoxStochModelVectorsXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < blackBoxStochModelVectorsXMLItemArray.length; i++) {
            _items.add(blackBoxStochModelVectorsXMLItemArray[i]);
        }
    } //-- void setBlackBoxStochModelVectorsXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXMLItem) 

    /**
     * Sets the value of field 'collectTimeSeries'. The field
     * 'collectTimeSeries' has the following description: A flag
     * for indicating whether predictor timeseries should be kept
     * in the memory during simulation.
     * 
     * @param collectTimeSeries the value of field
     * 'collectTimeSeries'.
     */
    public void setCollectTimeSeries(boolean collectTimeSeries)
    {
        this._collectTimeSeries = collectTimeSeries;
        this._has_collectTimeSeries = true;
    } //-- void setCollectTimeSeries(boolean) 

    /**
     * Method unmarshalBlackBoxStochModelVectorsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML unmarshalBlackBoxStochModelVectorsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML unmarshalBlackBoxStochModelVectorsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
