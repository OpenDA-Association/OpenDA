/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class PowellXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class PowellXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _baseParams
     */
    private org.openda.core.io.castorgenerated.TreeVectorXML _baseParams;

    /**
     * Field _baseParamVector
     */
    private java.lang.String _baseParamVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public PowellXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.PowellXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'baseParamVector'.
     * 
     * @return the value of field 'baseParamVector'.
     */
    public java.lang.String getBaseParamVector()
    {
        return this._baseParamVector;
    } //-- java.lang.String getBaseParamVector() 

    /**
     * Returns the value of field 'baseParams'.
     * 
     * @return the value of field 'baseParams'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXML getBaseParams()
    {
        return this._baseParams;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML getBaseParams() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'baseParamVector'.
     * 
     * @param baseParamVector the value of field 'baseParamVector'.
     */
    public void setBaseParamVector(java.lang.String baseParamVector)
    {
        this._baseParamVector = baseParamVector;
    } //-- void setBaseParamVector(java.lang.String) 

    /**
     * Sets the value of field 'baseParams'.
     * 
     * @param baseParams the value of field 'baseParams'.
     */
    public void setBaseParams(org.openda.core.io.castorgenerated.TreeVectorXML baseParams)
    {
        this._baseParams = baseParams;
    } //-- void setBaseParams(org.openda.core.io.castorgenerated.TreeVectorXML) 

    /**
     * Method unmarshalPowellXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.PowellXMLChoice unmarshalPowellXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.PowellXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.PowellXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.PowellXMLChoice unmarshalPowellXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
