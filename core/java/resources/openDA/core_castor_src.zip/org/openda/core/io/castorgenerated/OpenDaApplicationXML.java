/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class OpenDaApplicationXML.
 * 
 * @version $Revision$ $Date$
 */
public class OpenDaApplicationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the stochastic observer component
     */
    private org.openda.core.io.castorgenerated.OpenDaStochObserverXML _stochObserver;

    /**
     * Specify the stochastic model component
     */
    private org.openda.core.io.castorgenerated.OpenDaStochModelXML _stochModelFactory;

    /**
     * Specify the algorithm for data assimilation or parameter
     * calibration
     */
    private org.openda.core.io.castorgenerated.OpenDaAlgorithmXML _algorithm;

    /**
     * Specify the content and format of the results file
     */
    private org.openda.core.io.castorgenerated.OpenDaResultWriterXML _resultWriter;

    /**
     * Specify the results files in case more than one format is
     * needed
     */
    private org.openda.core.io.castorgenerated.OpenDaResultWritersXML _resultWriters;

    /**
     * Specify the input file from which the algoritm should
     * restart. If omitted, no restart file is read. A restartFile
     * of length zero is silently ignored and can be used to ignore
     * the restart, ie to start without a restart.
     */
    private java.lang.String _restartInFile;

    /**
     * Specify the prefix to be used for the output restart files
     * to be written. If ommitted, no restart files are written.
     */
    private java.lang.String _restartOutFilePrefix;

    /**
     * Specify the file extension to be used for restart output
     * files (default: .xml). Overrules only the extension, but not
     * the output format chosen by Openda (could be a zip file as
     * well). Use of this option is discouraged.
     */
    private java.lang.String _restartOutFileExtension = ".xml";

    /**
     * Should the restart time be added to the filename of the
     * restart file. 
     *  Default is yes. Possible values: yes, no
     */
    private java.lang.String _restartOutFileTimeTag = "yes";

    /**
     * Specify the time stamps for which to write restarts
     */
    private org.openda.core.io.castorgenerated.RestartOutFileTimesXML _restartOutFileTimes;

    /**
     * When true, only at the end of the run restart files are
     * written and not at every analysis step. Do not use this
     * element in combination with the restartOutFileTimes
     */
    private boolean _restartOutFileOnlyAtEndOfRun;

    /**
     * keeps track of state for field: _restartOutFileOnlyAtEndOfRun
     */
    private boolean _has_restartOutFileOnlyAtEndOfRun;

    /**
     * Specify the settings for the run time timing
     */
    private org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML _timingSettings;

    /**
     * Specify the optimization settings
     */
    private org.openda.core.io.castorgenerated.ApplicationOptimizationXML _optimizationSettings;

    /**
     * Specify the time settings
     */
    private org.openda.core.io.castorgenerated.ApplicationTimeXML _timeSettings;

    /**
     * Specify the type of initial seed (if ommited, default:
     * "fixed")
     */
    private org.openda.core.io.castorgenerated.ApplicationInitialSeedXML _initialSeed;


      //----------------/
     //- Constructors -/
    //----------------/

    public OpenDaApplicationXML() {
        super();
        setRestartOutFileExtension(".xml");
        setRestartOutFileTimeTag("yes");
    } //-- org.openda.core.io.castorgenerated.OpenDaApplicationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteRestartOutFileOnlyAtEndOfRun
     */
    public void deleteRestartOutFileOnlyAtEndOfRun()
    {
        this._has_restartOutFileOnlyAtEndOfRun= false;
    } //-- void deleteRestartOutFileOnlyAtEndOfRun() 

    /**
     * Returns the value of field 'algorithm'. The field
     * 'algorithm' has the following description: Specify the
     * algorithm for data assimilation or parameter calibration
     * 
     * @return the value of field 'algorithm'.
     */
    public org.openda.core.io.castorgenerated.OpenDaAlgorithmXML getAlgorithm()
    {
        return this._algorithm;
    } //-- org.openda.core.io.castorgenerated.OpenDaAlgorithmXML getAlgorithm() 

    /**
     * Returns the value of field 'initialSeed'. The field
     * 'initialSeed' has the following description: Specify the
     * type of initial seed (if ommited, default: "fixed")
     * 
     * @return the value of field 'initialSeed'.
     */
    public org.openda.core.io.castorgenerated.ApplicationInitialSeedXML getInitialSeed()
    {
        return this._initialSeed;
    } //-- org.openda.core.io.castorgenerated.ApplicationInitialSeedXML getInitialSeed() 

    /**
     * Returns the value of field 'optimizationSettings'. The field
     * 'optimizationSettings' has the following description:
     * Specify the optimization settings
     * 
     * @return the value of field 'optimizationSettings'.
     */
    public org.openda.core.io.castorgenerated.ApplicationOptimizationXML getOptimizationSettings()
    {
        return this._optimizationSettings;
    } //-- org.openda.core.io.castorgenerated.ApplicationOptimizationXML getOptimizationSettings() 

    /**
     * Returns the value of field 'restartInFile'. The field
     * 'restartInFile' has the following description: Specify the
     * input file from which the algoritm should restart. If
     * omitted, no restart file is read. A restartFile of length
     * zero is silently ignored and can be used to ignore the
     * restart, ie to start without a restart.
     * 
     * @return the value of field 'restartInFile'.
     */
    public java.lang.String getRestartInFile()
    {
        return this._restartInFile;
    } //-- java.lang.String getRestartInFile() 

    /**
     * Returns the value of field 'restartOutFileExtension'. The
     * field 'restartOutFileExtension' has the following
     * description: Specify the file extension to be used for
     * restart output files (default: .xml). Overrules only the
     * extension, but not the output format chosen by Openda (could
     * be a zip file as well). Use of this option is discouraged.
     * 
     * @return the value of field 'restartOutFileExtension'.
     */
    public java.lang.String getRestartOutFileExtension()
    {
        return this._restartOutFileExtension;
    } //-- java.lang.String getRestartOutFileExtension() 

    /**
     * Returns the value of field 'restartOutFileOnlyAtEndOfRun'.
     * The field 'restartOutFileOnlyAtEndOfRun' has the following
     * description: When true, only at the end of the run restart
     * files are written and not at every analysis step. Do not use
     * this element in combination with the restartOutFileTimes
     * 
     * @return the value of field 'restartOutFileOnlyAtEndOfRun'.
     */
    public boolean getRestartOutFileOnlyAtEndOfRun()
    {
        return this._restartOutFileOnlyAtEndOfRun;
    } //-- boolean getRestartOutFileOnlyAtEndOfRun() 

    /**
     * Returns the value of field 'restartOutFilePrefix'. The field
     * 'restartOutFilePrefix' has the following description:
     * Specify the prefix to be used for the output restart files
     * to be written. If ommitted, no restart files are written.
     * 
     * @return the value of field 'restartOutFilePrefix'.
     */
    public java.lang.String getRestartOutFilePrefix()
    {
        return this._restartOutFilePrefix;
    } //-- java.lang.String getRestartOutFilePrefix() 

    /**
     * Returns the value of field 'restartOutFileTimeTag'. The
     * field 'restartOutFileTimeTag' has the following description:
     * Should the restart time be added to the filename of the
     * restart file. 
     *  Default is yes. Possible values: yes, no
     * 
     * @return the value of field 'restartOutFileTimeTag'.
     */
    public java.lang.String getRestartOutFileTimeTag()
    {
        return this._restartOutFileTimeTag;
    } //-- java.lang.String getRestartOutFileTimeTag() 

    /**
     * Returns the value of field 'restartOutFileTimes'. The field
     * 'restartOutFileTimes' has the following description: Specify
     * the time stamps for which to write restarts
     * 
     * @return the value of field 'restartOutFileTimes'.
     */
    public org.openda.core.io.castorgenerated.RestartOutFileTimesXML getRestartOutFileTimes()
    {
        return this._restartOutFileTimes;
    } //-- org.openda.core.io.castorgenerated.RestartOutFileTimesXML getRestartOutFileTimes() 

    /**
     * Returns the value of field 'resultWriter'. The field
     * 'resultWriter' has the following description: Specify the
     * content and format of the results file
     * 
     * @return the value of field 'resultWriter'.
     */
    public org.openda.core.io.castorgenerated.OpenDaResultWriterXML getResultWriter()
    {
        return this._resultWriter;
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWriterXML getResultWriter() 

    /**
     * Returns the value of field 'resultWriters'. The field
     * 'resultWriters' has the following description: Specify the
     * results files in case more than one format is needed
     * 
     * @return the value of field 'resultWriters'.
     */
    public org.openda.core.io.castorgenerated.OpenDaResultWritersXML getResultWriters()
    {
        return this._resultWriters;
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWritersXML getResultWriters() 

    /**
     * Returns the value of field 'stochModelFactory'. The field
     * 'stochModelFactory' has the following description: Specify
     * the stochastic model component
     * 
     * @return the value of field 'stochModelFactory'.
     */
    public org.openda.core.io.castorgenerated.OpenDaStochModelXML getStochModelFactory()
    {
        return this._stochModelFactory;
    } //-- org.openda.core.io.castorgenerated.OpenDaStochModelXML getStochModelFactory() 

    /**
     * Returns the value of field 'stochObserver'. The field
     * 'stochObserver' has the following description: Specify the
     * stochastic observer component
     * 
     * @return the value of field 'stochObserver'.
     */
    public org.openda.core.io.castorgenerated.OpenDaStochObserverXML getStochObserver()
    {
        return this._stochObserver;
    } //-- org.openda.core.io.castorgenerated.OpenDaStochObserverXML getStochObserver() 

    /**
     * Returns the value of field 'timeSettings'. The field
     * 'timeSettings' has the following description: Specify the
     * time settings
     * 
     * @return the value of field 'timeSettings'.
     */
    public org.openda.core.io.castorgenerated.ApplicationTimeXML getTimeSettings()
    {
        return this._timeSettings;
    } //-- org.openda.core.io.castorgenerated.ApplicationTimeXML getTimeSettings() 

    /**
     * Returns the value of field 'timingSettings'. The field
     * 'timingSettings' has the following description: Specify the
     * settings for the run time timing
     * 
     * @return the value of field 'timingSettings'.
     */
    public org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML getTimingSettings()
    {
        return this._timingSettings;
    } //-- org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML getTimingSettings() 

    /**
     * Method hasRestartOutFileOnlyAtEndOfRun
     */
    public boolean hasRestartOutFileOnlyAtEndOfRun()
    {
        return this._has_restartOutFileOnlyAtEndOfRun;
    } //-- boolean hasRestartOutFileOnlyAtEndOfRun() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'algorithm'. The field 'algorithm'
     * has the following description: Specify the algorithm for
     * data assimilation or parameter calibration
     * 
     * @param algorithm the value of field 'algorithm'.
     */
    public void setAlgorithm(org.openda.core.io.castorgenerated.OpenDaAlgorithmXML algorithm)
    {
        this._algorithm = algorithm;
    } //-- void setAlgorithm(org.openda.core.io.castorgenerated.OpenDaAlgorithmXML) 

    /**
     * Sets the value of field 'initialSeed'. The field
     * 'initialSeed' has the following description: Specify the
     * type of initial seed (if ommited, default: "fixed")
     * 
     * @param initialSeed the value of field 'initialSeed'.
     */
    public void setInitialSeed(org.openda.core.io.castorgenerated.ApplicationInitialSeedXML initialSeed)
    {
        this._initialSeed = initialSeed;
    } //-- void setInitialSeed(org.openda.core.io.castorgenerated.ApplicationInitialSeedXML) 

    /**
     * Sets the value of field 'optimizationSettings'. The field
     * 'optimizationSettings' has the following description:
     * Specify the optimization settings
     * 
     * @param optimizationSettings the value of field
     * 'optimizationSettings'.
     */
    public void setOptimizationSettings(org.openda.core.io.castorgenerated.ApplicationOptimizationXML optimizationSettings)
    {
        this._optimizationSettings = optimizationSettings;
    } //-- void setOptimizationSettings(org.openda.core.io.castorgenerated.ApplicationOptimizationXML) 

    /**
     * Sets the value of field 'restartInFile'. The field
     * 'restartInFile' has the following description: Specify the
     * input file from which the algoritm should restart. If
     * omitted, no restart file is read. A restartFile of length
     * zero is silently ignored and can be used to ignore the
     * restart, ie to start without a restart.
     * 
     * @param restartInFile the value of field 'restartInFile'.
     */
    public void setRestartInFile(java.lang.String restartInFile)
    {
        this._restartInFile = restartInFile;
    } //-- void setRestartInFile(java.lang.String) 

    /**
     * Sets the value of field 'restartOutFileExtension'. The field
     * 'restartOutFileExtension' has the following description:
     * Specify the file extension to be used for restart output
     * files (default: .xml). Overrules only the extension, but not
     * the output format chosen by Openda (could be a zip file as
     * well). Use of this option is discouraged.
     * 
     * @param restartOutFileExtension the value of field
     * 'restartOutFileExtension'.
     */
    public void setRestartOutFileExtension(java.lang.String restartOutFileExtension)
    {
        this._restartOutFileExtension = restartOutFileExtension;
    } //-- void setRestartOutFileExtension(java.lang.String) 

    /**
     * Sets the value of field 'restartOutFileOnlyAtEndOfRun'. The
     * field 'restartOutFileOnlyAtEndOfRun' has the following
     * description: When true, only at the end of the run restart
     * files are written and not at every analysis step. Do not use
     * this element in combination with the restartOutFileTimes
     * 
     * @param restartOutFileOnlyAtEndOfRun the value of field
     * 'restartOutFileOnlyAtEndOfRun'.
     */
    public void setRestartOutFileOnlyAtEndOfRun(boolean restartOutFileOnlyAtEndOfRun)
    {
        this._restartOutFileOnlyAtEndOfRun = restartOutFileOnlyAtEndOfRun;
        this._has_restartOutFileOnlyAtEndOfRun = true;
    } //-- void setRestartOutFileOnlyAtEndOfRun(boolean) 

    /**
     * Sets the value of field 'restartOutFilePrefix'. The field
     * 'restartOutFilePrefix' has the following description:
     * Specify the prefix to be used for the output restart files
     * to be written. If ommitted, no restart files are written.
     * 
     * @param restartOutFilePrefix the value of field
     * 'restartOutFilePrefix'.
     */
    public void setRestartOutFilePrefix(java.lang.String restartOutFilePrefix)
    {
        this._restartOutFilePrefix = restartOutFilePrefix;
    } //-- void setRestartOutFilePrefix(java.lang.String) 

    /**
     * Sets the value of field 'restartOutFileTimeTag'. The field
     * 'restartOutFileTimeTag' has the following description:
     * Should the restart time be added to the filename of the
     * restart file. 
     *  Default is yes. Possible values: yes, no
     * 
     * @param restartOutFileTimeTag the value of field
     * 'restartOutFileTimeTag'.
     */
    public void setRestartOutFileTimeTag(java.lang.String restartOutFileTimeTag)
    {
        this._restartOutFileTimeTag = restartOutFileTimeTag;
    } //-- void setRestartOutFileTimeTag(java.lang.String) 

    /**
     * Sets the value of field 'restartOutFileTimes'. The field
     * 'restartOutFileTimes' has the following description: Specify
     * the time stamps for which to write restarts
     * 
     * @param restartOutFileTimes the value of field
     * 'restartOutFileTimes'.
     */
    public void setRestartOutFileTimes(org.openda.core.io.castorgenerated.RestartOutFileTimesXML restartOutFileTimes)
    {
        this._restartOutFileTimes = restartOutFileTimes;
    } //-- void setRestartOutFileTimes(org.openda.core.io.castorgenerated.RestartOutFileTimesXML) 

    /**
     * Sets the value of field 'resultWriter'. The field
     * 'resultWriter' has the following description: Specify the
     * content and format of the results file
     * 
     * @param resultWriter the value of field 'resultWriter'.
     */
    public void setResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML resultWriter)
    {
        this._resultWriter = resultWriter;
    } //-- void setResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML) 

    /**
     * Sets the value of field 'resultWriters'. The field
     * 'resultWriters' has the following description: Specify the
     * results files in case more than one format is needed
     * 
     * @param resultWriters the value of field 'resultWriters'.
     */
    public void setResultWriters(org.openda.core.io.castorgenerated.OpenDaResultWritersXML resultWriters)
    {
        this._resultWriters = resultWriters;
    } //-- void setResultWriters(org.openda.core.io.castorgenerated.OpenDaResultWritersXML) 

    /**
     * Sets the value of field 'stochModelFactory'. The field
     * 'stochModelFactory' has the following description: Specify
     * the stochastic model component
     * 
     * @param stochModelFactory the value of field
     * 'stochModelFactory'.
     */
    public void setStochModelFactory(org.openda.core.io.castorgenerated.OpenDaStochModelXML stochModelFactory)
    {
        this._stochModelFactory = stochModelFactory;
    } //-- void setStochModelFactory(org.openda.core.io.castorgenerated.OpenDaStochModelXML) 

    /**
     * Sets the value of field 'stochObserver'. The field
     * 'stochObserver' has the following description: Specify the
     * stochastic observer component
     * 
     * @param stochObserver the value of field 'stochObserver'.
     */
    public void setStochObserver(org.openda.core.io.castorgenerated.OpenDaStochObserverXML stochObserver)
    {
        this._stochObserver = stochObserver;
    } //-- void setStochObserver(org.openda.core.io.castorgenerated.OpenDaStochObserverXML) 

    /**
     * Sets the value of field 'timeSettings'. The field
     * 'timeSettings' has the following description: Specify the
     * time settings
     * 
     * @param timeSettings the value of field 'timeSettings'.
     */
    public void setTimeSettings(org.openda.core.io.castorgenerated.ApplicationTimeXML timeSettings)
    {
        this._timeSettings = timeSettings;
    } //-- void setTimeSettings(org.openda.core.io.castorgenerated.ApplicationTimeXML) 

    /**
     * Sets the value of field 'timingSettings'. The field
     * 'timingSettings' has the following description: Specify the
     * settings for the run time timing
     * 
     * @param timingSettings the value of field 'timingSettings'.
     */
    public void setTimingSettings(org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML timingSettings)
    {
        this._timingSettings = timingSettings;
    } //-- void setTimingSettings(org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML) 

    /**
     * Method unmarshalOpenDaApplicationXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.OpenDaApplicationXML unmarshalOpenDaApplicationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.OpenDaApplicationXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.OpenDaApplicationXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.OpenDaApplicationXML unmarshalOpenDaApplicationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
