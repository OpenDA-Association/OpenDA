/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class DudXMLChoice2Item.
 * 
 * @version $Revision$ $Date$
 */
public class DudXMLChoice2Item implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _predictions
     */
    private org.openda.core.io.castorgenerated.TreeVectorXML _predictions;

    /**
     * Field _predictionVector
     */
    private java.lang.String _predictionVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public DudXMLChoice2Item() {
        super();
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice2Item()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'predictionVector'.
     * 
     * @return the value of field 'predictionVector'.
     */
    public java.lang.String getPredictionVector()
    {
        return this._predictionVector;
    } //-- java.lang.String getPredictionVector() 

    /**
     * Returns the value of field 'predictions'.
     * 
     * @return the value of field 'predictions'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXML getPredictions()
    {
        return this._predictions;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML getPredictions() 

    /**
     * Sets the value of field 'predictionVector'.
     * 
     * @param predictionVector the value of field 'predictionVector'
     */
    public void setPredictionVector(java.lang.String predictionVector)
    {
        this._predictionVector = predictionVector;
    } //-- void setPredictionVector(java.lang.String) 

    /**
     * Sets the value of field 'predictions'.
     * 
     * @param predictions the value of field 'predictions'.
     */
    public void setPredictions(org.openda.core.io.castorgenerated.TreeVectorXML predictions)
    {
        this._predictions = predictions;
    } //-- void setPredictions(org.openda.core.io.castorgenerated.TreeVectorXML) 

}
