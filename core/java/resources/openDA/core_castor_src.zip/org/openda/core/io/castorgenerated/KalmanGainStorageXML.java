/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.Date;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class KalmanGainStorageXML.
 * 
 * @version $Revision$ $Date$
 */
public class KalmanGainStorageXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Optional comment on the stored kalman gain
     */
    private java.lang.String _comment;

    /**
     * The time stamp for which the kalman gain is valid,
     * represented as Modified Julian Day
     */
    private double _timeStampAsMJD;

    /**
     * keeps track of state for field: _timeStampAsMJD
     */
    private boolean _has_timeStampAsMJD;

    /**
     * Field _stateSize
     */
    private int _stateSize;

    /**
     * keeps track of state for field: _stateSize
     */
    private boolean _has_stateSize;

    /**
     * The time step mentioned above, represented as Date Time
     */
    private java.util.Date _timeStampAsDateTime;

    /**
     * Field _observations
     */
    private org.openda.core.io.castorgenerated.KalmanGainObservationsXML _observations;


      //----------------/
     //- Constructors -/
    //----------------/

    public KalmanGainStorageXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.KalmanGainStorageXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteStateSize
     */
    public void deleteStateSize()
    {
        this._has_stateSize= false;
    } //-- void deleteStateSize() 

    /**
     * Returns the value of field 'comment'. The field 'comment'
     * has the following description: Optional comment on the
     * stored kalman gain
     * 
     * @return the value of field 'comment'.
     */
    public java.lang.String getComment()
    {
        return this._comment;
    } //-- java.lang.String getComment() 

    /**
     * Returns the value of field 'observations'.
     * 
     * @return the value of field 'observations'.
     */
    public org.openda.core.io.castorgenerated.KalmanGainObservationsXML getObservations()
    {
        return this._observations;
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationsXML getObservations() 

    /**
     * Returns the value of field 'stateSize'.
     * 
     * @return the value of field 'stateSize'.
     */
    public int getStateSize()
    {
        return this._stateSize;
    } //-- int getStateSize() 

    /**
     * Returns the value of field 'timeStampAsDateTime'. The field
     * 'timeStampAsDateTime' has the following description: The
     * time step mentioned above, represented as Date Time
     * 
     * @return the value of field 'timeStampAsDateTime'.
     */
    public java.util.Date getTimeStampAsDateTime()
    {
        return this._timeStampAsDateTime;
    } //-- java.util.Date getTimeStampAsDateTime() 

    /**
     * Returns the value of field 'timeStampAsMJD'. The field
     * 'timeStampAsMJD' has the following description: The time
     * stamp for which the kalman gain is valid, represented as
     * Modified Julian Day
     * 
     * @return the value of field 'timeStampAsMJD'.
     */
    public double getTimeStampAsMJD()
    {
        return this._timeStampAsMJD;
    } //-- double getTimeStampAsMJD() 

    /**
     * Method hasStateSize
     */
    public boolean hasStateSize()
    {
        return this._has_stateSize;
    } //-- boolean hasStateSize() 

    /**
     * Method hasTimeStampAsMJD
     */
    public boolean hasTimeStampAsMJD()
    {
        return this._has_timeStampAsMJD;
    } //-- boolean hasTimeStampAsMJD() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'comment'. The field 'comment' has
     * the following description: Optional comment on the stored
     * kalman gain
     * 
     * @param comment the value of field 'comment'.
     */
    public void setComment(java.lang.String comment)
    {
        this._comment = comment;
    } //-- void setComment(java.lang.String) 

    /**
     * Sets the value of field 'observations'.
     * 
     * @param observations the value of field 'observations'.
     */
    public void setObservations(org.openda.core.io.castorgenerated.KalmanGainObservationsXML observations)
    {
        this._observations = observations;
    } //-- void setObservations(org.openda.core.io.castorgenerated.KalmanGainObservationsXML) 

    /**
     * Sets the value of field 'stateSize'.
     * 
     * @param stateSize the value of field 'stateSize'.
     */
    public void setStateSize(int stateSize)
    {
        this._stateSize = stateSize;
        this._has_stateSize = true;
    } //-- void setStateSize(int) 

    /**
     * Sets the value of field 'timeStampAsDateTime'. The field
     * 'timeStampAsDateTime' has the following description: The
     * time step mentioned above, represented as Date Time
     * 
     * @param timeStampAsDateTime the value of field
     * 'timeStampAsDateTime'.
     */
    public void setTimeStampAsDateTime(java.util.Date timeStampAsDateTime)
    {
        this._timeStampAsDateTime = timeStampAsDateTime;
    } //-- void setTimeStampAsDateTime(java.util.Date) 

    /**
     * Sets the value of field 'timeStampAsMJD'. The field
     * 'timeStampAsMJD' has the following description: The time
     * stamp for which the kalman gain is valid, represented as
     * Modified Julian Day
     * 
     * @param timeStampAsMJD the value of field 'timeStampAsMJD'.
     */
    public void setTimeStampAsMJD(double timeStampAsMJD)
    {
        this._timeStampAsMJD = timeStampAsMJD;
        this._has_timeStampAsMJD = true;
    } //-- void setTimeStampAsMJD(double) 

    /**
     * Method unmarshalKalmanGainStorageXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.KalmanGainStorageXML unmarshalKalmanGainStorageXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.KalmanGainStorageXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.KalmanGainStorageXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.KalmanGainStorageXML unmarshalKalmanGainStorageXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
