/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.types.Time;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DateTimeXML.
 * 
 * @version $Revision$ $Date$
 */
public class DateTimeXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * ISO 8601 (yyyy-mm-dd)
     */
    private org.exolab.castor.types.Date _date;

    /**
     * ISO 8601 (hh:mm:ss[.msec])
     */
    private org.exolab.castor.types.Time _time;

    /**
     * Field _timeZone
     */
    private java.lang.String _timeZone;


      //----------------/
     //- Constructors -/
    //----------------/

    public DateTimeXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.DateTimeXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'date'. The field 'date' has the
     * following description: ISO 8601 (yyyy-mm-dd)
     * 
     * @return the value of field 'date'.
     */
    public org.exolab.castor.types.Date getDate()
    {
        return this._date;
    } //-- org.exolab.castor.types.Date getDate() 

    /**
     * Returns the value of field 'time'. The field 'time' has the
     * following description: ISO 8601 (hh:mm:ss[.msec])
     * 
     * @return the value of field 'time'.
     */
    public org.exolab.castor.types.Time getTime()
    {
        return this._time;
    } //-- org.exolab.castor.types.Time getTime() 

    /**
     * Returns the value of field 'timeZone'.
     * 
     * @return the value of field 'timeZone'.
     */
    public java.lang.String getTimeZone()
    {
        return this._timeZone;
    } //-- java.lang.String getTimeZone() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'date'. The field 'date' has the
     * following description: ISO 8601 (yyyy-mm-dd)
     * 
     * @param date the value of field 'date'.
     */
    public void setDate(org.exolab.castor.types.Date date)
    {
        this._date = date;
    } //-- void setDate(org.exolab.castor.types.Date) 

    /**
     * Sets the value of field 'time'. The field 'time' has the
     * following description: ISO 8601 (hh:mm:ss[.msec])
     * 
     * @param time the value of field 'time'.
     */
    public void setTime(org.exolab.castor.types.Time time)
    {
        this._time = time;
    } //-- void setTime(org.exolab.castor.types.Time) 

    /**
     * Sets the value of field 'timeZone'.
     * 
     * @param timeZone the value of field 'timeZone'.
     */
    public void setTimeZone(java.lang.String timeZone)
    {
        this._timeZone = timeZone;
    } //-- void setTimeZone(java.lang.String) 

    /**
     * Method unmarshalDateTimeXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.DateTimeXML unmarshalDateTimeXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.DateTimeXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.DateTimeXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.DateTimeXML unmarshalDateTimeXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
