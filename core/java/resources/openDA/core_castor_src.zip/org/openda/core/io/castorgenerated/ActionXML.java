/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ActionXML.
 * 
 * @version $Revision$ $Date$
 */
public class ActionXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Name and path of the executable file
     */
    private java.lang.String _exe;

    /**
     * Name and path of the executable file for Windows operating
     * system
     */
    private java.lang.String _windowsExe;

    /**
     * Name and path of the executable file for Linux operating
     * system
     */
    private java.lang.String _linuxExe;

    /**
     * Name and path of the executable file for Mac operating system
     */
    private java.lang.String _macExe;

    /**
     * The openda:class name.
     */
    private java.lang.String _className;

    /**
     * Directory where executable file is run. This is usually the
     * instance dir. This is only used in blackBoxStochModelConfig.
     */
    private java.lang.String _workingDirectory;

    /**
     * Subdirectory of instance dir, where executable file has to
     * be run. To be specified as relative path to instance dir.
     * This is only used in blackBoxWrapperConfig. This is only
     * used for executable files, not for Java classes. For Java
     * classes the instanceDir is used as workingDirectory.
     */
    private java.lang.String _actualWorkingDirectory;

    /**
     * Flag for ignoring the status of the previous action step
     * (ignoreStatus=true). Not yet implemented.
     */
    private boolean _ignoreStatus = false;

    /**
     * keeps track of state for field: _ignoreStatus
     */
    private boolean _has_ignoreStatus;

    /**
     * Specify list of input arguments of the model executable
     */
    private java.util.ArrayList _argList;

    /**
     * Specify list of output files to be checked after the command
     * execution has finished
     */
    private java.util.ArrayList _checkOutputList;

    /**
     * Specify return value after the command execution has finished
     */
    private org.openda.core.io.castorgenerated.CheckReturnStatusXML _checkReturnStatus;


      //----------------/
     //- Constructors -/
    //----------------/

    public ActionXML() {
        super();
        _argList = new ArrayList();
        _checkOutputList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.ActionXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addArg
     * 
     * @param vArg
     */
    public void addArg(java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        _argList.add(vArg);
    } //-- void addArg(java.lang.String) 

    /**
     * Method addArg
     * 
     * @param index
     * @param vArg
     */
    public void addArg(int index, java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        _argList.add(index, vArg);
    } //-- void addArg(int, java.lang.String) 

    /**
     * Method addCheckOutput
     * 
     * @param vCheckOutput
     */
    public void addCheckOutput(org.openda.core.io.castorgenerated.CheckOutputXML vCheckOutput)
        throws java.lang.IndexOutOfBoundsException
    {
        _checkOutputList.add(vCheckOutput);
    } //-- void addCheckOutput(org.openda.core.io.castorgenerated.CheckOutputXML) 

    /**
     * Method addCheckOutput
     * 
     * @param index
     * @param vCheckOutput
     */
    public void addCheckOutput(int index, org.openda.core.io.castorgenerated.CheckOutputXML vCheckOutput)
        throws java.lang.IndexOutOfBoundsException
    {
        _checkOutputList.add(index, vCheckOutput);
    } //-- void addCheckOutput(int, org.openda.core.io.castorgenerated.CheckOutputXML) 

    /**
     * Method clearArg
     */
    public void clearArg()
    {
        _argList.clear();
    } //-- void clearArg() 

    /**
     * Method clearCheckOutput
     */
    public void clearCheckOutput()
    {
        _checkOutputList.clear();
    } //-- void clearCheckOutput() 

    /**
     * Method deleteIgnoreStatus
     */
    public void deleteIgnoreStatus()
    {
        this._has_ignoreStatus= false;
    } //-- void deleteIgnoreStatus() 

    /**
     * Method enumerateArg
     */
    public java.util.Enumeration enumerateArg()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_argList.iterator());
    } //-- java.util.Enumeration enumerateArg() 

    /**
     * Method enumerateCheckOutput
     */
    public java.util.Enumeration enumerateCheckOutput()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_checkOutputList.iterator());
    } //-- java.util.Enumeration enumerateCheckOutput() 

    /**
     * Returns the value of field 'actualWorkingDirectory'. The
     * field 'actualWorkingDirectory' has the following
     * description: Subdirectory of instance dir, where executable
     * file has to be run. To be specified as relative path to
     * instance dir. This is only used in blackBoxWrapperConfig.
     * This is only used for executable files, not for Java
     * classes. For Java classes the instanceDir is used as
     * workingDirectory.
     * 
     * @return the value of field 'actualWorkingDirectory'.
     */
    public java.lang.String getActualWorkingDirectory()
    {
        return this._actualWorkingDirectory;
    } //-- java.lang.String getActualWorkingDirectory() 

    /**
     * Method getArg
     * 
     * @param index
     */
    public java.lang.String getArg(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_argList.get(index);
    } //-- java.lang.String getArg(int) 

    /**
     * Method getArg
     */
    public java.lang.String[] getArg()
    {
        int size = _argList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_argList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getArg() 

    /**
     * Method getArgCount
     */
    public int getArgCount()
    {
        return _argList.size();
    } //-- int getArgCount() 

    /**
     * Method getCheckOutput
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.CheckOutputXML getCheckOutput(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _checkOutputList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.CheckOutputXML) _checkOutputList.get(index);
    } //-- org.openda.core.io.castorgenerated.CheckOutputXML getCheckOutput(int) 

    /**
     * Method getCheckOutput
     */
    public org.openda.core.io.castorgenerated.CheckOutputXML[] getCheckOutput()
    {
        int size = _checkOutputList.size();
        org.openda.core.io.castorgenerated.CheckOutputXML[] mArray = new org.openda.core.io.castorgenerated.CheckOutputXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.CheckOutputXML) _checkOutputList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.CheckOutputXML[] getCheckOutput() 

    /**
     * Method getCheckOutputCount
     */
    public int getCheckOutputCount()
    {
        return _checkOutputList.size();
    } //-- int getCheckOutputCount() 

    /**
     * Returns the value of field 'checkReturnStatus'. The field
     * 'checkReturnStatus' has the following description: Specify
     * return value after the command execution has finished
     * 
     * @return the value of field 'checkReturnStatus'.
     */
    public org.openda.core.io.castorgenerated.CheckReturnStatusXML getCheckReturnStatus()
    {
        return this._checkReturnStatus;
    } //-- org.openda.core.io.castorgenerated.CheckReturnStatusXML getCheckReturnStatus() 

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: The openda:class
     * name.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'exe'. The field 'exe' has the
     * following description: Name and path of the executable file
     * 
     * @return the value of field 'exe'.
     */
    public java.lang.String getExe()
    {
        return this._exe;
    } //-- java.lang.String getExe() 

    /**
     * Returns the value of field 'ignoreStatus'. The field
     * 'ignoreStatus' has the following description: Flag for
     * ignoring the status of the previous action step
     * (ignoreStatus=true). Not yet implemented.
     * 
     * @return the value of field 'ignoreStatus'.
     */
    public boolean getIgnoreStatus()
    {
        return this._ignoreStatus;
    } //-- boolean getIgnoreStatus() 

    /**
     * Returns the value of field 'linuxExe'. The field 'linuxExe'
     * has the following description: Name and path of the
     * executable file for Linux operating system
     * 
     * @return the value of field 'linuxExe'.
     */
    public java.lang.String getLinuxExe()
    {
        return this._linuxExe;
    } //-- java.lang.String getLinuxExe() 

    /**
     * Returns the value of field 'macExe'. The field 'macExe' has
     * the following description: Name and path of the executable
     * file for Mac operating system
     * 
     * @return the value of field 'macExe'.
     */
    public java.lang.String getMacExe()
    {
        return this._macExe;
    } //-- java.lang.String getMacExe() 

    /**
     * Returns the value of field 'windowsExe'. The field
     * 'windowsExe' has the following description: Name and path of
     * the executable file for Windows operating system
     * 
     * @return the value of field 'windowsExe'.
     */
    public java.lang.String getWindowsExe()
    {
        return this._windowsExe;
    } //-- java.lang.String getWindowsExe() 

    /**
     * Returns the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: Directory
     * where executable file is run. This is usually the instance
     * dir. This is only used in blackBoxStochModelConfig.
     * 
     * @return the value of field 'workingDirectory'.
     */
    public java.lang.String getWorkingDirectory()
    {
        return this._workingDirectory;
    } //-- java.lang.String getWorkingDirectory() 

    /**
     * Method hasIgnoreStatus
     */
    public boolean hasIgnoreStatus()
    {
        return this._has_ignoreStatus;
    } //-- boolean hasIgnoreStatus() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeArg
     * 
     * @param vArg
     */
    public boolean removeArg(java.lang.String vArg)
    {
        boolean removed = _argList.remove(vArg);
        return removed;
    } //-- boolean removeArg(java.lang.String) 

    /**
     * Method removeCheckOutput
     * 
     * @param vCheckOutput
     */
    public boolean removeCheckOutput(org.openda.core.io.castorgenerated.CheckOutputXML vCheckOutput)
    {
        boolean removed = _checkOutputList.remove(vCheckOutput);
        return removed;
    } //-- boolean removeCheckOutput(org.openda.core.io.castorgenerated.CheckOutputXML) 

    /**
     * Sets the value of field 'actualWorkingDirectory'. The field
     * 'actualWorkingDirectory' has the following description:
     * Subdirectory of instance dir, where executable file has to
     * be run. To be specified as relative path to instance dir.
     * This is only used in blackBoxWrapperConfig. This is only
     * used for executable files, not for Java classes. For Java
     * classes the instanceDir is used as workingDirectory.
     * 
     * @param actualWorkingDirectory the value of field
     * 'actualWorkingDirectory'.
     */
    public void setActualWorkingDirectory(java.lang.String actualWorkingDirectory)
    {
        this._actualWorkingDirectory = actualWorkingDirectory;
    } //-- void setActualWorkingDirectory(java.lang.String) 

    /**
     * Method setArg
     * 
     * @param index
     * @param vArg
     */
    public void setArg(int index, java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _argList.set(index, vArg);
    } //-- void setArg(int, java.lang.String) 

    /**
     * Method setArg
     * 
     * @param argArray
     */
    public void setArg(java.lang.String[] argArray)
    {
        //-- copy array
        _argList.clear();
        for (int i = 0; i < argArray.length; i++) {
            _argList.add(argArray[i]);
        }
    } //-- void setArg(java.lang.String) 

    /**
     * Method setCheckOutput
     * 
     * @param index
     * @param vCheckOutput
     */
    public void setCheckOutput(int index, org.openda.core.io.castorgenerated.CheckOutputXML vCheckOutput)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _checkOutputList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _checkOutputList.set(index, vCheckOutput);
    } //-- void setCheckOutput(int, org.openda.core.io.castorgenerated.CheckOutputXML) 

    /**
     * Method setCheckOutput
     * 
     * @param checkOutputArray
     */
    public void setCheckOutput(org.openda.core.io.castorgenerated.CheckOutputXML[] checkOutputArray)
    {
        //-- copy array
        _checkOutputList.clear();
        for (int i = 0; i < checkOutputArray.length; i++) {
            _checkOutputList.add(checkOutputArray[i]);
        }
    } //-- void setCheckOutput(org.openda.core.io.castorgenerated.CheckOutputXML) 

    /**
     * Sets the value of field 'checkReturnStatus'. The field
     * 'checkReturnStatus' has the following description: Specify
     * return value after the command execution has finished
     * 
     * @param checkReturnStatus the value of field
     * 'checkReturnStatus'.
     */
    public void setCheckReturnStatus(org.openda.core.io.castorgenerated.CheckReturnStatusXML checkReturnStatus)
    {
        this._checkReturnStatus = checkReturnStatus;
    } //-- void setCheckReturnStatus(org.openda.core.io.castorgenerated.CheckReturnStatusXML) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: The openda:class name.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'exe'. The field 'exe' has the
     * following description: Name and path of the executable file
     * 
     * @param exe the value of field 'exe'.
     */
    public void setExe(java.lang.String exe)
    {
        this._exe = exe;
    } //-- void setExe(java.lang.String) 

    /**
     * Sets the value of field 'ignoreStatus'. The field
     * 'ignoreStatus' has the following description: Flag for
     * ignoring the status of the previous action step
     * (ignoreStatus=true). Not yet implemented.
     * 
     * @param ignoreStatus the value of field 'ignoreStatus'.
     */
    public void setIgnoreStatus(boolean ignoreStatus)
    {
        this._ignoreStatus = ignoreStatus;
        this._has_ignoreStatus = true;
    } //-- void setIgnoreStatus(boolean) 

    /**
     * Sets the value of field 'linuxExe'. The field 'linuxExe' has
     * the following description: Name and path of the executable
     * file for Linux operating system
     * 
     * @param linuxExe the value of field 'linuxExe'.
     */
    public void setLinuxExe(java.lang.String linuxExe)
    {
        this._linuxExe = linuxExe;
    } //-- void setLinuxExe(java.lang.String) 

    /**
     * Sets the value of field 'macExe'. The field 'macExe' has the
     * following description: Name and path of the executable file
     * for Mac operating system
     * 
     * @param macExe the value of field 'macExe'.
     */
    public void setMacExe(java.lang.String macExe)
    {
        this._macExe = macExe;
    } //-- void setMacExe(java.lang.String) 

    /**
     * Sets the value of field 'windowsExe'. The field 'windowsExe'
     * has the following description: Name and path of the
     * executable file for Windows operating system
     * 
     * @param windowsExe the value of field 'windowsExe'.
     */
    public void setWindowsExe(java.lang.String windowsExe)
    {
        this._windowsExe = windowsExe;
    } //-- void setWindowsExe(java.lang.String) 

    /**
     * Sets the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: Directory
     * where executable file is run. This is usually the instance
     * dir. This is only used in blackBoxStochModelConfig.
     * 
     * @param workingDirectory the value of field 'workingDirectory'
     */
    public void setWorkingDirectory(java.lang.String workingDirectory)
    {
        this._workingDirectory = workingDirectory;
    } //-- void setWorkingDirectory(java.lang.String) 

    /**
     * Method unmarshalActionXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ActionXML unmarshalActionXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ActionXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ActionXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ActionXML unmarshalActionXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
