/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class CartesianToPolarXML.
 * 
 * @version $Revision$ $Date$
 */
public class CartesianToPolarXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Scaling factor for dx
     */
    private double _xScale = 1;

    /**
     * keeps track of state for field: _xScale
     */
    private boolean _has_xScale;

    /**
     * Scaling factor for dy
     */
    private double _yScale = 1;

    /**
     * keeps track of state for field: _yScale
     */
    private boolean _has_yScale;

    /**
     * Name suffix for dx in the noise model exchange items
     */
    private java.lang.String _xSuffixCaption = "dX";

    /**
     * Name suffix for dy in the noise model exchange items
     */
    private java.lang.String _ySuffixCaption = "dY";

    /**
     * Name for dx in the noise model exchange items
     */
    private java.lang.String _xCaption;

    /**
     * Name for dy in the noise model exchange items
     */
    private java.lang.String _yCaption;

    /**
     * Specify standard deviation for dx and dy Set the standard
     * deviation of this parameter and the method how the parameter
     * should be corrected
     */
    private org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML _stdDev;

    /**
     * Select the sets of parameter vectors to adjust, in pairs of
     * two: amplitude and phase
     */
    private java.util.ArrayList _cartesianToPolarXMLChoiceList;


      //----------------/
     //- Constructors -/
    //----------------/

    public CartesianToPolarXML() {
        super();
        setXSuffixCaption("dX");
        setYSuffixCaption("dY");
        _cartesianToPolarXMLChoiceList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.CartesianToPolarXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addCartesianToPolarXMLChoice
     * 
     * @param vCartesianToPolarXMLChoice
     */
    public void addCartesianToPolarXMLChoice(org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice vCartesianToPolarXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _cartesianToPolarXMLChoiceList.add(vCartesianToPolarXMLChoice);
    } //-- void addCartesianToPolarXMLChoice(org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) 

    /**
     * Method addCartesianToPolarXMLChoice
     * 
     * @param index
     * @param vCartesianToPolarXMLChoice
     */
    public void addCartesianToPolarXMLChoice(int index, org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice vCartesianToPolarXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _cartesianToPolarXMLChoiceList.add(index, vCartesianToPolarXMLChoice);
    } //-- void addCartesianToPolarXMLChoice(int, org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) 

    /**
     * Method clearCartesianToPolarXMLChoice
     */
    public void clearCartesianToPolarXMLChoice()
    {
        _cartesianToPolarXMLChoiceList.clear();
    } //-- void clearCartesianToPolarXMLChoice() 

    /**
     * Method deleteXScale
     */
    public void deleteXScale()
    {
        this._has_xScale= false;
    } //-- void deleteXScale() 

    /**
     * Method deleteYScale
     */
    public void deleteYScale()
    {
        this._has_yScale= false;
    } //-- void deleteYScale() 

    /**
     * Method enumerateCartesianToPolarXMLChoice
     */
    public java.util.Enumeration enumerateCartesianToPolarXMLChoice()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_cartesianToPolarXMLChoiceList.iterator());
    } //-- java.util.Enumeration enumerateCartesianToPolarXMLChoice() 

    /**
     * Method getCartesianToPolarXMLChoice
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice getCartesianToPolarXMLChoice(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _cartesianToPolarXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) _cartesianToPolarXMLChoiceList.get(index);
    } //-- org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice getCartesianToPolarXMLChoice(int) 

    /**
     * Method getCartesianToPolarXMLChoice
     */
    public org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice[] getCartesianToPolarXMLChoice()
    {
        int size = _cartesianToPolarXMLChoiceList.size();
        org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice[] mArray = new org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) _cartesianToPolarXMLChoiceList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice[] getCartesianToPolarXMLChoice() 

    /**
     * Method getCartesianToPolarXMLChoiceCount
     */
    public int getCartesianToPolarXMLChoiceCount()
    {
        return _cartesianToPolarXMLChoiceList.size();
    } //-- int getCartesianToPolarXMLChoiceCount() 

    /**
     * Returns the value of field 'stdDev'. The field 'stdDev' has
     * the following description: Specify standard deviation for dx
     * and dy Set the standard deviation of this parameter and the
     * method how the parameter should be corrected
     * 
     * @return the value of field 'stdDev'.
     */
    public org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML getStdDev()
    {
        return this._stdDev;
    } //-- org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML getStdDev() 

    /**
     * Returns the value of field 'xCaption'. The field 'xCaption'
     * has the following description: Name for dx in the noise
     * model exchange items
     * 
     * @return the value of field 'xCaption'.
     */
    public java.lang.String getXCaption()
    {
        return this._xCaption;
    } //-- java.lang.String getXCaption() 

    /**
     * Returns the value of field 'xScale'. The field 'xScale' has
     * the following description: Scaling factor for dx
     * 
     * @return the value of field 'xScale'.
     */
    public double getXScale()
    {
        return this._xScale;
    } //-- double getXScale() 

    /**
     * Returns the value of field 'xSuffixCaption'. The field
     * 'xSuffixCaption' has the following description: Name suffix
     * for dx in the noise model exchange items
     * 
     * @return the value of field 'xSuffixCaption'.
     */
    public java.lang.String getXSuffixCaption()
    {
        return this._xSuffixCaption;
    } //-- java.lang.String getXSuffixCaption() 

    /**
     * Returns the value of field 'yCaption'. The field 'yCaption'
     * has the following description: Name for dy in the noise
     * model exchange items
     * 
     * @return the value of field 'yCaption'.
     */
    public java.lang.String getYCaption()
    {
        return this._yCaption;
    } //-- java.lang.String getYCaption() 

    /**
     * Returns the value of field 'yScale'. The field 'yScale' has
     * the following description: Scaling factor for dy
     * 
     * @return the value of field 'yScale'.
     */
    public double getYScale()
    {
        return this._yScale;
    } //-- double getYScale() 

    /**
     * Returns the value of field 'ySuffixCaption'. The field
     * 'ySuffixCaption' has the following description: Name suffix
     * for dy in the noise model exchange items
     * 
     * @return the value of field 'ySuffixCaption'.
     */
    public java.lang.String getYSuffixCaption()
    {
        return this._ySuffixCaption;
    } //-- java.lang.String getYSuffixCaption() 

    /**
     * Method hasXScale
     */
    public boolean hasXScale()
    {
        return this._has_xScale;
    } //-- boolean hasXScale() 

    /**
     * Method hasYScale
     */
    public boolean hasYScale()
    {
        return this._has_yScale;
    } //-- boolean hasYScale() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeCartesianToPolarXMLChoice
     * 
     * @param vCartesianToPolarXMLChoice
     */
    public boolean removeCartesianToPolarXMLChoice(org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice vCartesianToPolarXMLChoice)
    {
        boolean removed = _cartesianToPolarXMLChoiceList.remove(vCartesianToPolarXMLChoice);
        return removed;
    } //-- boolean removeCartesianToPolarXMLChoice(org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) 

    /**
     * Method setCartesianToPolarXMLChoice
     * 
     * @param index
     * @param vCartesianToPolarXMLChoice
     */
    public void setCartesianToPolarXMLChoice(int index, org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice vCartesianToPolarXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _cartesianToPolarXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _cartesianToPolarXMLChoiceList.set(index, vCartesianToPolarXMLChoice);
    } //-- void setCartesianToPolarXMLChoice(int, org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) 

    /**
     * Method setCartesianToPolarXMLChoice
     * 
     * @param cartesianToPolarXMLChoiceArray
     */
    public void setCartesianToPolarXMLChoice(org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice[] cartesianToPolarXMLChoiceArray)
    {
        //-- copy array
        _cartesianToPolarXMLChoiceList.clear();
        for (int i = 0; i < cartesianToPolarXMLChoiceArray.length; i++) {
            _cartesianToPolarXMLChoiceList.add(cartesianToPolarXMLChoiceArray[i]);
        }
    } //-- void setCartesianToPolarXMLChoice(org.openda.core.io.castorgenerated.CartesianToPolarXMLChoice) 

    /**
     * Sets the value of field 'stdDev'. The field 'stdDev' has the
     * following description: Specify standard deviation for dx and
     * dy Set the standard deviation of this parameter and the
     * method how the parameter should be corrected
     * 
     * @param stdDev the value of field 'stdDev'.
     */
    public void setStdDev(org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML stdDev)
    {
        this._stdDev = stdDev;
    } //-- void setStdDev(org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML) 

    /**
     * Sets the value of field 'xCaption'. The field 'xCaption' has
     * the following description: Name for dx in the noise model
     * exchange items
     * 
     * @param xCaption the value of field 'xCaption'.
     */
    public void setXCaption(java.lang.String xCaption)
    {
        this._xCaption = xCaption;
    } //-- void setXCaption(java.lang.String) 

    /**
     * Sets the value of field 'xScale'. The field 'xScale' has the
     * following description: Scaling factor for dx
     * 
     * @param xScale the value of field 'xScale'.
     */
    public void setXScale(double xScale)
    {
        this._xScale = xScale;
        this._has_xScale = true;
    } //-- void setXScale(double) 

    /**
     * Sets the value of field 'xSuffixCaption'. The field
     * 'xSuffixCaption' has the following description: Name suffix
     * for dx in the noise model exchange items
     * 
     * @param xSuffixCaption the value of field 'xSuffixCaption'.
     */
    public void setXSuffixCaption(java.lang.String xSuffixCaption)
    {
        this._xSuffixCaption = xSuffixCaption;
    } //-- void setXSuffixCaption(java.lang.String) 

    /**
     * Sets the value of field 'yCaption'. The field 'yCaption' has
     * the following description: Name for dy in the noise model
     * exchange items
     * 
     * @param yCaption the value of field 'yCaption'.
     */
    public void setYCaption(java.lang.String yCaption)
    {
        this._yCaption = yCaption;
    } //-- void setYCaption(java.lang.String) 

    /**
     * Sets the value of field 'yScale'. The field 'yScale' has the
     * following description: Scaling factor for dy
     * 
     * @param yScale the value of field 'yScale'.
     */
    public void setYScale(double yScale)
    {
        this._yScale = yScale;
        this._has_yScale = true;
    } //-- void setYScale(double) 

    /**
     * Sets the value of field 'ySuffixCaption'. The field
     * 'ySuffixCaption' has the following description: Name suffix
     * for dy in the noise model exchange items
     * 
     * @param ySuffixCaption the value of field 'ySuffixCaption'.
     */
    public void setYSuffixCaption(java.lang.String ySuffixCaption)
    {
        this._ySuffixCaption = ySuffixCaption;
    } //-- void setYSuffixCaption(java.lang.String) 

    /**
     * Method unmarshalCartesianToPolarXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.CartesianToPolarXML unmarshalCartesianToPolarXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.CartesianToPolarXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.CartesianToPolarXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.CartesianToPolarXML unmarshalCartesianToPolarXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
