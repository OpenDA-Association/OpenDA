/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DudXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class DudXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field dudXMLChoiceItem
     */
    private org.openda.core.io.castorgenerated.DudXMLChoiceItem dudXMLChoiceItem;


      //----------------/
     //- Constructors -/
    //----------------/

    public DudXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dudXMLChoiceItem'.
     * 
     * @return the value of field 'dudXMLChoiceItem'.
     */
    public org.openda.core.io.castorgenerated.DudXMLChoiceItem getDudXMLChoiceItem()
    {
        return this.dudXMLChoiceItem;
    } //-- org.openda.core.io.castorgenerated.DudXMLChoiceItem getDudXMLChoiceItem() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dudXMLChoiceItem'.
     * 
     * @param dudXMLChoiceItem the value of field 'dudXMLChoiceItem'
     */
    public void setDudXMLChoiceItem(org.openda.core.io.castorgenerated.DudXMLChoiceItem dudXMLChoiceItem)
    {
        this.dudXMLChoiceItem = dudXMLChoiceItem;
    } //-- void setDudXMLChoiceItem(org.openda.core.io.castorgenerated.DudXMLChoiceItem) 

    /**
     * Method unmarshalDudXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.DudXMLChoice unmarshalDudXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.DudXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.DudXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice unmarshalDudXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
