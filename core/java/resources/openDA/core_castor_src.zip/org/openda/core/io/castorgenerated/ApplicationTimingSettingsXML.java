/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ApplicationTimingSettingsXML.
 * 
 * @version $Revision$ $Date$
 */
public class ApplicationTimingSettingsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * (should the various steps in the application be timed?
     */
    private boolean _doTiming;

    /**
     * keeps track of state for field: _doTiming
     */
    private boolean _has_doTiming;


      //----------------/
     //- Constructors -/
    //----------------/

    public ApplicationTimingSettingsXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'doTiming'. The field 'doTiming'
     * has the following description: (should the various steps in
     * the application be timed?
     * 
     * @return the value of field 'doTiming'.
     */
    public boolean getDoTiming()
    {
        return this._doTiming;
    } //-- boolean getDoTiming() 

    /**
     * Method hasDoTiming
     */
    public boolean hasDoTiming()
    {
        return this._has_doTiming;
    } //-- boolean hasDoTiming() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'doTiming'. The field 'doTiming' has
     * the following description: (should the various steps in the
     * application be timed?
     * 
     * @param doTiming the value of field 'doTiming'.
     */
    public void setDoTiming(boolean doTiming)
    {
        this._doTiming = doTiming;
        this._has_doTiming = true;
    } //-- void setDoTiming(boolean) 

    /**
     * Method unmarshalApplicationTimingSettingsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML unmarshalApplicationTimingSettingsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ApplicationTimingSettingsXML unmarshalApplicationTimingSettingsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
