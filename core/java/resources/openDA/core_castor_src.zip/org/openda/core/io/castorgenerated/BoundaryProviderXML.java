/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BoundaryProviderXML.
 * 
 * @version $Revision$ $Date$
 */
public class BoundaryProviderXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The data object containing the forcing data.
     */
    private org.openda.core.io.castorgenerated.BoundaryDataObjectXML _dataObject;

    /**
     * Specify the operation when imposing the forcing
     * ExchangeItems on the model ExchangeItems.
     */
    private java.util.ArrayList _boundaryMappingList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BoundaryProviderXML() {
        super();
        _boundaryMappingList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BoundaryProviderXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBoundaryMapping
     * 
     * @param vBoundaryMapping
     */
    public void addBoundaryMapping(org.openda.core.io.castorgenerated.BoundaryMappingXML vBoundaryMapping)
        throws java.lang.IndexOutOfBoundsException
    {
        _boundaryMappingList.add(vBoundaryMapping);
    } //-- void addBoundaryMapping(org.openda.core.io.castorgenerated.BoundaryMappingXML) 

    /**
     * Method addBoundaryMapping
     * 
     * @param index
     * @param vBoundaryMapping
     */
    public void addBoundaryMapping(int index, org.openda.core.io.castorgenerated.BoundaryMappingXML vBoundaryMapping)
        throws java.lang.IndexOutOfBoundsException
    {
        _boundaryMappingList.add(index, vBoundaryMapping);
    } //-- void addBoundaryMapping(int, org.openda.core.io.castorgenerated.BoundaryMappingXML) 

    /**
     * Method clearBoundaryMapping
     */
    public void clearBoundaryMapping()
    {
        _boundaryMappingList.clear();
    } //-- void clearBoundaryMapping() 

    /**
     * Method enumerateBoundaryMapping
     */
    public java.util.Enumeration enumerateBoundaryMapping()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_boundaryMappingList.iterator());
    } //-- java.util.Enumeration enumerateBoundaryMapping() 

    /**
     * Method getBoundaryMapping
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BoundaryMappingXML getBoundaryMapping(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _boundaryMappingList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BoundaryMappingXML) _boundaryMappingList.get(index);
    } //-- org.openda.core.io.castorgenerated.BoundaryMappingXML getBoundaryMapping(int) 

    /**
     * Method getBoundaryMapping
     */
    public org.openda.core.io.castorgenerated.BoundaryMappingXML[] getBoundaryMapping()
    {
        int size = _boundaryMappingList.size();
        org.openda.core.io.castorgenerated.BoundaryMappingXML[] mArray = new org.openda.core.io.castorgenerated.BoundaryMappingXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BoundaryMappingXML) _boundaryMappingList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BoundaryMappingXML[] getBoundaryMapping() 

    /**
     * Method getBoundaryMappingCount
     */
    public int getBoundaryMappingCount()
    {
        return _boundaryMappingList.size();
    } //-- int getBoundaryMappingCount() 

    /**
     * Returns the value of field 'dataObject'. The field
     * 'dataObject' has the following description: The data object
     * containing the forcing data.
     * 
     * @return the value of field 'dataObject'.
     */
    public org.openda.core.io.castorgenerated.BoundaryDataObjectXML getDataObject()
    {
        return this._dataObject;
    } //-- org.openda.core.io.castorgenerated.BoundaryDataObjectXML getDataObject() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBoundaryMapping
     * 
     * @param vBoundaryMapping
     */
    public boolean removeBoundaryMapping(org.openda.core.io.castorgenerated.BoundaryMappingXML vBoundaryMapping)
    {
        boolean removed = _boundaryMappingList.remove(vBoundaryMapping);
        return removed;
    } //-- boolean removeBoundaryMapping(org.openda.core.io.castorgenerated.BoundaryMappingXML) 

    /**
     * Method setBoundaryMapping
     * 
     * @param index
     * @param vBoundaryMapping
     */
    public void setBoundaryMapping(int index, org.openda.core.io.castorgenerated.BoundaryMappingXML vBoundaryMapping)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _boundaryMappingList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _boundaryMappingList.set(index, vBoundaryMapping);
    } //-- void setBoundaryMapping(int, org.openda.core.io.castorgenerated.BoundaryMappingXML) 

    /**
     * Method setBoundaryMapping
     * 
     * @param boundaryMappingArray
     */
    public void setBoundaryMapping(org.openda.core.io.castorgenerated.BoundaryMappingXML[] boundaryMappingArray)
    {
        //-- copy array
        _boundaryMappingList.clear();
        for (int i = 0; i < boundaryMappingArray.length; i++) {
            _boundaryMappingList.add(boundaryMappingArray[i]);
        }
    } //-- void setBoundaryMapping(org.openda.core.io.castorgenerated.BoundaryMappingXML) 

    /**
     * Sets the value of field 'dataObject'. The field 'dataObject'
     * has the following description: The data object containing
     * the forcing data.
     * 
     * @param dataObject the value of field 'dataObject'.
     */
    public void setDataObject(org.openda.core.io.castorgenerated.BoundaryDataObjectXML dataObject)
    {
        this._dataObject = dataObject;
    } //-- void setDataObject(org.openda.core.io.castorgenerated.BoundaryDataObjectXML) 

    /**
     * Method unmarshalBoundaryProviderXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BoundaryProviderXML unmarshalBoundaryProviderXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BoundaryProviderXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BoundaryProviderXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BoundaryProviderXML unmarshalBoundaryProviderXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
