/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelVectorSpecificationXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelVectorSpecificationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the model parameters vectors
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML _parameters;

    /**
     * Specify the model state vectors
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML _state;

    /**
     * Specify the predictor vectors. i.e. the model variables that
     * correspond to the observer variables. This can contain three
     * different types of mappings between model and observer
     * variables:
     * 1. a vector for a mapping between an observed scalar and a
     * scalar in the model. In this case the coordinates are not
     * used and no interpolation is done.
     * 2. a vector for a mapping between an observed grid and a
     * grid in the model. In this case the model values are
     * interpolated to get values at the cell centers of the
     * observed grid. This uses the coordinates of both grids and
     * bilinear interpolation.
     * 3. a subVector for a mapping between an observed scalar and
     * a cell of a grid in the model. In this case the coordinates
     * are not used and no interpolation is done.
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML _predictor;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelVectorSpecificationXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'parameters'. The field
     * 'parameters' has the following description: Specify the
     * model parameters vectors
     * 
     * @return the value of field 'parameters'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML getParameters()
    {
        return this._parameters;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML getParameters() 

    /**
     * Returns the value of field 'predictor'. The field
     * 'predictor' has the following description: Specify the
     * predictor vectors. i.e. the model variables that correspond
     * to the observer variables. This can contain three different
     * types of mappings between model and observer variables:
     * 1. a vector for a mapping between an observed scalar and a
     * scalar in the model. In this case the coordinates are not
     * used and no interpolation is done.
     * 2. a vector for a mapping between an observed grid and a
     * grid in the model. In this case the model values are
     * interpolated to get values at the cell centers of the
     * observed grid. This uses the coordinates of both grids and
     * bilinear interpolation.
     * 3. a subVector for a mapping between an observed scalar and
     * a cell of a grid in the model. In this case the coordinates
     * are not used and no interpolation is done.
     * 
     * @return the value of field 'predictor'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML getPredictor()
    {
        return this._predictor;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML getPredictor() 

    /**
     * Returns the value of field 'state'. The field 'state' has
     * the following description: Specify the model state vectors
     * 
     * @return the value of field 'state'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML getState()
    {
        return this._state;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML getState() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'parameters'. The field 'parameters'
     * has the following description: Specify the model parameters
     * vectors
     * 
     * @param parameters the value of field 'parameters'.
     */
    public void setParameters(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML parameters)
    {
        this._parameters = parameters;
    } //-- void setParameters(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML) 

    /**
     * Sets the value of field 'predictor'. The field 'predictor'
     * has the following description: Specify the predictor
     * vectors. i.e. the model variables that correspond to the
     * observer variables. This can contain three different types
     * of mappings between model and observer variables:
     * 1. a vector for a mapping between an observed scalar and a
     * scalar in the model. In this case the coordinates are not
     * used and no interpolation is done.
     * 2. a vector for a mapping between an observed grid and a
     * grid in the model. In this case the model values are
     * interpolated to get values at the cell centers of the
     * observed grid. This uses the coordinates of both grids and
     * bilinear interpolation.
     * 3. a subVector for a mapping between an observed scalar and
     * a cell of a grid in the model. In this case the coordinates
     * are not used and no interpolation is done.
     * 
     * @param predictor the value of field 'predictor'.
     */
    public void setPredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML predictor)
    {
        this._predictor = predictor;
    } //-- void setPredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) 

    /**
     * Sets the value of field 'state'. The field 'state' has the
     * following description: Specify the model state vectors
     * 
     * @param state the value of field 'state'.
     */
    public void setState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML state)
    {
        this._state = state;
    } //-- void setState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) 

    /**
     * Method unmarshalBlackBoxStochModelVectorSpecificationXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML unmarshalBlackBoxStochModelVectorSpecificationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML unmarshalBlackBoxStochModelVectorSpecificationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
