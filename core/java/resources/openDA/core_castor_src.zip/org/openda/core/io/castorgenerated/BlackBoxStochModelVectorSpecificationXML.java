/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelVectorSpecificationXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelVectorSpecificationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the model parameters vectors
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML _parameters;

    /**
     * Specify the model state vectors
     */
    private java.util.ArrayList _stateList;

    /**
     * Specify the predictor vectors. i.e. the model variables that
     * correspond to the observer variables. This can contain three
     * different types of mappings between model and observer
     * variables:
     * 1. a vector for a mapping between an observed scalar and a
     * scalar in the model. In this case the coordinates are not
     * used and no interpolation is done.
     * 2. a vector for a mapping between an observed grid and a
     * grid in the model. In this case the model values are
     * interpolated to get values at the cell centers of the
     * observed grid. This uses the coordinates of both grids and
     * bilinear interpolation.
     * 3. a subVector for a mapping between an observed scalar and
     * a cell of a grid in the model. In this case the coordinates
     * are not used and no interpolation is done.
     */
    private java.util.ArrayList _predictorList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelVectorSpecificationXML() {
        super();
        _stateList = new ArrayList();
        _predictorList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addPredictor
     * 
     * @param vPredictor
     */
    public void addPredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML vPredictor)
        throws java.lang.IndexOutOfBoundsException
    {
        _predictorList.add(vPredictor);
    } //-- void addPredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) 

    /**
     * Method addPredictor
     * 
     * @param index
     * @param vPredictor
     */
    public void addPredictor(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML vPredictor)
        throws java.lang.IndexOutOfBoundsException
    {
        _predictorList.add(index, vPredictor);
    } //-- void addPredictor(int, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) 

    /**
     * Method addState
     * 
     * @param vState
     */
    public void addState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML vState)
        throws java.lang.IndexOutOfBoundsException
    {
        _stateList.add(vState);
    } //-- void addState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) 

    /**
     * Method addState
     * 
     * @param index
     * @param vState
     */
    public void addState(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML vState)
        throws java.lang.IndexOutOfBoundsException
    {
        _stateList.add(index, vState);
    } //-- void addState(int, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) 

    /**
     * Method clearPredictor
     */
    public void clearPredictor()
    {
        _predictorList.clear();
    } //-- void clearPredictor() 

    /**
     * Method clearState
     */
    public void clearState()
    {
        _stateList.clear();
    } //-- void clearState() 

    /**
     * Method enumeratePredictor
     */
    public java.util.Enumeration enumeratePredictor()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_predictorList.iterator());
    } //-- java.util.Enumeration enumeratePredictor() 

    /**
     * Method enumerateState
     */
    public java.util.Enumeration enumerateState()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_stateList.iterator());
    } //-- java.util.Enumeration enumerateState() 

    /**
     * Returns the value of field 'parameters'. The field
     * 'parameters' has the following description: Specify the
     * model parameters vectors
     * 
     * @return the value of field 'parameters'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML getParameters()
    {
        return this._parameters;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML getParameters() 

    /**
     * Method getPredictor
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML getPredictor(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _predictorList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) _predictorList.get(index);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML getPredictor(int) 

    /**
     * Method getPredictor
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML[] getPredictor()
    {
        int size = _predictorList.size();
        org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML[] mArray = new org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) _predictorList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML[] getPredictor() 

    /**
     * Method getPredictorCount
     */
    public int getPredictorCount()
    {
        return _predictorList.size();
    } //-- int getPredictorCount() 

    /**
     * Method getState
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML getState(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _stateList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) _stateList.get(index);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML getState(int) 

    /**
     * Method getState
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML[] getState()
    {
        int size = _stateList.size();
        org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML[] mArray = new org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) _stateList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML[] getState() 

    /**
     * Method getStateCount
     */
    public int getStateCount()
    {
        return _stateList.size();
    } //-- int getStateCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removePredictor
     * 
     * @param vPredictor
     */
    public boolean removePredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML vPredictor)
    {
        boolean removed = _predictorList.remove(vPredictor);
        return removed;
    } //-- boolean removePredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) 

    /**
     * Method removeState
     * 
     * @param vState
     */
    public boolean removeState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML vState)
    {
        boolean removed = _stateList.remove(vState);
        return removed;
    } //-- boolean removeState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) 

    /**
     * Sets the value of field 'parameters'. The field 'parameters'
     * has the following description: Specify the model parameters
     * vectors
     * 
     * @param parameters the value of field 'parameters'.
     */
    public void setParameters(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML parameters)
    {
        this._parameters = parameters;
    } //-- void setParameters(org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXML) 

    /**
     * Method setPredictor
     * 
     * @param index
     * @param vPredictor
     */
    public void setPredictor(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML vPredictor)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _predictorList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _predictorList.set(index, vPredictor);
    } //-- void setPredictor(int, org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) 

    /**
     * Method setPredictor
     * 
     * @param predictorArray
     */
    public void setPredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML[] predictorArray)
    {
        //-- copy array
        _predictorList.clear();
        for (int i = 0; i < predictorArray.length; i++) {
            _predictorList.add(predictorArray[i]);
        }
    } //-- void setPredictor(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorsXML) 

    /**
     * Method setState
     * 
     * @param index
     * @param vState
     */
    public void setState(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML vState)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _stateList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _stateList.set(index, vState);
    } //-- void setState(int, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) 

    /**
     * Method setState
     * 
     * @param stateArray
     */
    public void setState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML[] stateArray)
    {
        //-- copy array
        _stateList.clear();
        for (int i = 0; i < stateArray.length; i++) {
            _stateList.add(stateArray[i]);
        }
    } //-- void setState(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) 

    /**
     * Method unmarshalBlackBoxStochModelVectorSpecificationXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML unmarshalBlackBoxStochModelVectorSpecificationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML unmarshalBlackBoxStochModelVectorSpecificationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
