/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TemplateKeyDefinitionXML.
 * 
 * @version $Revision$ $Date$
 */
public class TemplateKeyDefinitionXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The id to be referred to by the alias.
     */
    private java.lang.String _id;

    /**
     * The name to be associated with the aliased key.
     */
    private java.lang.String _name;

    /**
     * The data type to which the alias key will be replaced
     * (default String).
     */
    private java.lang.String _targetType = "org.openda.blackbox.config.KeyTypeString";

    /**
     * Specify the prefix for the alias key.
     */
    private java.lang.String _keyPrefix;

    /**
     * Specify the suffix for the alias key.
     */
    private java.lang.String _keySuffix;


      //----------------/
     //- Constructors -/
    //----------------/

    public TemplateKeyDefinitionXML() {
        super();
        setTargetType("org.openda.blackbox.config.KeyTypeString");
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: The id to be referred to by the
     * alias.
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'keyPrefix'. The field
     * 'keyPrefix' has the following description: Specify the
     * prefix for the alias key.
     * 
     * @return the value of field 'keyPrefix'.
     */
    public java.lang.String getKeyPrefix()
    {
        return this._keyPrefix;
    } //-- java.lang.String getKeyPrefix() 

    /**
     * Returns the value of field 'keySuffix'. The field
     * 'keySuffix' has the following description: Specify the
     * suffix for the alias key.
     * 
     * @return the value of field 'keySuffix'.
     */
    public java.lang.String getKeySuffix()
    {
        return this._keySuffix;
    } //-- java.lang.String getKeySuffix() 

    /**
     * Returns the value of field 'name'. The field 'name' has the
     * following description: The name to be associated with the
     * aliased key.
     * 
     * @return the value of field 'name'.
     */
    public java.lang.String getName()
    {
        return this._name;
    } //-- java.lang.String getName() 

    /**
     * Returns the value of field 'targetType'. The field
     * 'targetType' has the following description: The data type to
     * which the alias key will be replaced (default String).
     * 
     * @return the value of field 'targetType'.
     */
    public java.lang.String getTargetType()
    {
        return this._targetType;
    } //-- java.lang.String getTargetType() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: The id to be referred to by the
     * alias.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'keyPrefix'. The field 'keyPrefix'
     * has the following description: Specify the prefix for the
     * alias key.
     * 
     * @param keyPrefix the value of field 'keyPrefix'.
     */
    public void setKeyPrefix(java.lang.String keyPrefix)
    {
        this._keyPrefix = keyPrefix;
    } //-- void setKeyPrefix(java.lang.String) 

    /**
     * Sets the value of field 'keySuffix'. The field 'keySuffix'
     * has the following description: Specify the suffix for the
     * alias key.
     * 
     * @param keySuffix the value of field 'keySuffix'.
     */
    public void setKeySuffix(java.lang.String keySuffix)
    {
        this._keySuffix = keySuffix;
    } //-- void setKeySuffix(java.lang.String) 

    /**
     * Sets the value of field 'name'. The field 'name' has the
     * following description: The name to be associated with the
     * aliased key.
     * 
     * @param name the value of field 'name'.
     */
    public void setName(java.lang.String name)
    {
        this._name = name;
    } //-- void setName(java.lang.String) 

    /**
     * Sets the value of field 'targetType'. The field 'targetType'
     * has the following description: The data type to which the
     * alias key will be replaced (default String).
     * 
     * @param targetType the value of field 'targetType'.
     */
    public void setTargetType(java.lang.String targetType)
    {
        this._targetType = targetType;
    } //-- void setTargetType(java.lang.String) 

    /**
     * Method unmarshalTemplateKeyDefinitionXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML unmarshalTemplateKeyDefinitionXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TemplateKeyDefinitionXML unmarshalTemplateKeyDefinitionXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
