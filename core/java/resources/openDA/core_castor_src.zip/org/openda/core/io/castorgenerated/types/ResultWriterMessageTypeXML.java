/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class ResultWriterMessageTypeXML.
 * 
 * @version $Revision$ $Date$
 */
public class ResultWriterMessageTypeXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The step type
     */
    public static final int STEP_TYPE = 0;

    /**
     * The instance of the step type
     */
    public static final ResultWriterMessageTypeXML STEP = new ResultWriterMessageTypeXML(STEP_TYPE, "step");

    /**
     * The outer type
     */
    public static final int OUTER_TYPE = 1;

    /**
     * The instance of the outer type
     */
    public static final ResultWriterMessageTypeXML OUTER = new ResultWriterMessageTypeXML(OUTER_TYPE, "outer");

    /**
     * The outerIter type
     */
    public static final int OUTERITER_TYPE = 2;

    /**
     * The instance of the outerIter type
     */
    public static final ResultWriterMessageTypeXML OUTERITER = new ResultWriterMessageTypeXML(OUTERITER_TYPE, "outerIter");

    /**
     * The outerIteration type
     */
    public static final int OUTERITERATION_TYPE = 3;

    /**
     * The instance of the outerIteration type
     */
    public static final ResultWriterMessageTypeXML OUTERITERATION = new ResultWriterMessageTypeXML(OUTERITERATION_TYPE, "outerIteration");

    /**
     * The inner type
     */
    public static final int INNER_TYPE = 4;

    /**
     * The instance of the inner type
     */
    public static final ResultWriterMessageTypeXML INNER = new ResultWriterMessageTypeXML(INNER_TYPE, "inner");

    /**
     * The innerIter type
     */
    public static final int INNERITER_TYPE = 5;

    /**
     * The instance of the innerIter type
     */
    public static final ResultWriterMessageTypeXML INNERITER = new ResultWriterMessageTypeXML(INNERITER_TYPE, "innerIter");

    /**
     * The innerIteration type
     */
    public static final int INNERITERATION_TYPE = 6;

    /**
     * The instance of the innerIteration type
     */
    public static final ResultWriterMessageTypeXML INNERITERATION = new ResultWriterMessageTypeXML(INNERITERATION_TYPE, "innerIteration");

    /**
     * The evaluation type
     */
    public static final int EVALUATION_TYPE = 7;

    /**
     * The instance of the evaluation type
     */
    public static final ResultWriterMessageTypeXML EVALUATION = new ResultWriterMessageTypeXML(EVALUATION_TYPE, "evaluation");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private ResultWriterMessageTypeXML(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of ResultWriterMessageTypeXML
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this
     * ResultWriterMessageTypeXML
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("step", STEP);
        members.put("outer", OUTER);
        members.put("outerIter", OUTERITER);
        members.put("outerIteration", OUTERITERATION);
        members.put("inner", INNER);
        members.put("innerIter", INNERITER);
        members.put("innerIteration", INNERITERATION);
        members.put("evaluation", EVALUATION);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * ResultWriterMessageTypeXML
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new ResultWriterMessageTypeXML based
     * on the given String value.
     * 
     * @param string
     */
    public static org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid ResultWriterMessageTypeXML";
            throw new IllegalArgumentException(err);
        }
        return (ResultWriterMessageTypeXML) obj;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML valueOf(java.lang.String) 

}
