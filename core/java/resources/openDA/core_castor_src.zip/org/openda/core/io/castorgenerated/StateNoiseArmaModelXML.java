/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class StateNoiseArmaModelXML.
 * 
 * @version $Revision$ $Date$
 */
public class StateNoiseArmaModelXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Operation type: add (default) or multiply
     */
    private org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML _operation = org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML.valueOf("add");

    /**
     * Field _stdDev
     */
    private org.openda.core.io.castorgenerated.StandardDeviationXML _stdDev;

    /**
     * ARMA constants, which reflects temporal correlation per
     * timestep of the ARMA model.
     */
    private java.util.ArrayList _armaConstantList;


      //----------------/
     //- Constructors -/
    //----------------/

    public StateNoiseArmaModelXML() {
        super();
        setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML.valueOf("add"));
        _armaConstantList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.StateNoiseArmaModelXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addArmaConstant
     * 
     * @param vArmaConstant
     */
    public void addArmaConstant(double vArmaConstant)
        throws java.lang.IndexOutOfBoundsException
    {
        _armaConstantList.add(new Double(vArmaConstant));
    } //-- void addArmaConstant(double) 

    /**
     * Method addArmaConstant
     * 
     * @param index
     * @param vArmaConstant
     */
    public void addArmaConstant(int index, double vArmaConstant)
        throws java.lang.IndexOutOfBoundsException
    {
        _armaConstantList.add(index, new Double(vArmaConstant));
    } //-- void addArmaConstant(int, double) 

    /**
     * Method clearArmaConstant
     */
    public void clearArmaConstant()
    {
        _armaConstantList.clear();
    } //-- void clearArmaConstant() 

    /**
     * Method enumerateArmaConstant
     */
    public java.util.Enumeration enumerateArmaConstant()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_armaConstantList.iterator());
    } //-- java.util.Enumeration enumerateArmaConstant() 

    /**
     * Method getArmaConstant
     * 
     * @param index
     */
    public double getArmaConstant(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _armaConstantList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return ((Double)_armaConstantList.get(index)).doubleValue();
    } //-- double getArmaConstant(int) 

    /**
     * Method getArmaConstant
     */
    public double[] getArmaConstant()
    {
        int size = _armaConstantList.size();
        double[] mArray = new double[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = ((Double)_armaConstantList.get(index)).doubleValue();
        }
        return mArray;
    } //-- double[] getArmaConstant() 

    /**
     * Method getArmaConstantCount
     */
    public int getArmaConstantCount()
    {
        return _armaConstantList.size();
    } //-- int getArmaConstantCount() 

    /**
     * Returns the value of field 'operation'. The field
     * 'operation' has the following description: Operation type:
     * add (default) or multiply
     * 
     * @return the value of field 'operation'.
     */
    public org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML getOperation()
    {
        return this._operation;
    } //-- org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML getOperation() 

    /**
     * Returns the value of field 'stdDev'.
     * 
     * @return the value of field 'stdDev'.
     */
    public org.openda.core.io.castorgenerated.StandardDeviationXML getStdDev()
    {
        return this._stdDev;
    } //-- org.openda.core.io.castorgenerated.StandardDeviationXML getStdDev() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeArmaConstant
     * 
     * @param vArmaConstant
     */
    public boolean removeArmaConstant(double vArmaConstant)
    {
        boolean removed = _armaConstantList.remove(new Double(vArmaConstant));
        return removed;
    } //-- boolean removeArmaConstant(double) 

    /**
     * Method setArmaConstant
     * 
     * @param index
     * @param vArmaConstant
     */
    public void setArmaConstant(int index, double vArmaConstant)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _armaConstantList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _armaConstantList.set(index, new Double(vArmaConstant));
    } //-- void setArmaConstant(int, double) 

    /**
     * Method setArmaConstant
     * 
     * @param armaConstantArray
     */
    public void setArmaConstant(double[] armaConstantArray)
    {
        //-- copy array
        _armaConstantList.clear();
        for (int i = 0; i < armaConstantArray.length; i++) {
            _armaConstantList.add(new Double(armaConstantArray[i]));
        }
    } //-- void setArmaConstant(double) 

    /**
     * Sets the value of field 'operation'. The field 'operation'
     * has the following description: Operation type: add (default)
     * or multiply
     * 
     * @param operation the value of field 'operation'.
     */
    public void setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML operation)
    {
        this._operation = operation;
    } //-- void setOperation(org.openda.core.io.castorgenerated.types.NoiseOperationTypesXML) 

    /**
     * Sets the value of field 'stdDev'.
     * 
     * @param stdDev the value of field 'stdDev'.
     */
    public void setStdDev(org.openda.core.io.castorgenerated.StandardDeviationXML stdDev)
    {
        this._stdDev = stdDev;
    } //-- void setStdDev(org.openda.core.io.castorgenerated.StandardDeviationXML) 

    /**
     * Method unmarshalStateNoiseArmaModelXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.StateNoiseArmaModelXML unmarshalStateNoiseArmaModelXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.StateNoiseArmaModelXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.StateNoiseArmaModelXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.StateNoiseArmaModelXML unmarshalStateNoiseArmaModelXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
