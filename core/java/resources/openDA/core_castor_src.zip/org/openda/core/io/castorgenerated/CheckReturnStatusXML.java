/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class CheckReturnStatusXML.
 * 
 * @version $Revision$ $Date$
 */
public class CheckReturnStatusXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Expected return value when the action is successful
     */
    private java.lang.String _expect;


      //----------------/
     //- Constructors -/
    //----------------/

    public CheckReturnStatusXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.CheckReturnStatusXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'expect'. The field 'expect' has
     * the following description: Expected return value when the
     * action is successful
     * 
     * @return the value of field 'expect'.
     */
    public java.lang.String getExpect()
    {
        return this._expect;
    } //-- java.lang.String getExpect() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'expect'. The field 'expect' has the
     * following description: Expected return value when the action
     * is successful
     * 
     * @param expect the value of field 'expect'.
     */
    public void setExpect(java.lang.String expect)
    {
        this._expect = expect;
    } //-- void setExpect(java.lang.String) 

    /**
     * Method unmarshalCheckReturnStatusXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.CheckReturnStatusXML unmarshalCheckReturnStatusXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.CheckReturnStatusXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.CheckReturnStatusXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.CheckReturnStatusXML unmarshalCheckReturnStatusXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
