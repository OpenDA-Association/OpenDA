/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TNC_times.
 * 
 * @version $Revision$ $Date$
 */
public class TNC_times implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selection
     */
    private org.openda.core.io.castorgenerated.TNC_selection _selection;


      //----------------/
     //- Constructors -/
    //----------------/

    public TNC_times() {
        super();
    } //-- org.openda.core.io.castorgenerated.TNC_times()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'selection'.
     * 
     * @return the value of field 'selection'.
     */
    public org.openda.core.io.castorgenerated.TNC_selection getSelection()
    {
        return this._selection;
    } //-- org.openda.core.io.castorgenerated.TNC_selection getSelection() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'selection'.
     * 
     * @param selection the value of field 'selection'.
     */
    public void setSelection(org.openda.core.io.castorgenerated.TNC_selection selection)
    {
        this._selection = selection;
    } //-- void setSelection(org.openda.core.io.castorgenerated.TNC_selection) 

    /**
     * Method unmarshalTNC_times
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TNC_times unmarshalTNC_times(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TNC_times) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TNC_times.class, reader);
    } //-- org.openda.core.io.castorgenerated.TNC_times unmarshalTNC_times(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
