/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class OpenDaResultWritersXML.
 * 
 * @version $Revision$ $Date$
 */
public class OpenDaResultWritersXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the content and format of the results file
     */
    private java.util.ArrayList _resultWriterList;


      //----------------/
     //- Constructors -/
    //----------------/

    public OpenDaResultWritersXML() {
        super();
        _resultWriterList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWritersXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addResultWriter
     * 
     * @param vResultWriter
     */
    public void addResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML vResultWriter)
        throws java.lang.IndexOutOfBoundsException
    {
        _resultWriterList.add(vResultWriter);
    } //-- void addResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML) 

    /**
     * Method addResultWriter
     * 
     * @param index
     * @param vResultWriter
     */
    public void addResultWriter(int index, org.openda.core.io.castorgenerated.OpenDaResultWriterXML vResultWriter)
        throws java.lang.IndexOutOfBoundsException
    {
        _resultWriterList.add(index, vResultWriter);
    } //-- void addResultWriter(int, org.openda.core.io.castorgenerated.OpenDaResultWriterXML) 

    /**
     * Method clearResultWriter
     */
    public void clearResultWriter()
    {
        _resultWriterList.clear();
    } //-- void clearResultWriter() 

    /**
     * Method enumerateResultWriter
     */
    public java.util.Enumeration enumerateResultWriter()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_resultWriterList.iterator());
    } //-- java.util.Enumeration enumerateResultWriter() 

    /**
     * Method getResultWriter
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.OpenDaResultWriterXML getResultWriter(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _resultWriterList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.OpenDaResultWriterXML) _resultWriterList.get(index);
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWriterXML getResultWriter(int) 

    /**
     * Method getResultWriter
     */
    public org.openda.core.io.castorgenerated.OpenDaResultWriterXML[] getResultWriter()
    {
        int size = _resultWriterList.size();
        org.openda.core.io.castorgenerated.OpenDaResultWriterXML[] mArray = new org.openda.core.io.castorgenerated.OpenDaResultWriterXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.OpenDaResultWriterXML) _resultWriterList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWriterXML[] getResultWriter() 

    /**
     * Method getResultWriterCount
     */
    public int getResultWriterCount()
    {
        return _resultWriterList.size();
    } //-- int getResultWriterCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeResultWriter
     * 
     * @param vResultWriter
     */
    public boolean removeResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML vResultWriter)
    {
        boolean removed = _resultWriterList.remove(vResultWriter);
        return removed;
    } //-- boolean removeResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML) 

    /**
     * Method setResultWriter
     * 
     * @param index
     * @param vResultWriter
     */
    public void setResultWriter(int index, org.openda.core.io.castorgenerated.OpenDaResultWriterXML vResultWriter)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _resultWriterList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _resultWriterList.set(index, vResultWriter);
    } //-- void setResultWriter(int, org.openda.core.io.castorgenerated.OpenDaResultWriterXML) 

    /**
     * Method setResultWriter
     * 
     * @param resultWriterArray
     */
    public void setResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML[] resultWriterArray)
    {
        //-- copy array
        _resultWriterList.clear();
        for (int i = 0; i < resultWriterArray.length; i++) {
            _resultWriterList.add(resultWriterArray[i]);
        }
    } //-- void setResultWriter(org.openda.core.io.castorgenerated.OpenDaResultWriterXML) 

    /**
     * Method unmarshalOpenDaResultWritersXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.OpenDaResultWritersXML unmarshalOpenDaResultWritersXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.OpenDaResultWritersXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.OpenDaResultWritersXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.OpenDaResultWritersXML unmarshalOpenDaResultWritersXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
