/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TNC_selection.
 * 
 * @version $Revision$ $Date$
 */
public class TNC_selection implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _variableList
     */
    private java.util.ArrayList _variableList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TNC_selection() {
        super();
        _variableList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.TNC_selection()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addVariable
     * 
     * @param vVariable
     */
    public void addVariable(org.openda.core.io.castorgenerated.TNC_variable vVariable)
        throws java.lang.IndexOutOfBoundsException
    {
        _variableList.add(vVariable);
    } //-- void addVariable(org.openda.core.io.castorgenerated.TNC_variable) 

    /**
     * Method addVariable
     * 
     * @param index
     * @param vVariable
     */
    public void addVariable(int index, org.openda.core.io.castorgenerated.TNC_variable vVariable)
        throws java.lang.IndexOutOfBoundsException
    {
        _variableList.add(index, vVariable);
    } //-- void addVariable(int, org.openda.core.io.castorgenerated.TNC_variable) 

    /**
     * Method clearVariable
     */
    public void clearVariable()
    {
        _variableList.clear();
    } //-- void clearVariable() 

    /**
     * Method enumerateVariable
     */
    public java.util.Enumeration enumerateVariable()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_variableList.iterator());
    } //-- java.util.Enumeration enumerateVariable() 

    /**
     * Method getVariable
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TNC_variable getVariable(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _variableList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TNC_variable) _variableList.get(index);
    } //-- org.openda.core.io.castorgenerated.TNC_variable getVariable(int) 

    /**
     * Method getVariable
     */
    public org.openda.core.io.castorgenerated.TNC_variable[] getVariable()
    {
        int size = _variableList.size();
        org.openda.core.io.castorgenerated.TNC_variable[] mArray = new org.openda.core.io.castorgenerated.TNC_variable[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TNC_variable) _variableList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TNC_variable[] getVariable() 

    /**
     * Method getVariableCount
     */
    public int getVariableCount()
    {
        return _variableList.size();
    } //-- int getVariableCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeVariable
     * 
     * @param vVariable
     */
    public boolean removeVariable(org.openda.core.io.castorgenerated.TNC_variable vVariable)
    {
        boolean removed = _variableList.remove(vVariable);
        return removed;
    } //-- boolean removeVariable(org.openda.core.io.castorgenerated.TNC_variable) 

    /**
     * Method setVariable
     * 
     * @param index
     * @param vVariable
     */
    public void setVariable(int index, org.openda.core.io.castorgenerated.TNC_variable vVariable)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _variableList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _variableList.set(index, vVariable);
    } //-- void setVariable(int, org.openda.core.io.castorgenerated.TNC_variable) 

    /**
     * Method setVariable
     * 
     * @param variableArray
     */
    public void setVariable(org.openda.core.io.castorgenerated.TNC_variable[] variableArray)
    {
        //-- copy array
        _variableList.clear();
        for (int i = 0; i < variableArray.length; i++) {
            _variableList.add(variableArray[i]);
        }
    } //-- void setVariable(org.openda.core.io.castorgenerated.TNC_variable) 

    /**
     * Method unmarshalTNC_selection
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TNC_selection unmarshalTNC_selection(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TNC_selection) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TNC_selection.class, reader);
    } //-- org.openda.core.io.castorgenerated.TNC_selection unmarshalTNC_selection(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
