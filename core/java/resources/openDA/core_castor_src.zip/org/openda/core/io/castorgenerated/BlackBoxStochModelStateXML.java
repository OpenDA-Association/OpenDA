/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelStateXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelStateXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelStateXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBlackBoxStochModelStateXMLItem
     * 
     * @param vBlackBoxStochModelStateXMLItem
     */
    public void addBlackBoxStochModelStateXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem vBlackBoxStochModelStateXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vBlackBoxStochModelStateXMLItem);
    } //-- void addBlackBoxStochModelStateXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) 

    /**
     * Method addBlackBoxStochModelStateXMLItem
     * 
     * @param index
     * @param vBlackBoxStochModelStateXMLItem
     */
    public void addBlackBoxStochModelStateXMLItem(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem vBlackBoxStochModelStateXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vBlackBoxStochModelStateXMLItem);
    } //-- void addBlackBoxStochModelStateXMLItem(int, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) 

    /**
     * Method clearBlackBoxStochModelStateXMLItem
     */
    public void clearBlackBoxStochModelStateXMLItem()
    {
        _items.clear();
    } //-- void clearBlackBoxStochModelStateXMLItem() 

    /**
     * Method enumerateBlackBoxStochModelStateXMLItem
     */
    public java.util.Enumeration enumerateBlackBoxStochModelStateXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateBlackBoxStochModelStateXMLItem() 

    /**
     * Method getBlackBoxStochModelStateXMLItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem getBlackBoxStochModelStateXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) _items.get(index);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem getBlackBoxStochModelStateXMLItem(int) 

    /**
     * Method getBlackBoxStochModelStateXMLItem
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem[] getBlackBoxStochModelStateXMLItem()
    {
        int size = _items.size();
        org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem[] mArray = new org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem[] getBlackBoxStochModelStateXMLItem() 

    /**
     * Method getBlackBoxStochModelStateXMLItemCount
     */
    public int getBlackBoxStochModelStateXMLItemCount()
    {
        return _items.size();
    } //-- int getBlackBoxStochModelStateXMLItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBlackBoxStochModelStateXMLItem
     * 
     * @param vBlackBoxStochModelStateXMLItem
     */
    public boolean removeBlackBoxStochModelStateXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem vBlackBoxStochModelStateXMLItem)
    {
        boolean removed = _items.remove(vBlackBoxStochModelStateXMLItem);
        return removed;
    } //-- boolean removeBlackBoxStochModelStateXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) 

    /**
     * Method setBlackBoxStochModelStateXMLItem
     * 
     * @param index
     * @param vBlackBoxStochModelStateXMLItem
     */
    public void setBlackBoxStochModelStateXMLItem(int index, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem vBlackBoxStochModelStateXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vBlackBoxStochModelStateXMLItem);
    } //-- void setBlackBoxStochModelStateXMLItem(int, org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) 

    /**
     * Method setBlackBoxStochModelStateXMLItem
     * 
     * @param blackBoxStochModelStateXMLItemArray
     */
    public void setBlackBoxStochModelStateXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem[] blackBoxStochModelStateXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < blackBoxStochModelStateXMLItemArray.length; i++) {
            _items.add(blackBoxStochModelStateXMLItemArray[i]);
        }
    } //-- void setBlackBoxStochModelStateXMLItem(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXMLItem) 

    /**
     * Method unmarshalBlackBoxStochModelStateXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML unmarshalBlackBoxStochModelStateXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelStateXML unmarshalBlackBoxStochModelStateXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
