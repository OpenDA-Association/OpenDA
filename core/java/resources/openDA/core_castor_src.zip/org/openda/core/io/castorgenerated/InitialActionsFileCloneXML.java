/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class InitialActionsFileCloneXML.
 * 
 * @version $Revision$ $Date$
 */
public class InitialActionsFileCloneXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Name of the template file.
     */
    private java.lang.String _templateFile;

    /**
     * File name of the instance of the template file.
     */
    private java.lang.String _instanceFile;

    /**
     * Specify the consecutive actions by model executables or
     * classes to run, arguments to supply and fail/success checks
     * to perform
     */
    private java.util.ArrayList _actionList;


      //----------------/
     //- Constructors -/
    //----------------/

    public InitialActionsFileCloneXML() {
        super();
        _actionList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.InitialActionsFileCloneXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addAction
     * 
     * @param vAction
     */
    public void addAction(org.openda.core.io.castorgenerated.ActionXML vAction)
        throws java.lang.IndexOutOfBoundsException
    {
        _actionList.add(vAction);
    } //-- void addAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method addAction
     * 
     * @param index
     * @param vAction
     */
    public void addAction(int index, org.openda.core.io.castorgenerated.ActionXML vAction)
        throws java.lang.IndexOutOfBoundsException
    {
        _actionList.add(index, vAction);
    } //-- void addAction(int, org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method clearAction
     */
    public void clearAction()
    {
        _actionList.clear();
    } //-- void clearAction() 

    /**
     * Method enumerateAction
     */
    public java.util.Enumeration enumerateAction()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_actionList.iterator());
    } //-- java.util.Enumeration enumerateAction() 

    /**
     * Method getAction
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.ActionXML getAction(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _actionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.ActionXML) _actionList.get(index);
    } //-- org.openda.core.io.castorgenerated.ActionXML getAction(int) 

    /**
     * Method getAction
     */
    public org.openda.core.io.castorgenerated.ActionXML[] getAction()
    {
        int size = _actionList.size();
        org.openda.core.io.castorgenerated.ActionXML[] mArray = new org.openda.core.io.castorgenerated.ActionXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.ActionXML) _actionList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.ActionXML[] getAction() 

    /**
     * Method getActionCount
     */
    public int getActionCount()
    {
        return _actionList.size();
    } //-- int getActionCount() 

    /**
     * Returns the value of field 'instanceFile'. The field
     * 'instanceFile' has the following description: File name of
     * the instance of the template file.
     * 
     * @return the value of field 'instanceFile'.
     */
    public java.lang.String getInstanceFile()
    {
        return this._instanceFile;
    } //-- java.lang.String getInstanceFile() 

    /**
     * Returns the value of field 'templateFile'. The field
     * 'templateFile' has the following description: Name of the
     * template file.
     * 
     * @return the value of field 'templateFile'.
     */
    public java.lang.String getTemplateFile()
    {
        return this._templateFile;
    } //-- java.lang.String getTemplateFile() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAction
     * 
     * @param vAction
     */
    public boolean removeAction(org.openda.core.io.castorgenerated.ActionXML vAction)
    {
        boolean removed = _actionList.remove(vAction);
        return removed;
    } //-- boolean removeAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method setAction
     * 
     * @param index
     * @param vAction
     */
    public void setAction(int index, org.openda.core.io.castorgenerated.ActionXML vAction)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _actionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _actionList.set(index, vAction);
    } //-- void setAction(int, org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Method setAction
     * 
     * @param actionArray
     */
    public void setAction(org.openda.core.io.castorgenerated.ActionXML[] actionArray)
    {
        //-- copy array
        _actionList.clear();
        for (int i = 0; i < actionArray.length; i++) {
            _actionList.add(actionArray[i]);
        }
    } //-- void setAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Sets the value of field 'instanceFile'. The field
     * 'instanceFile' has the following description: File name of
     * the instance of the template file.
     * 
     * @param instanceFile the value of field 'instanceFile'.
     */
    public void setInstanceFile(java.lang.String instanceFile)
    {
        this._instanceFile = instanceFile;
    } //-- void setInstanceFile(java.lang.String) 

    /**
     * Sets the value of field 'templateFile'. The field
     * 'templateFile' has the following description: Name of the
     * template file.
     * 
     * @param templateFile the value of field 'templateFile'.
     */
    public void setTemplateFile(java.lang.String templateFile)
    {
        this._templateFile = templateFile;
    } //-- void setTemplateFile(java.lang.String) 

    /**
     * Method unmarshalInitialActionsFileCloneXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.InitialActionsFileCloneXML unmarshalInitialActionsFileCloneXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.InitialActionsFileCloneXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.InitialActionsFileCloneXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.InitialActionsFileCloneXML unmarshalInitialActionsFileCloneXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
