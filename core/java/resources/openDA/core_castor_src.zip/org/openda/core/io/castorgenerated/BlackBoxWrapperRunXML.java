/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxWrapperRunXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxWrapperRunXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Configure method for model initialization. Select one of the
     * three options.
     */
    private org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice _blackBoxWrapperRunXMLChoice;

    /**
     * Configure the method for model computation
     */
    private org.openda.core.io.castorgenerated.ActionsXML _computeActions;

    /**
     * Configure the actions that should be performed after all
     * other computation actions (used for instance when the actual
     * computation is sent to a queue. The additional computation
     * action can then be used to start a script that checks the
     * status of the queue.
     */
    private org.openda.core.io.castorgenerated.ActionsXML _additionalComputeActions;

    /**
     * Configure the method for model finalization
     */
    private org.openda.core.io.castorgenerated.ActionsXML _finalizeActions;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxWrapperRunXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'additionalComputeActions'. The
     * field 'additionalComputeActions' has the following
     * description: Configure the actions that should be performed
     * after all other computation actions (used for instance when
     * the actual computation is sent to a queue. The additional
     * computation action can then be used to start a script that
     * checks the status of the queue.
     * 
     * @return the value of field 'additionalComputeActions'.
     */
    public org.openda.core.io.castorgenerated.ActionsXML getAdditionalComputeActions()
    {
        return this._additionalComputeActions;
    } //-- org.openda.core.io.castorgenerated.ActionsXML getAdditionalComputeActions() 

    /**
     * Returns the value of field 'blackBoxWrapperRunXMLChoice'.
     * The field 'blackBoxWrapperRunXMLChoice' has the following
     * description: Configure method for model initialization.
     * Select one of the three options.
     * 
     * @return the value of field 'blackBoxWrapperRunXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice getBlackBoxWrapperRunXMLChoice()
    {
        return this._blackBoxWrapperRunXMLChoice;
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice getBlackBoxWrapperRunXMLChoice() 

    /**
     * Returns the value of field 'computeActions'. The field
     * 'computeActions' has the following description: Configure
     * the method for model computation
     * 
     * @return the value of field 'computeActions'.
     */
    public org.openda.core.io.castorgenerated.ActionsXML getComputeActions()
    {
        return this._computeActions;
    } //-- org.openda.core.io.castorgenerated.ActionsXML getComputeActions() 

    /**
     * Returns the value of field 'finalizeActions'. The field
     * 'finalizeActions' has the following description: Configure
     * the method for model finalization
     * 
     * @return the value of field 'finalizeActions'.
     */
    public org.openda.core.io.castorgenerated.ActionsXML getFinalizeActions()
    {
        return this._finalizeActions;
    } //-- org.openda.core.io.castorgenerated.ActionsXML getFinalizeActions() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'additionalComputeActions'. The
     * field 'additionalComputeActions' has the following
     * description: Configure the actions that should be performed
     * after all other computation actions (used for instance when
     * the actual computation is sent to a queue. The additional
     * computation action can then be used to start a script that
     * checks the status of the queue.
     * 
     * @param additionalComputeActions the value of field
     * 'additionalComputeActions'.
     */
    public void setAdditionalComputeActions(org.openda.core.io.castorgenerated.ActionsXML additionalComputeActions)
    {
        this._additionalComputeActions = additionalComputeActions;
    } //-- void setAdditionalComputeActions(org.openda.core.io.castorgenerated.ActionsXML) 

    /**
     * Sets the value of field 'blackBoxWrapperRunXMLChoice'. The
     * field 'blackBoxWrapperRunXMLChoice' has the following
     * description: Configure method for model initialization.
     * Select one of the three options.
     * 
     * @param blackBoxWrapperRunXMLChoice the value of field
     * 'blackBoxWrapperRunXMLChoice'.
     */
    public void setBlackBoxWrapperRunXMLChoice(org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice blackBoxWrapperRunXMLChoice)
    {
        this._blackBoxWrapperRunXMLChoice = blackBoxWrapperRunXMLChoice;
    } //-- void setBlackBoxWrapperRunXMLChoice(org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice) 

    /**
     * Sets the value of field 'computeActions'. The field
     * 'computeActions' has the following description: Configure
     * the method for model computation
     * 
     * @param computeActions the value of field 'computeActions'.
     */
    public void setComputeActions(org.openda.core.io.castorgenerated.ActionsXML computeActions)
    {
        this._computeActions = computeActions;
    } //-- void setComputeActions(org.openda.core.io.castorgenerated.ActionsXML) 

    /**
     * Sets the value of field 'finalizeActions'. The field
     * 'finalizeActions' has the following description: Configure
     * the method for model finalization
     * 
     * @param finalizeActions the value of field 'finalizeActions'.
     */
    public void setFinalizeActions(org.openda.core.io.castorgenerated.ActionsXML finalizeActions)
    {
        this._finalizeActions = finalizeActions;
    } //-- void setFinalizeActions(org.openda.core.io.castorgenerated.ActionsXML) 

    /**
     * Method unmarshalBlackBoxWrapperRunXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML unmarshalBlackBoxWrapperRunXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperRunXML unmarshalBlackBoxWrapperRunXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
