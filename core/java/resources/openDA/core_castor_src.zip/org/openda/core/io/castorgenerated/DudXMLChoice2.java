/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DudXMLChoice2.
 * 
 * @version $Revision$ $Date$
 */
public class DudXMLChoice2 implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field dudXMLChoice2Item
     */
    private org.openda.core.io.castorgenerated.DudXMLChoice2Item dudXMLChoice2Item;


      //----------------/
     //- Constructors -/
    //----------------/

    public DudXMLChoice2() {
        super();
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice2()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dudXMLChoice2Item'.
     * 
     * @return the value of field 'dudXMLChoice2Item'.
     */
    public org.openda.core.io.castorgenerated.DudXMLChoice2Item getDudXMLChoice2Item()
    {
        return this.dudXMLChoice2Item;
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice2Item getDudXMLChoice2Item() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dudXMLChoice2Item'.
     * 
     * @param dudXMLChoice2Item the value of field
     * 'dudXMLChoice2Item'.
     */
    public void setDudXMLChoice2Item(org.openda.core.io.castorgenerated.DudXMLChoice2Item dudXMLChoice2Item)
    {
        this.dudXMLChoice2Item = dudXMLChoice2Item;
    } //-- void setDudXMLChoice2Item(org.openda.core.io.castorgenerated.DudXMLChoice2Item) 

    /**
     * Method unmarshalDudXMLChoice2
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.DudXMLChoice2 unmarshalDudXMLChoice2(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.DudXMLChoice2) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.DudXMLChoice2.class, reader);
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice2 unmarshalDudXMLChoice2(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
