/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class RegularisationConstantXMLChoice2Item.
 * 
 * @version $Revision$ $Date$
 */
public class RegularisationConstantXMLChoice2Item implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Select the whole parameter vector
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML _vector;

    /**
     * Select only a part of the parameter vector
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML _subVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public RegularisationConstantXMLChoice2Item() {
        super();
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice2Item()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'subVector'. The field
     * 'subVector' has the following description: Select only a
     * part of the parameter vector
     * 
     * @return the value of field 'subVector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML getSubVector()
    {
        return this._subVector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML getSubVector() 

    /**
     * Returns the value of field 'vector'. The field 'vector' has
     * the following description: Select the whole parameter vector
     * 
     * @return the value of field 'vector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML getVector()
    {
        return this._vector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML getVector() 

    /**
     * Sets the value of field 'subVector'. The field 'subVector'
     * has the following description: Select only a part of the
     * parameter vector
     * 
     * @param subVector the value of field 'subVector'.
     */
    public void setSubVector(org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML subVector)
    {
        this._subVector = subVector;
    } //-- void setSubVector(org.openda.core.io.castorgenerated.BlackBoxStochModelSubVectorXML) 

    /**
     * Sets the value of field 'vector'. The field 'vector' has the
     * following description: Select the whole parameter vector
     * 
     * @param vector the value of field 'vector'.
     */
    public void setVector(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML vector)
    {
        this._vector = vector;
    } //-- void setVector(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorXML) 

}
