/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Select one of the options
 * 
 * @version $Revision$ $Date$
 */
public class OpenDaAlgorithmXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the name of the algorithm configuration file stored
     * in the working directory
     */
    private java.lang.String _configFile;

    /**
     * Specify the configuration string (whether a configFile or
     * configString is required depends on the choice of algorithm) 
     */
    private java.lang.String _configString;


      //----------------/
     //- Constructors -/
    //----------------/

    public OpenDaAlgorithmXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.OpenDaAlgorithmXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'configFile'. The field
     * 'configFile' has the following description: Specify the name
     * of the algorithm configuration file stored in the working
     * directory
     * 
     * @return the value of field 'configFile'.
     */
    public java.lang.String getConfigFile()
    {
        return this._configFile;
    } //-- java.lang.String getConfigFile() 

    /**
     * Returns the value of field 'configString'. The field
     * 'configString' has the following description: Specify the
     * configuration string (whether a configFile or configString
     * is required depends on the choice of algorithm) 
     * 
     * @return the value of field 'configString'.
     */
    public java.lang.String getConfigString()
    {
        return this._configString;
    } //-- java.lang.String getConfigString() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'configFile'. The field 'configFile'
     * has the following description: Specify the name of the
     * algorithm configuration file stored in the working directory
     * 
     * @param configFile the value of field 'configFile'.
     */
    public void setConfigFile(java.lang.String configFile)
    {
        this._configFile = configFile;
    } //-- void setConfigFile(java.lang.String) 

    /**
     * Sets the value of field 'configString'. The field
     * 'configString' has the following description: Specify the
     * configuration string (whether a configFile or configString
     * is required depends on the choice of algorithm) 
     * 
     * @param configString the value of field 'configString'.
     */
    public void setConfigString(java.lang.String configString)
    {
        this._configString = configString;
    } //-- void setConfigString(java.lang.String) 

    /**
     * Method unmarshalOpenDaAlgorithmXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.OpenDaAlgorithmXMLChoice unmarshalOpenDaAlgorithmXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.OpenDaAlgorithmXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.OpenDaAlgorithmXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.OpenDaAlgorithmXMLChoice unmarshalOpenDaAlgorithmXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
