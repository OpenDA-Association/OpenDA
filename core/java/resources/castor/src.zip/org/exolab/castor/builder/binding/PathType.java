/*
 * This class was automatically generated with 
 * <a href="http://castor.exolab.org">Castor 0.9.4</a>, using an
 * XML Schema.
 * $Id: PathType.java,v 1.1.1.1 2003/03/03 07:07:53 kvisco Exp $
 */

package org.exolab.castor.builder.binding;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.*;

/**
 * 
 *                  This type represents an easy path to access an
 * element or an attribute
 *                  inside a schema. It is a direct restriction of
 * the XPath specification.
 *              
 * 
 * @version $Revision: 1.1.1.1 $ $Date: 2003/03/03 07:07:53 $
**/
public class PathType implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public PathType() {
        super();
    } //-- org.exolab.castor.builder.binding.PathType()

}
