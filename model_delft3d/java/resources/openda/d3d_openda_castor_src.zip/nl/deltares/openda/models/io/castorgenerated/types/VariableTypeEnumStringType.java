/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class VariableTypeEnumStringType.
 * 
 * @version $Revision$ $Date$
 */
public class VariableTypeEnumStringType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The CONTINUOUS type
     */
    public static final int CONTINUOUS_TYPE = 0;

    /**
     * The instance of the CONTINUOUS type
     */
    public static final VariableTypeEnumStringType CONTINUOUS = new VariableTypeEnumStringType(CONTINUOUS_TYPE, "CONTINUOUS");

    /**
     * The INTEGER type
     */
    public static final int INTEGER_TYPE = 1;

    /**
     * The instance of the INTEGER type
     */
    public static final VariableTypeEnumStringType INTEGER = new VariableTypeEnumStringType(INTEGER_TYPE, "INTEGER");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private VariableTypeEnumStringType(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- nl.deltares.openda.models.io.castorgenerated.types.VariableTypeEnumStringType(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of VariableTypeEnumStringType
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this
     * VariableTypeEnumStringType
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("CONTINUOUS", CONTINUOUS);
        members.put("INTEGER", INTEGER);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * VariableTypeEnumStringType
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new VariableTypeEnumStringType based
     * on the given String value.
     * 
     * @param string
     */
    public static nl.deltares.openda.models.io.castorgenerated.types.VariableTypeEnumStringType valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid VariableTypeEnumStringType";
            throw new IllegalArgumentException(err);
        }
        return (VariableTypeEnumStringType) obj;
    } //-- nl.deltares.openda.models.io.castorgenerated.types.VariableTypeEnumStringType valueOf(java.lang.String) 

}
