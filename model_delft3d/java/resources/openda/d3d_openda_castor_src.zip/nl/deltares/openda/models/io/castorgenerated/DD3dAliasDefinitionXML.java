/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dAliasDefinitionXML.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dAliasDefinitionXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The name to be associated with the aliased value.
     */
    private java.lang.String _key;

    /**
     * Actual value referred to by the alias key.
     */
    private java.lang.String _value;

    /**
     * Specify the prefix for the alias key.
     */
    private java.lang.String _keyPrefix;

    /**
     * Specify the suffix for the alias key.
     */
    private java.lang.String _keySuffix;

    /**
     * Field _listValueList
     */
    private java.util.ArrayList _listValueList;


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dAliasDefinitionXML() {
        super();
        _listValueList = new ArrayList();
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addListValue
     * 
     * @param vListValue
     */
    public void addListValue(java.lang.String vListValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _listValueList.add(vListValue);
    } //-- void addListValue(java.lang.String) 

    /**
     * Method addListValue
     * 
     * @param index
     * @param vListValue
     */
    public void addListValue(int index, java.lang.String vListValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _listValueList.add(index, vListValue);
    } //-- void addListValue(int, java.lang.String) 

    /**
     * Method clearListValue
     */
    public void clearListValue()
    {
        _listValueList.clear();
    } //-- void clearListValue() 

    /**
     * Method enumerateListValue
     */
    public java.util.Enumeration enumerateListValue()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_listValueList.iterator());
    } //-- java.util.Enumeration enumerateListValue() 

    /**
     * Returns the value of field 'key'. The field 'key' has the
     * following description: The name to be associated with the
     * aliased value.
     * 
     * @return the value of field 'key'.
     */
    public java.lang.String getKey()
    {
        return this._key;
    } //-- java.lang.String getKey() 

    /**
     * Returns the value of field 'keyPrefix'. The field
     * 'keyPrefix' has the following description: Specify the
     * prefix for the alias key.
     * 
     * @return the value of field 'keyPrefix'.
     */
    public java.lang.String getKeyPrefix()
    {
        return this._keyPrefix;
    } //-- java.lang.String getKeyPrefix() 

    /**
     * Returns the value of field 'keySuffix'. The field
     * 'keySuffix' has the following description: Specify the
     * suffix for the alias key.
     * 
     * @return the value of field 'keySuffix'.
     */
    public java.lang.String getKeySuffix()
    {
        return this._keySuffix;
    } //-- java.lang.String getKeySuffix() 

    /**
     * Method getListValue
     * 
     * @param index
     */
    public java.lang.String getListValue(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _listValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_listValueList.get(index);
    } //-- java.lang.String getListValue(int) 

    /**
     * Method getListValue
     */
    public java.lang.String[] getListValue()
    {
        int size = _listValueList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_listValueList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getListValue() 

    /**
     * Method getListValueCount
     */
    public int getListValueCount()
    {
        return _listValueList.size();
    } //-- int getListValueCount() 

    /**
     * Returns the value of field 'value'. The field 'value' has
     * the following description: Actual value referred to by the
     * alias key.
     * 
     * @return the value of field 'value'.
     */
    public java.lang.String getValue()
    {
        return this._value;
    } //-- java.lang.String getValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeListValue
     * 
     * @param vListValue
     */
    public boolean removeListValue(java.lang.String vListValue)
    {
        boolean removed = _listValueList.remove(vListValue);
        return removed;
    } //-- boolean removeListValue(java.lang.String) 

    /**
     * Sets the value of field 'key'. The field 'key' has the
     * following description: The name to be associated with the
     * aliased value.
     * 
     * @param key the value of field 'key'.
     */
    public void setKey(java.lang.String key)
    {
        this._key = key;
    } //-- void setKey(java.lang.String) 

    /**
     * Sets the value of field 'keyPrefix'. The field 'keyPrefix'
     * has the following description: Specify the prefix for the
     * alias key.
     * 
     * @param keyPrefix the value of field 'keyPrefix'.
     */
    public void setKeyPrefix(java.lang.String keyPrefix)
    {
        this._keyPrefix = keyPrefix;
    } //-- void setKeyPrefix(java.lang.String) 

    /**
     * Sets the value of field 'keySuffix'. The field 'keySuffix'
     * has the following description: Specify the suffix for the
     * alias key.
     * 
     * @param keySuffix the value of field 'keySuffix'.
     */
    public void setKeySuffix(java.lang.String keySuffix)
    {
        this._keySuffix = keySuffix;
    } //-- void setKeySuffix(java.lang.String) 

    /**
     * Method setListValue
     * 
     * @param index
     * @param vListValue
     */
    public void setListValue(int index, java.lang.String vListValue)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _listValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _listValueList.set(index, vListValue);
    } //-- void setListValue(int, java.lang.String) 

    /**
     * Method setListValue
     * 
     * @param listValueArray
     */
    public void setListValue(java.lang.String[] listValueArray)
    {
        //-- copy array
        _listValueList.clear();
        for (int i = 0; i < listValueArray.length; i++) {
            _listValueList.add(listValueArray[i]);
        }
    } //-- void setListValue(java.lang.String) 

    /**
     * Sets the value of field 'value'. The field 'value' has the
     * following description: Actual value referred to by the alias
     * key.
     * 
     * @param value the value of field 'value'.
     */
    public void setValue(java.lang.String value)
    {
        this._value = value;
    } //-- void setValue(java.lang.String) 

    /**
     * Method unmarshalDD3dAliasDefinitionXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML unmarshalDD3dAliasDefinitionXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML unmarshalDD3dAliasDefinitionXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
