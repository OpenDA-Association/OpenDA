/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DComponentXML.
 * 
 * @version $Revision$ $Date$
 */
public class DComponentXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Openda:class name.
     */
    private java.lang.String _className;

    /**
     * Working directory relative to the configuration directory.
     */
    private java.lang.String _workingDir;

    /**
     * Input argument to the respective openda:class.
     */
    private java.util.ArrayList _argumentList;


      //----------------/
     //- Constructors -/
    //----------------/

    public DComponentXML() {
        super();
        _argumentList = new ArrayList();
    } //-- nl.deltares.openda.models.io.castorgenerated.DComponentXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addArgument
     * 
     * @param vArgument
     */
    public void addArgument(java.lang.String vArgument)
        throws java.lang.IndexOutOfBoundsException
    {
        _argumentList.add(vArgument);
    } //-- void addArgument(java.lang.String) 

    /**
     * Method addArgument
     * 
     * @param index
     * @param vArgument
     */
    public void addArgument(int index, java.lang.String vArgument)
        throws java.lang.IndexOutOfBoundsException
    {
        _argumentList.add(index, vArgument);
    } //-- void addArgument(int, java.lang.String) 

    /**
     * Method clearArgument
     */
    public void clearArgument()
    {
        _argumentList.clear();
    } //-- void clearArgument() 

    /**
     * Method enumerateArgument
     */
    public java.util.Enumeration enumerateArgument()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_argumentList.iterator());
    } //-- java.util.Enumeration enumerateArgument() 

    /**
     * Method getArgument
     * 
     * @param index
     */
    public java.lang.String getArgument(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argumentList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_argumentList.get(index);
    } //-- java.lang.String getArgument(int) 

    /**
     * Method getArgument
     */
    public java.lang.String[] getArgument()
    {
        int size = _argumentList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_argumentList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getArgument() 

    /**
     * Method getArgumentCount
     */
    public int getArgumentCount()
    {
        return _argumentList.size();
    } //-- int getArgumentCount() 

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: Openda:class
     * name.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'workingDir'. The field
     * 'workingDir' has the following description: Working
     * directory relative to the configuration directory.
     * 
     * @return the value of field 'workingDir'.
     */
    public java.lang.String getWorkingDir()
    {
        return this._workingDir;
    } //-- java.lang.String getWorkingDir() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeArgument
     * 
     * @param vArgument
     */
    public boolean removeArgument(java.lang.String vArgument)
    {
        boolean removed = _argumentList.remove(vArgument);
        return removed;
    } //-- boolean removeArgument(java.lang.String) 

    /**
     * Method setArgument
     * 
     * @param index
     * @param vArgument
     */
    public void setArgument(int index, java.lang.String vArgument)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argumentList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _argumentList.set(index, vArgument);
    } //-- void setArgument(int, java.lang.String) 

    /**
     * Method setArgument
     * 
     * @param argumentArray
     */
    public void setArgument(java.lang.String[] argumentArray)
    {
        //-- copy array
        _argumentList.clear();
        for (int i = 0; i < argumentArray.length; i++) {
            _argumentList.add(argumentArray[i]);
        }
    } //-- void setArgument(java.lang.String) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: Openda:class name.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'workingDir'. The field 'workingDir'
     * has the following description: Working directory relative to
     * the configuration directory.
     * 
     * @param workingDir the value of field 'workingDir'.
     */
    public void setWorkingDir(java.lang.String workingDir)
    {
        this._workingDir = workingDir;
    } //-- void setWorkingDir(java.lang.String) 

    /**
     * Method unmarshalDComponentXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DComponentXML unmarshalDComponentXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DComponentXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DComponentXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DComponentXML unmarshalDComponentXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
