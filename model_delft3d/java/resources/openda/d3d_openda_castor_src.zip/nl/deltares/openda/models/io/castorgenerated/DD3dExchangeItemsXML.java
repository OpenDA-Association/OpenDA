/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dExchangeItemsXML.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dExchangeItemsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * List of exchange items that will be part of the modelling
     * process
     */
    private java.util.ArrayList _exchangeItemList;


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dExchangeItemsXML() {
        super();
        _exchangeItemList = new ArrayList();
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addExchangeItem
     * 
     * @param vExchangeItem
     */
    public void addExchangeItem(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _exchangeItemList.add(vExchangeItem);
    } //-- void addExchangeItem(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) 

    /**
     * Method addExchangeItem
     * 
     * @param index
     * @param vExchangeItem
     */
    public void addExchangeItem(int index, nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _exchangeItemList.add(index, vExchangeItem);
    } //-- void addExchangeItem(int, nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) 

    /**
     * Method clearExchangeItem
     */
    public void clearExchangeItem()
    {
        _exchangeItemList.clear();
    } //-- void clearExchangeItem() 

    /**
     * Method enumerateExchangeItem
     */
    public java.util.Enumeration enumerateExchangeItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_exchangeItemList.iterator());
    } //-- java.util.Enumeration enumerateExchangeItem() 

    /**
     * Method getExchangeItem
     * 
     * @param index
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML getExchangeItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _exchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) _exchangeItemList.get(index);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML getExchangeItem(int) 

    /**
     * Method getExchangeItem
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML[] getExchangeItem()
    {
        int size = _exchangeItemList.size();
        nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML[] mArray = new nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) _exchangeItemList.get(index);
        }
        return mArray;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML[] getExchangeItem() 

    /**
     * Method getExchangeItemCount
     */
    public int getExchangeItemCount()
    {
        return _exchangeItemList.size();
    } //-- int getExchangeItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeExchangeItem
     * 
     * @param vExchangeItem
     */
    public boolean removeExchangeItem(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML vExchangeItem)
    {
        boolean removed = _exchangeItemList.remove(vExchangeItem);
        return removed;
    } //-- boolean removeExchangeItem(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) 

    /**
     * Method setExchangeItem
     * 
     * @param index
     * @param vExchangeItem
     */
    public void setExchangeItem(int index, nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML vExchangeItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _exchangeItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _exchangeItemList.set(index, vExchangeItem);
    } //-- void setExchangeItem(int, nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) 

    /**
     * Method setExchangeItem
     * 
     * @param exchangeItemArray
     */
    public void setExchangeItem(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML[] exchangeItemArray)
    {
        //-- copy array
        _exchangeItemList.clear();
        for (int i = 0; i < exchangeItemArray.length; i++) {
            _exchangeItemList.add(exchangeItemArray[i]);
        }
    } //-- void setExchangeItem(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) 

    /**
     * Method unmarshalDD3dExchangeItemsXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML unmarshalDD3dExchangeItemsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML unmarshalDD3dExchangeItemsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
