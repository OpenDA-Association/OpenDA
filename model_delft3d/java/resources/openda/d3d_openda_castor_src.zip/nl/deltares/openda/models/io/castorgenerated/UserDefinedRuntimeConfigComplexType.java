/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class UserDefinedRuntimeConfigComplexType.
 * 
 * @version $Revision$ $Date$
 */
public class UserDefinedRuntimeConfigComplexType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _startDate
     */
    private nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType _startDate;

    /**
     * Field _endDate
     */
    private nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType _endDate;

    /**
     * Field _timeStep
     */
    private nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType _timeStep;

    /**
     * Field _numberEnsembles
     */
    private int _numberEnsembles = 1;

    /**
     * keeps track of state for field: _numberEnsembles
     */
    private boolean _has_numberEnsembles;


      //----------------/
     //- Constructors -/
    //----------------/

    public UserDefinedRuntimeConfigComplexType() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteNumberEnsembles
     */
    public void deleteNumberEnsembles()
    {
        this._has_numberEnsembles= false;
    } //-- void deleteNumberEnsembles() 

    /**
     * Returns the value of field 'endDate'.
     * 
     * @return the value of field 'endDate'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType getEndDate()
    {
        return this._endDate;
    } //-- nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType getEndDate() 

    /**
     * Returns the value of field 'numberEnsembles'.
     * 
     * @return the value of field 'numberEnsembles'.
     */
    public int getNumberEnsembles()
    {
        return this._numberEnsembles;
    } //-- int getNumberEnsembles() 

    /**
     * Returns the value of field 'startDate'.
     * 
     * @return the value of field 'startDate'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType getStartDate()
    {
        return this._startDate;
    } //-- nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType getStartDate() 

    /**
     * Returns the value of field 'timeStep'.
     * 
     * @return the value of field 'timeStep'.
     */
    public nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType getTimeStep()
    {
        return this._timeStep;
    } //-- nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType getTimeStep() 

    /**
     * Method hasNumberEnsembles
     */
    public boolean hasNumberEnsembles()
    {
        return this._has_numberEnsembles;
    } //-- boolean hasNumberEnsembles() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'endDate'.
     * 
     * @param endDate the value of field 'endDate'.
     */
    public void setEndDate(nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType endDate)
    {
        this._endDate = endDate;
    } //-- void setEndDate(nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType) 

    /**
     * Sets the value of field 'numberEnsembles'.
     * 
     * @param numberEnsembles the value of field 'numberEnsembles'.
     */
    public void setNumberEnsembles(int numberEnsembles)
    {
        this._numberEnsembles = numberEnsembles;
        this._has_numberEnsembles = true;
    } //-- void setNumberEnsembles(int) 

    /**
     * Sets the value of field 'startDate'.
     * 
     * @param startDate the value of field 'startDate'.
     */
    public void setStartDate(nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType startDate)
    {
        this._startDate = startDate;
    } //-- void setStartDate(nl.deltares.openda.models.io.castorgenerated.DateTimeComplexType) 

    /**
     * Sets the value of field 'timeStep'.
     * 
     * @param timeStep the value of field 'timeStep'.
     */
    public void setTimeStep(nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType timeStep)
    {
        this._timeStep = timeStep;
    } //-- void setTimeStep(nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType) 

    /**
     * Method unmarshalUserDefinedRuntimeConfigComplexType
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType unmarshalUserDefinedRuntimeConfigComplexType(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType unmarshalUserDefinedRuntimeConfigComplexType(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
