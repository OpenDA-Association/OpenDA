/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dModelConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dModelConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the model directory that contains the mdf-file
     * (relative to this config file).
     */
    private java.lang.String _directory;

    /**
     * Field _DD3dModelConfigXMLChoice
     */
    private nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice _DD3dModelConfigXMLChoice;

    /**
     * Additional argument for delwaq
     */
    private java.util.ArrayList _argList;

    /**
     * Specify the maximum number of instances to be kept in memory
     * (the other instances will be flushed to disk)
     */
    private int _maxNumInstancesInMemory = 256;

    /**
     * keeps track of state for field: _maxNumInstancesInMemory
     */
    private boolean _has_maxNumInstancesInMemory;

    /**
     * Specify the model directory that will contain the stored
     * restart files if the algorithm requests to store states.
     */
    private java.lang.String _directoryForSavedStates = "./savedStates";


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dModelConfigXML() {
        super();
        _argList = new ArrayList();
        setDirectoryForSavedStates("./savedStates");
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addArg
     * 
     * @param vArg
     */
    public void addArg(java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        _argList.add(vArg);
    } //-- void addArg(java.lang.String) 

    /**
     * Method addArg
     * 
     * @param index
     * @param vArg
     */
    public void addArg(int index, java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        _argList.add(index, vArg);
    } //-- void addArg(int, java.lang.String) 

    /**
     * Method clearArg
     */
    public void clearArg()
    {
        _argList.clear();
    } //-- void clearArg() 

    /**
     * Method deleteMaxNumInstancesInMemory
     */
    public void deleteMaxNumInstancesInMemory()
    {
        this._has_maxNumInstancesInMemory= false;
    } //-- void deleteMaxNumInstancesInMemory() 

    /**
     * Method enumerateArg
     */
    public java.util.Enumeration enumerateArg()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_argList.iterator());
    } //-- java.util.Enumeration enumerateArg() 

    /**
     * Method getArg
     * 
     * @param index
     */
    public java.lang.String getArg(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_argList.get(index);
    } //-- java.lang.String getArg(int) 

    /**
     * Method getArg
     */
    public java.lang.String[] getArg()
    {
        int size = _argList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_argList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getArg() 

    /**
     * Method getArgCount
     */
    public int getArgCount()
    {
        return _argList.size();
    } //-- int getArgCount() 

    /**
     * Returns the value of field 'DD3dModelConfigXMLChoice'.
     * 
     * @return the value of field 'DD3dModelConfigXMLChoice'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice getDD3dModelConfigXMLChoice()
    {
        return this._DD3dModelConfigXMLChoice;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice getDD3dModelConfigXMLChoice() 

    /**
     * Returns the value of field 'directory'. The field
     * 'directory' has the following description: Specify the model
     * directory that contains the mdf-file (relative to this
     * config file).
     * 
     * @return the value of field 'directory'.
     */
    public java.lang.String getDirectory()
    {
        return this._directory;
    } //-- java.lang.String getDirectory() 

    /**
     * Returns the value of field 'directoryForSavedStates'. The
     * field 'directoryForSavedStates' has the following
     * description: Specify the model directory that will contain
     * the stored restart files if the algorithm requests to store
     * states.
     * 
     * @return the value of field 'directoryForSavedStates'.
     */
    public java.lang.String getDirectoryForSavedStates()
    {
        return this._directoryForSavedStates;
    } //-- java.lang.String getDirectoryForSavedStates() 

    /**
     * Returns the value of field 'maxNumInstancesInMemory'. The
     * field 'maxNumInstancesInMemory' has the following
     * description: Specify the maximum number of instances to be
     * kept in memory (the other instances will be flushed to disk)
     * 
     * @return the value of field 'maxNumInstancesInMemory'.
     */
    public int getMaxNumInstancesInMemory()
    {
        return this._maxNumInstancesInMemory;
    } //-- int getMaxNumInstancesInMemory() 

    /**
     * Method hasMaxNumInstancesInMemory
     */
    public boolean hasMaxNumInstancesInMemory()
    {
        return this._has_maxNumInstancesInMemory;
    } //-- boolean hasMaxNumInstancesInMemory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeArg
     * 
     * @param vArg
     */
    public boolean removeArg(java.lang.String vArg)
    {
        boolean removed = _argList.remove(vArg);
        return removed;
    } //-- boolean removeArg(java.lang.String) 

    /**
     * Method setArg
     * 
     * @param index
     * @param vArg
     */
    public void setArg(int index, java.lang.String vArg)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _argList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _argList.set(index, vArg);
    } //-- void setArg(int, java.lang.String) 

    /**
     * Method setArg
     * 
     * @param argArray
     */
    public void setArg(java.lang.String[] argArray)
    {
        //-- copy array
        _argList.clear();
        for (int i = 0; i < argArray.length; i++) {
            _argList.add(argArray[i]);
        }
    } //-- void setArg(java.lang.String) 

    /**
     * Sets the value of field 'DD3dModelConfigXMLChoice'.
     * 
     * @param DD3dModelConfigXMLChoice the value of field
     * 'DD3dModelConfigXMLChoice'.
     */
    public void setDD3dModelConfigXMLChoice(nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice DD3dModelConfigXMLChoice)
    {
        this._DD3dModelConfigXMLChoice = DD3dModelConfigXMLChoice;
    } //-- void setDD3dModelConfigXMLChoice(nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice) 

    /**
     * Sets the value of field 'directory'. The field 'directory'
     * has the following description: Specify the model directory
     * that contains the mdf-file (relative to this config file).
     * 
     * @param directory the value of field 'directory'.
     */
    public void setDirectory(java.lang.String directory)
    {
        this._directory = directory;
    } //-- void setDirectory(java.lang.String) 

    /**
     * Sets the value of field 'directoryForSavedStates'. The field
     * 'directoryForSavedStates' has the following description:
     * Specify the model directory that will contain the stored
     * restart files if the algorithm requests to store states.
     * 
     * @param directoryForSavedStates the value of field
     * 'directoryForSavedStates'.
     */
    public void setDirectoryForSavedStates(java.lang.String directoryForSavedStates)
    {
        this._directoryForSavedStates = directoryForSavedStates;
    } //-- void setDirectoryForSavedStates(java.lang.String) 

    /**
     * Sets the value of field 'maxNumInstancesInMemory'. The field
     * 'maxNumInstancesInMemory' has the following description:
     * Specify the maximum number of instances to be kept in memory
     * (the other instances will be flushed to disk)
     * 
     * @param maxNumInstancesInMemory the value of field
     * 'maxNumInstancesInMemory'.
     */
    public void setMaxNumInstancesInMemory(int maxNumInstancesInMemory)
    {
        this._maxNumInstancesInMemory = maxNumInstancesInMemory;
        this._has_maxNumInstancesInMemory = true;
    } //-- void setMaxNumInstancesInMemory(int) 

    /**
     * Method unmarshalDD3dModelConfigXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML unmarshalDD3dModelConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML unmarshalDD3dModelConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
