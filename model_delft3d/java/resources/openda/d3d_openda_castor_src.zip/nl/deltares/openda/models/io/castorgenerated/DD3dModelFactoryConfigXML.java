/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dModelFactoryConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dModelFactoryConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Aliases (e.g. environment variables) used in the configuratio
     */
    private nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML _aliases;

    /**
     * Model (i.e. schematization) specification .
     */
    private nl.deltares.openda.models.io.castorgenerated.DD3dDLLConfigXML _dll;

    /**
     * Model (i.e. schematization) specification .
     */
    private nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML _model;

    /**
     * Exchange times.
     */
    private nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML _exchangeItems;


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dModelFactoryConfigXML() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelFactoryConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'aliases'. The field 'aliases'
     * has the following description: Aliases (e.g. environment
     * variables) used in the configuration
     * 
     * @return the value of field 'aliases'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML getAliases()
    {
        return this._aliases;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML getAliases() 

    /**
     * Returns the value of field 'dll'. The field 'dll' has the
     * following description: Model (i.e. schematization)
     * specification .
     * 
     * @return the value of field 'dll'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dDLLConfigXML getDll()
    {
        return this._dll;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dDLLConfigXML getDll() 

    /**
     * Returns the value of field 'exchangeItems'. The field
     * 'exchangeItems' has the following description: Exchange
     * times.
     * 
     * @return the value of field 'exchangeItems'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML getExchangeItems()
    {
        return this._exchangeItems;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML getExchangeItems() 

    /**
     * Returns the value of field 'model'. The field 'model' has
     * the following description: Model (i.e. schematization)
     * specification .
     * 
     * @return the value of field 'model'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML getModel()
    {
        return this._model;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML getModel() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'aliases'. The field 'aliases' has
     * the following description: Aliases (e.g. environment
     * variables) used in the configuration
     * 
     * @param aliases the value of field 'aliases'.
     */
    public void setAliases(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML aliases)
    {
        this._aliases = aliases;
    } //-- void setAliases(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML) 

    /**
     * Sets the value of field 'dll'. The field 'dll' has the
     * following description: Model (i.e. schematization)
     * specification .
     * 
     * @param dll the value of field 'dll'.
     */
    public void setDll(nl.deltares.openda.models.io.castorgenerated.DD3dDLLConfigXML dll)
    {
        this._dll = dll;
    } //-- void setDll(nl.deltares.openda.models.io.castorgenerated.DD3dDLLConfigXML) 

    /**
     * Sets the value of field 'exchangeItems'. The field
     * 'exchangeItems' has the following description: Exchange
     * times.
     * 
     * @param exchangeItems the value of field 'exchangeItems'.
     */
    public void setExchangeItems(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML exchangeItems)
    {
        this._exchangeItems = exchangeItems;
    } //-- void setExchangeItems(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemsXML) 

    /**
     * Sets the value of field 'model'. The field 'model' has the
     * following description: Model (i.e. schematization)
     * specification .
     * 
     * @param model the value of field 'model'.
     */
    public void setModel(nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML model)
    {
        this._model = model;
    } //-- void setModel(nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXML) 

    /**
     * Method unmarshalDD3dModelFactoryConfigXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dModelFactoryConfigXML unmarshalDD3dModelFactoryConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dModelFactoryConfigXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dModelFactoryConfigXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelFactoryConfigXML unmarshalDD3dModelFactoryConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
