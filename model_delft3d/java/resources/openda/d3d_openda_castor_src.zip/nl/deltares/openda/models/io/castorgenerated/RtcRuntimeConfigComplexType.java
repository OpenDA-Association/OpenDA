/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class RtcRuntimeConfigComplexType.
 * 
 * @version $Revision$ $Date$
 */
public class RtcRuntimeConfigComplexType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _userDefined
     */
    private nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType _userDefined;

    /**
     * Field _PIInput
     */
    private nl.deltares.openda.models.io.castorgenerated.PIInputRuntimeConfigComplexType _PIInput;


      //----------------/
     //- Constructors -/
    //----------------/

    public RtcRuntimeConfigComplexType() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.RtcRuntimeConfigComplexType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'PIInput'.
     * 
     * @return the value of field 'PIInput'.
     */
    public nl.deltares.openda.models.io.castorgenerated.PIInputRuntimeConfigComplexType getPIInput()
    {
        return this._PIInput;
    } //-- nl.deltares.openda.models.io.castorgenerated.PIInputRuntimeConfigComplexType getPIInput() 

    /**
     * Returns the value of field 'userDefined'.
     * 
     * @return the value of field 'userDefined'.
     */
    public nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType getUserDefined()
    {
        return this._userDefined;
    } //-- nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType getUserDefined() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'PIInput'.
     * 
     * @param PIInput the value of field 'PIInput'.
     */
    public void setPIInput(nl.deltares.openda.models.io.castorgenerated.PIInputRuntimeConfigComplexType PIInput)
    {
        this._PIInput = PIInput;
    } //-- void setPIInput(nl.deltares.openda.models.io.castorgenerated.PIInputRuntimeConfigComplexType) 

    /**
     * Sets the value of field 'userDefined'.
     * 
     * @param userDefined the value of field 'userDefined'.
     */
    public void setUserDefined(nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType userDefined)
    {
        this._userDefined = userDefined;
    } //-- void setUserDefined(nl.deltares.openda.models.io.castorgenerated.UserDefinedRuntimeConfigComplexType) 

    /**
     * Method unmarshalRtcRuntimeConfigComplexType
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.RtcRuntimeConfigComplexType unmarshalRtcRuntimeConfigComplexType(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.RtcRuntimeConfigComplexType) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.RtcRuntimeConfigComplexType.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.RtcRuntimeConfigComplexType unmarshalRtcRuntimeConfigComplexType(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
