/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dModelConfigXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dModelConfigXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the name of the mdf-file.
     */
    private java.lang.String _mdFile;

    /**
     * Specify the name of the input file (Flow: .mdf file, Delwaq:
     * .inp file)
     */
    private java.lang.String _inputFile;


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dModelConfigXMLChoice() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'inputFile'. The field
     * 'inputFile' has the following description: Specify the name
     * of the input file (Flow: .mdf file, Delwaq: .inp file)
     * 
     * @return the value of field 'inputFile'.
     */
    public java.lang.String getInputFile()
    {
        return this._inputFile;
    } //-- java.lang.String getInputFile() 

    /**
     * Returns the value of field 'mdFile'. The field 'mdFile' has
     * the following description: Specify the name of the mdf-file.
     * 
     * @return the value of field 'mdFile'.
     */
    public java.lang.String getMdFile()
    {
        return this._mdFile;
    } //-- java.lang.String getMdFile() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'inputFile'. The field 'inputFile'
     * has the following description: Specify the name of the input
     * file (Flow: .mdf file, Delwaq: .inp file)
     * 
     * @param inputFile the value of field 'inputFile'.
     */
    public void setInputFile(java.lang.String inputFile)
    {
        this._inputFile = inputFile;
    } //-- void setInputFile(java.lang.String) 

    /**
     * Sets the value of field 'mdFile'. The field 'mdFile' has the
     * following description: Specify the name of the mdf-file.
     * 
     * @param mdFile the value of field 'mdFile'.
     */
    public void setMdFile(java.lang.String mdFile)
    {
        this._mdFile = mdFile;
    } //-- void setMdFile(java.lang.String) 

    /**
     * Method unmarshalDD3dModelConfigXMLChoice
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice unmarshalDD3dModelConfigXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dModelConfigXMLChoice unmarshalDD3dModelConfigXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
