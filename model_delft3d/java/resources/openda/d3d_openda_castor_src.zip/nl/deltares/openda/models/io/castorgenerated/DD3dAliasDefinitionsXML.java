/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dAliasDefinitionsXML.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dAliasDefinitionsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the default prefix for the alias keys.
     */
    private java.lang.String _defaultKeyPrefix;

    /**
     * Specify the default suffix for the alias keys.
     */
    private java.lang.String _defaultKeySuffix;

    /**
     * Create list of key and value pairs of aliases.
     */
    private java.util.ArrayList _aliasList;


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dAliasDefinitionsXML() {
        super();
        _aliasList = new ArrayList();
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addAlias
     * 
     * @param vAlias
     */
    public void addAlias(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML vAlias)
        throws java.lang.IndexOutOfBoundsException
    {
        _aliasList.add(vAlias);
    } //-- void addAlias(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) 

    /**
     * Method addAlias
     * 
     * @param index
     * @param vAlias
     */
    public void addAlias(int index, nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML vAlias)
        throws java.lang.IndexOutOfBoundsException
    {
        _aliasList.add(index, vAlias);
    } //-- void addAlias(int, nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) 

    /**
     * Method clearAlias
     */
    public void clearAlias()
    {
        _aliasList.clear();
    } //-- void clearAlias() 

    /**
     * Method enumerateAlias
     */
    public java.util.Enumeration enumerateAlias()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_aliasList.iterator());
    } //-- java.util.Enumeration enumerateAlias() 

    /**
     * Method getAlias
     * 
     * @param index
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML getAlias(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _aliasList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) _aliasList.get(index);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML getAlias(int) 

    /**
     * Method getAlias
     */
    public nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML[] getAlias()
    {
        int size = _aliasList.size();
        nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML[] mArray = new nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) _aliasList.get(index);
        }
        return mArray;
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML[] getAlias() 

    /**
     * Method getAliasCount
     */
    public int getAliasCount()
    {
        return _aliasList.size();
    } //-- int getAliasCount() 

    /**
     * Returns the value of field 'defaultKeyPrefix'. The field
     * 'defaultKeyPrefix' has the following description: Specify
     * the default prefix for the alias keys.
     * 
     * @return the value of field 'defaultKeyPrefix'.
     */
    public java.lang.String getDefaultKeyPrefix()
    {
        return this._defaultKeyPrefix;
    } //-- java.lang.String getDefaultKeyPrefix() 

    /**
     * Returns the value of field 'defaultKeySuffix'. The field
     * 'defaultKeySuffix' has the following description: Specify
     * the default suffix for the alias keys.
     * 
     * @return the value of field 'defaultKeySuffix'.
     */
    public java.lang.String getDefaultKeySuffix()
    {
        return this._defaultKeySuffix;
    } //-- java.lang.String getDefaultKeySuffix() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeAlias
     * 
     * @param vAlias
     */
    public boolean removeAlias(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML vAlias)
    {
        boolean removed = _aliasList.remove(vAlias);
        return removed;
    } //-- boolean removeAlias(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) 

    /**
     * Method setAlias
     * 
     * @param index
     * @param vAlias
     */
    public void setAlias(int index, nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML vAlias)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _aliasList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _aliasList.set(index, vAlias);
    } //-- void setAlias(int, nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) 

    /**
     * Method setAlias
     * 
     * @param aliasArray
     */
    public void setAlias(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML[] aliasArray)
    {
        //-- copy array
        _aliasList.clear();
        for (int i = 0; i < aliasArray.length; i++) {
            _aliasList.add(aliasArray[i]);
        }
    } //-- void setAlias(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionXML) 

    /**
     * Sets the value of field 'defaultKeyPrefix'. The field
     * 'defaultKeyPrefix' has the following description: Specify
     * the default prefix for the alias keys.
     * 
     * @param defaultKeyPrefix the value of field 'defaultKeyPrefix'
     */
    public void setDefaultKeyPrefix(java.lang.String defaultKeyPrefix)
    {
        this._defaultKeyPrefix = defaultKeyPrefix;
    } //-- void setDefaultKeyPrefix(java.lang.String) 

    /**
     * Sets the value of field 'defaultKeySuffix'. The field
     * 'defaultKeySuffix' has the following description: Specify
     * the default suffix for the alias keys.
     * 
     * @param defaultKeySuffix the value of field 'defaultKeySuffix'
     */
    public void setDefaultKeySuffix(java.lang.String defaultKeySuffix)
    {
        this._defaultKeySuffix = defaultKeySuffix;
    } //-- void setDefaultKeySuffix(java.lang.String) 

    /**
     * Method unmarshalDD3dAliasDefinitionsXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML unmarshalDD3dAliasDefinitionsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dAliasDefinitionsXML unmarshalDD3dAliasDefinitionsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
