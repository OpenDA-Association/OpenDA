/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import nl.deltares.openda.models.io.castorgenerated.types.TimeStepUnitEnumStringType;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * The timeunit element has three attributes, unit and devider and
 * multiplier.
 *  the unit is second, minute, hour, week, month year.
 *  The divider attribute is optional (default = 1).
 * 
 * @version $Revision$ $Date$
 */
public class TimeStepComplexType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _unit
     */
    private nl.deltares.openda.models.io.castorgenerated.types.TimeStepUnitEnumStringType _unit;

    /**
     * Field _divider
     */
    private int _divider = 1;

    /**
     * keeps track of state for field: _divider
     */
    private boolean _has_divider;

    /**
     * Field _multiplier
     */
    private int _multiplier = 1;

    /**
     * keeps track of state for field: _multiplier
     */
    private boolean _has_multiplier;


      //----------------/
     //- Constructors -/
    //----------------/

    public TimeStepComplexType() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteDivider
     */
    public void deleteDivider()
    {
        this._has_divider= false;
    } //-- void deleteDivider() 

    /**
     * Method deleteMultiplier
     */
    public void deleteMultiplier()
    {
        this._has_multiplier= false;
    } //-- void deleteMultiplier() 

    /**
     * Returns the value of field 'divider'.
     * 
     * @return the value of field 'divider'.
     */
    public int getDivider()
    {
        return this._divider;
    } //-- int getDivider() 

    /**
     * Returns the value of field 'multiplier'.
     * 
     * @return the value of field 'multiplier'.
     */
    public int getMultiplier()
    {
        return this._multiplier;
    } //-- int getMultiplier() 

    /**
     * Returns the value of field 'unit'.
     * 
     * @return the value of field 'unit'.
     */
    public nl.deltares.openda.models.io.castorgenerated.types.TimeStepUnitEnumStringType getUnit()
    {
        return this._unit;
    } //-- nl.deltares.openda.models.io.castorgenerated.types.TimeStepUnitEnumStringType getUnit() 

    /**
     * Method hasDivider
     */
    public boolean hasDivider()
    {
        return this._has_divider;
    } //-- boolean hasDivider() 

    /**
     * Method hasMultiplier
     */
    public boolean hasMultiplier()
    {
        return this._has_multiplier;
    } //-- boolean hasMultiplier() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'divider'.
     * 
     * @param divider the value of field 'divider'.
     */
    public void setDivider(int divider)
    {
        this._divider = divider;
        this._has_divider = true;
    } //-- void setDivider(int) 

    /**
     * Sets the value of field 'multiplier'.
     * 
     * @param multiplier the value of field 'multiplier'.
     */
    public void setMultiplier(int multiplier)
    {
        this._multiplier = multiplier;
        this._has_multiplier = true;
    } //-- void setMultiplier(int) 

    /**
     * Sets the value of field 'unit'.
     * 
     * @param unit the value of field 'unit'.
     */
    public void setUnit(nl.deltares.openda.models.io.castorgenerated.types.TimeStepUnitEnumStringType unit)
    {
        this._unit = unit;
    } //-- void setUnit(nl.deltares.openda.models.io.castorgenerated.types.TimeStepUnitEnumStringType) 

    /**
     * Method unmarshalTimeStepComplexType
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType unmarshalTimeStepComplexType(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.TimeStepComplexType unmarshalTimeStepComplexType(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
