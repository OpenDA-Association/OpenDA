/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class TimeType.
 * 
 * @version $Revision$ $Date$
 */
public class TimeType implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public TimeType() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.TimeType()

}
