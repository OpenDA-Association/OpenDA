/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DD3dExchangeItemXML.
 * 
 * @version $Revision$ $Date$
 */
public class DD3dExchangeItemXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Exchange item identifier.
     */
    private java.lang.String _id;

    /**
     * Exchange item type, bound_HQ, etc. (TODO: make enumeration
     * of possible values) 
     */
    private java.lang.String _type;


      //----------------/
     //- Constructors -/
    //----------------/

    public DD3dExchangeItemXML() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Exchange item identifier.
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'type'. The field 'type' has the
     * following description: Exchange item type, bound_HQ, etc.
     * (TODO: make enumeration of possible values) 
     * 
     * @return the value of field 'type'.
     */
    public java.lang.String getType()
    {
        return this._type;
    } //-- java.lang.String getType() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Exchange item identifier.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'type'. The field 'type' has the
     * following description: Exchange item type, bound_HQ, etc.
     * (TODO: make enumeration of possible values) 
     * 
     * @param type the value of field 'type'.
     */
    public void setType(java.lang.String type)
    {
        this._type = type;
    } //-- void setType(java.lang.String) 

    /**
     * Method unmarshalDD3dExchangeItemXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML unmarshalDD3dExchangeItemXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DD3dExchangeItemXML unmarshalDD3dExchangeItemXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
