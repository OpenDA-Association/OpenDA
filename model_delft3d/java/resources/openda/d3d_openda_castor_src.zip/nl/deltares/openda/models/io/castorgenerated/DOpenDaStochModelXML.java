/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package nl.deltares.openda.models.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DOpenDaStochModelXML.
 * 
 * @version $Revision$ $Date$
 */
public class DOpenDaStochModelXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the information about the model wrapper class name,
     * working directory containing all model related files to be
     * clonned, and input argument to the model wrapper object.
     */
    private nl.deltares.openda.models.io.castorgenerated.DComponentXML _model;

    /**
     * Specify the information about openda:class postprocessor of
     * the simulation results, working directory containing
     * configuration file, and argument to the openda:class
     * (configuration file name). 
     */
    private nl.deltares.openda.models.io.castorgenerated.DComponentXML _postProcessor;

    /**
     * Specify the openda:class of the uncertainty module, its
     * working directory containing configuration file, and
     * argument to the openda:class (configuration file name).
     */
    private nl.deltares.openda.models.io.castorgenerated.DComponentXML _uncertaintyModule;


      //----------------/
     //- Constructors -/
    //----------------/

    public DOpenDaStochModelXML() {
        super();
    } //-- nl.deltares.openda.models.io.castorgenerated.DOpenDaStochModelXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'model'. The field 'model' has
     * the following description: Specify the information about the
     * model wrapper class name, working directory containing all
     * model related files to be clonned, and input argument to the
     * model wrapper object.
     * 
     * @return the value of field 'model'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DComponentXML getModel()
    {
        return this._model;
    } //-- nl.deltares.openda.models.io.castorgenerated.DComponentXML getModel() 

    /**
     * Returns the value of field 'postProcessor'. The field
     * 'postProcessor' has the following description: Specify the
     * information about openda:class postprocessor of the
     * simulation results, working directory containing
     * configuration file, and argument to the openda:class
     * (configuration file name). 
     * 
     * @return the value of field 'postProcessor'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DComponentXML getPostProcessor()
    {
        return this._postProcessor;
    } //-- nl.deltares.openda.models.io.castorgenerated.DComponentXML getPostProcessor() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: Specify
     * the openda:class of the uncertainty module, its working
     * directory containing configuration file, and argument to the
     * openda:class (configuration file name).
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public nl.deltares.openda.models.io.castorgenerated.DComponentXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- nl.deltares.openda.models.io.castorgenerated.DComponentXML getUncertaintyModule() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'model'. The field 'model' has the
     * following description: Specify the information about the
     * model wrapper class name, working directory containing all
     * model related files to be clonned, and input argument to the
     * model wrapper object.
     * 
     * @param model the value of field 'model'.
     */
    public void setModel(nl.deltares.openda.models.io.castorgenerated.DComponentXML model)
    {
        this._model = model;
    } //-- void setModel(nl.deltares.openda.models.io.castorgenerated.DComponentXML) 

    /**
     * Sets the value of field 'postProcessor'. The field
     * 'postProcessor' has the following description: Specify the
     * information about openda:class postprocessor of the
     * simulation results, working directory containing
     * configuration file, and argument to the openda:class
     * (configuration file name). 
     * 
     * @param postProcessor the value of field 'postProcessor'.
     */
    public void setPostProcessor(nl.deltares.openda.models.io.castorgenerated.DComponentXML postProcessor)
    {
        this._postProcessor = postProcessor;
    } //-- void setPostProcessor(nl.deltares.openda.models.io.castorgenerated.DComponentXML) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: Specify
     * the openda:class of the uncertainty module, its working
     * directory containing configuration file, and argument to the
     * openda:class (configuration file name).
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(nl.deltares.openda.models.io.castorgenerated.DComponentXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(nl.deltares.openda.models.io.castorgenerated.DComponentXML) 

    /**
     * Method unmarshalDOpenDaStochModelXML
     * 
     * @param reader
     */
    public static nl.deltares.openda.models.io.castorgenerated.DOpenDaStochModelXML unmarshalDOpenDaStochModelXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (nl.deltares.openda.models.io.castorgenerated.DOpenDaStochModelXML) Unmarshaller.unmarshal(nl.deltares.openda.models.io.castorgenerated.DOpenDaStochModelXML.class, reader);
    } //-- nl.deltares.openda.models.io.castorgenerated.DOpenDaStochModelXML unmarshalDOpenDaStochModelXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
