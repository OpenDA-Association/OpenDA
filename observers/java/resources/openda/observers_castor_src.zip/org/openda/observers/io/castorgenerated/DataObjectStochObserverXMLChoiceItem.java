/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.observers.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class DataObjectStochObserverXMLChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
public class DataObjectStochObserverXMLChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * One or more data objects. The first argument of each data
     * object is interpreted as the file to be read
     */
    private org.openda.observers.io.castorgenerated.StochObsDataObjectXML _dataObject;

    /**
     * DEPRECATED. Please use dataObject
     */
    private org.openda.observers.io.castorgenerated.StochObsDataObjectXML _ioObject;


      //----------------/
     //- Constructors -/
    //----------------/

    public DataObjectStochObserverXMLChoiceItem() {
        super();
    } //-- org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoiceItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dataObject'. The field
     * 'dataObject' has the following description: One or more data
     * objects. The first argument of each data object is
     * interpreted as the file to be read
     * 
     * @return the value of field 'dataObject'.
     */
    public org.openda.observers.io.castorgenerated.StochObsDataObjectXML getDataObject()
    {
        return this._dataObject;
    } //-- org.openda.observers.io.castorgenerated.StochObsDataObjectXML getDataObject() 

    /**
     * Returns the value of field 'ioObject'. The field 'ioObject'
     * has the following description: DEPRECATED. Please use
     * dataObject
     * 
     * @return the value of field 'ioObject'.
     */
    public org.openda.observers.io.castorgenerated.StochObsDataObjectXML getIoObject()
    {
        return this._ioObject;
    } //-- org.openda.observers.io.castorgenerated.StochObsDataObjectXML getIoObject() 

    /**
     * Sets the value of field 'dataObject'. The field 'dataObject'
     * has the following description: One or more data objects. The
     * first argument of each data object is interpreted as the
     * file to be read
     * 
     * @param dataObject the value of field 'dataObject'.
     */
    public void setDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML dataObject)
    {
        this._dataObject = dataObject;
    } //-- void setDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

    /**
     * Sets the value of field 'ioObject'. The field 'ioObject' has
     * the following description: DEPRECATED. Please use dataObject
     * 
     * @param ioObject the value of field 'ioObject'.
     */
    public void setIoObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML ioObject)
    {
        this._ioObject = ioObject;
    } //-- void setIoObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

}
