/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.observers.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DataObjectStochObserverXML.
 * 
 * @version $Revision$ $Date$
 */
public class DataObjectStochObserverXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The uncertainty module to be started (e.g.
     * org.openda.uncertainties.UncertaintyEngine).
     */
    private org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML _uncertaintyModule;

    /**
     * One or more data objects. The first argument of each data
     * object is interpreted as the file to be read
     */
    private java.util.ArrayList _dataObjectList;

    /**
     * Field _assimilationStations
     */
    private org.openda.observers.io.castorgenerated.StochObservationStationsXML _assimilationStations;

    /**
     * Field _validationStations
     */
    private org.openda.observers.io.castorgenerated.StochObservationStationsXML _validationStations;

    /**
     * Should missing values in the observations be removed, or
     * should they be presented as NaN?
     */
    private boolean _removeMissingValues = true;

    /**
     * keeps track of state for field: _removeMissingValues
     */
    private boolean _has_removeMissingValues;


      //----------------/
     //- Constructors -/
    //----------------/

    public DataObjectStochObserverXML() {
        super();
        _dataObjectList = new ArrayList();
    } //-- org.openda.observers.io.castorgenerated.DataObjectStochObserverXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addDataObject
     * 
     * @param vDataObject
     */
    public void addDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML vDataObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _dataObjectList.add(vDataObject);
    } //-- void addDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

    /**
     * Method addDataObject
     * 
     * @param index
     * @param vDataObject
     */
    public void addDataObject(int index, org.openda.observers.io.castorgenerated.StochObsDataObjectXML vDataObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _dataObjectList.add(index, vDataObject);
    } //-- void addDataObject(int, org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

    /**
     * Method clearDataObject
     */
    public void clearDataObject()
    {
        _dataObjectList.clear();
    } //-- void clearDataObject() 

    /**
     * Method deleteRemoveMissingValues
     */
    public void deleteRemoveMissingValues()
    {
        this._has_removeMissingValues= false;
    } //-- void deleteRemoveMissingValues() 

    /**
     * Method enumerateDataObject
     */
    public java.util.Enumeration enumerateDataObject()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_dataObjectList.iterator());
    } //-- java.util.Enumeration enumerateDataObject() 

    /**
     * Returns the value of field 'assimilationStations'.
     * 
     * @return the value of field 'assimilationStations'.
     */
    public org.openda.observers.io.castorgenerated.StochObservationStationsXML getAssimilationStations()
    {
        return this._assimilationStations;
    } //-- org.openda.observers.io.castorgenerated.StochObservationStationsXML getAssimilationStations() 

    /**
     * Method getDataObject
     * 
     * @param index
     */
    public org.openda.observers.io.castorgenerated.StochObsDataObjectXML getDataObject(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dataObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.observers.io.castorgenerated.StochObsDataObjectXML) _dataObjectList.get(index);
    } //-- org.openda.observers.io.castorgenerated.StochObsDataObjectXML getDataObject(int) 

    /**
     * Method getDataObject
     */
    public org.openda.observers.io.castorgenerated.StochObsDataObjectXML[] getDataObject()
    {
        int size = _dataObjectList.size();
        org.openda.observers.io.castorgenerated.StochObsDataObjectXML[] mArray = new org.openda.observers.io.castorgenerated.StochObsDataObjectXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.observers.io.castorgenerated.StochObsDataObjectXML) _dataObjectList.get(index);
        }
        return mArray;
    } //-- org.openda.observers.io.castorgenerated.StochObsDataObjectXML[] getDataObject() 

    /**
     * Method getDataObjectCount
     */
    public int getDataObjectCount()
    {
        return _dataObjectList.size();
    } //-- int getDataObjectCount() 

    /**
     * Returns the value of field 'removeMissingValues'. The field
     * 'removeMissingValues' has the following description: Should
     * missing values in the observations be removed, or should
     * they be presented as NaN?
     * 
     * @return the value of field 'removeMissingValues'.
     */
    public boolean getRemoveMissingValues()
    {
        return this._removeMissingValues;
    } //-- boolean getRemoveMissingValues() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: The
     * uncertainty module to be started (e.g.
     * org.openda.uncertainties.UncertaintyEngine).
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML getUncertaintyModule() 

    /**
     * Returns the value of field 'validationStations'.
     * 
     * @return the value of field 'validationStations'.
     */
    public org.openda.observers.io.castorgenerated.StochObservationStationsXML getValidationStations()
    {
        return this._validationStations;
    } //-- org.openda.observers.io.castorgenerated.StochObservationStationsXML getValidationStations() 

    /**
     * Method hasRemoveMissingValues
     */
    public boolean hasRemoveMissingValues()
    {
        return this._has_removeMissingValues;
    } //-- boolean hasRemoveMissingValues() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeDataObject
     * 
     * @param vDataObject
     */
    public boolean removeDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML vDataObject)
    {
        boolean removed = _dataObjectList.remove(vDataObject);
        return removed;
    } //-- boolean removeDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

    /**
     * Sets the value of field 'assimilationStations'.
     * 
     * @param assimilationStations the value of field
     * 'assimilationStations'.
     */
    public void setAssimilationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML assimilationStations)
    {
        this._assimilationStations = assimilationStations;
    } //-- void setAssimilationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML) 

    /**
     * Method setDataObject
     * 
     * @param index
     * @param vDataObject
     */
    public void setDataObject(int index, org.openda.observers.io.castorgenerated.StochObsDataObjectXML vDataObject)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dataObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _dataObjectList.set(index, vDataObject);
    } //-- void setDataObject(int, org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

    /**
     * Method setDataObject
     * 
     * @param dataObjectArray
     */
    public void setDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML[] dataObjectArray)
    {
        //-- copy array
        _dataObjectList.clear();
        for (int i = 0; i < dataObjectArray.length; i++) {
            _dataObjectList.add(dataObjectArray[i]);
        }
    } //-- void setDataObject(org.openda.observers.io.castorgenerated.StochObsDataObjectXML) 

    /**
     * Sets the value of field 'removeMissingValues'. The field
     * 'removeMissingValues' has the following description: Should
     * missing values in the observations be removed, or should
     * they be presented as NaN?
     * 
     * @param removeMissingValues the value of field
     * 'removeMissingValues'.
     */
    public void setRemoveMissingValues(boolean removeMissingValues)
    {
        this._removeMissingValues = removeMissingValues;
        this._has_removeMissingValues = true;
    } //-- void setRemoveMissingValues(boolean) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: The
     * uncertainty module to be started (e.g.
     * org.openda.uncertainties.UncertaintyEngine).
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML) 

    /**
     * Sets the value of field 'validationStations'.
     * 
     * @param validationStations the value of field
     * 'validationStations'.
     */
    public void setValidationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML validationStations)
    {
        this._validationStations = validationStations;
    } //-- void setValidationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML) 

    /**
     * Method unmarshalDataObjectStochObserverXML
     * 
     * @param reader
     */
    public static org.openda.observers.io.castorgenerated.DataObjectStochObserverXML unmarshalDataObjectStochObserverXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.observers.io.castorgenerated.DataObjectStochObserverXML) Unmarshaller.unmarshal(org.openda.observers.io.castorgenerated.DataObjectStochObserverXML.class, reader);
    } //-- org.openda.observers.io.castorgenerated.DataObjectStochObserverXML unmarshalDataObjectStochObserverXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
