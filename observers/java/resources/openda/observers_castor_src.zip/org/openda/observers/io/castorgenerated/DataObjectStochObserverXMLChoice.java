/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.observers.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DataObjectStochObserverXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class DataObjectStochObserverXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field dataObjectStochObserverXMLChoiceItem
     */
    private org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoiceItem dataObjectStochObserverXMLChoiceItem;


      //----------------/
     //- Constructors -/
    //----------------/

    public DataObjectStochObserverXMLChoice() {
        super();
    } //-- org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field
     * 'dataObjectStochObserverXMLChoiceItem'.
     * 
     * @return the value of field
     * 'dataObjectStochObserverXMLChoiceItem'.
     */
    public org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoiceItem getDataObjectStochObserverXMLChoiceItem()
    {
        return this.dataObjectStochObserverXMLChoiceItem;
    } //-- org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoiceItem getDataObjectStochObserverXMLChoiceItem() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field
     * 'dataObjectStochObserverXMLChoiceItem'.
     * 
     * @param dataObjectStochObserverXMLChoiceItem the value of
     * field 'dataObjectStochObserverXMLChoiceItem'.
     */
    public void setDataObjectStochObserverXMLChoiceItem(org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoiceItem dataObjectStochObserverXMLChoiceItem)
    {
        this.dataObjectStochObserverXMLChoiceItem = dataObjectStochObserverXMLChoiceItem;
    } //-- void setDataObjectStochObserverXMLChoiceItem(org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoiceItem) 

    /**
     * Method unmarshalDataObjectStochObserverXMLChoice
     * 
     * @param reader
     */
    public static org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoice unmarshalDataObjectStochObserverXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoice) Unmarshaller.unmarshal(org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoice.class, reader);
    } //-- org.openda.observers.io.castorgenerated.DataObjectStochObserverXMLChoice unmarshalDataObjectStochObserverXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
