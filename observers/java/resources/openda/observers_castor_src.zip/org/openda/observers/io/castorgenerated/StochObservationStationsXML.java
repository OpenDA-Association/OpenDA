/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.observers.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class StochObservationStationsXML.
 * 
 * @version $Revision$ $Date$
 */
public class StochObservationStationsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _observationIdList
     */
    private java.util.ArrayList _observationIdList;


      //----------------/
     //- Constructors -/
    //----------------/

    public StochObservationStationsXML() {
        super();
        _observationIdList = new ArrayList();
    } //-- org.openda.observers.io.castorgenerated.StochObservationStationsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addObservationId
     * 
     * @param vObservationId
     */
    public void addObservationId(java.lang.String vObservationId)
        throws java.lang.IndexOutOfBoundsException
    {
        _observationIdList.add(vObservationId);
    } //-- void addObservationId(java.lang.String) 

    /**
     * Method addObservationId
     * 
     * @param index
     * @param vObservationId
     */
    public void addObservationId(int index, java.lang.String vObservationId)
        throws java.lang.IndexOutOfBoundsException
    {
        _observationIdList.add(index, vObservationId);
    } //-- void addObservationId(int, java.lang.String) 

    /**
     * Method clearObservationId
     */
    public void clearObservationId()
    {
        _observationIdList.clear();
    } //-- void clearObservationId() 

    /**
     * Method enumerateObservationId
     */
    public java.util.Enumeration enumerateObservationId()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_observationIdList.iterator());
    } //-- java.util.Enumeration enumerateObservationId() 

    /**
     * Method getObservationId
     * 
     * @param index
     */
    public java.lang.String getObservationId(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _observationIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_observationIdList.get(index);
    } //-- java.lang.String getObservationId(int) 

    /**
     * Method getObservationId
     */
    public java.lang.String[] getObservationId()
    {
        int size = _observationIdList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_observationIdList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getObservationId() 

    /**
     * Method getObservationIdCount
     */
    public int getObservationIdCount()
    {
        return _observationIdList.size();
    } //-- int getObservationIdCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeObservationId
     * 
     * @param vObservationId
     */
    public boolean removeObservationId(java.lang.String vObservationId)
    {
        boolean removed = _observationIdList.remove(vObservationId);
        return removed;
    } //-- boolean removeObservationId(java.lang.String) 

    /**
     * Method setObservationId
     * 
     * @param index
     * @param vObservationId
     */
    public void setObservationId(int index, java.lang.String vObservationId)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _observationIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _observationIdList.set(index, vObservationId);
    } //-- void setObservationId(int, java.lang.String) 

    /**
     * Method setObservationId
     * 
     * @param observationIdArray
     */
    public void setObservationId(java.lang.String[] observationIdArray)
    {
        //-- copy array
        _observationIdList.clear();
        for (int i = 0; i < observationIdArray.length; i++) {
            _observationIdList.add(observationIdArray[i]);
        }
    } //-- void setObservationId(java.lang.String) 

    /**
     * Method unmarshalStochObservationStationsXML
     * 
     * @param reader
     */
    public static org.openda.observers.io.castorgenerated.StochObservationStationsXML unmarshalStochObservationStationsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.observers.io.castorgenerated.StochObservationStationsXML) Unmarshaller.unmarshal(org.openda.observers.io.castorgenerated.StochObservationStationsXML.class, reader);
    } //-- org.openda.observers.io.castorgenerated.StochObservationStationsXML unmarshalStochObservationStationsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
