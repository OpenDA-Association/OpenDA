/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class LimitedExchangeItemChoice.
 * 
 * @version $Revision$ $Date$
 */
public class LimitedExchangeItemChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Optional. If the value of a model exchange item is below the
     * lower limit, then the value is changed to the lower limit.
     */
    private double _lowerLimit;

    /**
     * keeps track of state for field: _lowerLimit
     */
    private boolean _has_lowerLimit;

    /**
     * Optional. If the value of a model exchange item is below the
     * value of the value of this lower limit exchange item, then
     * the value is changed to the lower limit.
     *  
     */
    private java.lang.String _lowerLimitExchangeItemId;


      //----------------/
     //- Constructors -/
    //----------------/

    public LimitedExchangeItemChoice() {
        super();
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteLowerLimit
     */
    public void deleteLowerLimit()
    {
        this._has_lowerLimit= false;
    } //-- void deleteLowerLimit() 

    /**
     * Returns the value of field 'lowerLimit'. The field
     * 'lowerLimit' has the following description: Optional. If the
     * value of a model exchange item is below the lower limit,
     * then the value is changed to the lower limit.
     * 
     * @return the value of field 'lowerLimit'.
     */
    public double getLowerLimit()
    {
        return this._lowerLimit;
    } //-- double getLowerLimit() 

    /**
     * Returns the value of field 'lowerLimitExchangeItemId'. The
     * field 'lowerLimitExchangeItemId' has the following
     * description: Optional. If the value of a model exchange item
     * is below the value of the value of this lower limit exchange
     * item, then the value is changed to the lower limit.
     *  
     * 
     * @return the value of field 'lowerLimitExchangeItemId'.
     */
    public java.lang.String getLowerLimitExchangeItemId()
    {
        return this._lowerLimitExchangeItemId;
    } //-- java.lang.String getLowerLimitExchangeItemId() 

    /**
     * Method hasLowerLimit
     */
    public boolean hasLowerLimit()
    {
        return this._has_lowerLimit;
    } //-- boolean hasLowerLimit() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'lowerLimit'. The field 'lowerLimit'
     * has the following description: Optional. If the value of a
     * model exchange item is below the lower limit, then the value
     * is changed to the lower limit.
     * 
     * @param lowerLimit the value of field 'lowerLimit'.
     */
    public void setLowerLimit(double lowerLimit)
    {
        this._lowerLimit = lowerLimit;
        this._has_lowerLimit = true;
    } //-- void setLowerLimit(double) 

    /**
     * Sets the value of field 'lowerLimitExchangeItemId'. The
     * field 'lowerLimitExchangeItemId' has the following
     * description: Optional. If the value of a model exchange item
     * is below the value of the value of this lower limit exchange
     * item, then the value is changed to the lower limit.
     *  
     * 
     * @param lowerLimitExchangeItemId the value of field
     * 'lowerLimitExchangeItemId'.
     */
    public void setLowerLimitExchangeItemId(java.lang.String lowerLimitExchangeItemId)
    {
        this._lowerLimitExchangeItemId = lowerLimitExchangeItemId;
    } //-- void setLowerLimitExchangeItemId(java.lang.String) 

    /**
     * Method unmarshalLimitedExchangeItemChoice
     * 
     * @param reader
     */
    public static org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice unmarshalLimitedExchangeItemChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice) Unmarshaller.unmarshal(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice.class, reader);
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice unmarshalLimitedExchangeItemChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
