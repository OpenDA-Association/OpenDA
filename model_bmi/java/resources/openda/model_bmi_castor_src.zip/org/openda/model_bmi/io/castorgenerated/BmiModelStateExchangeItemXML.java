/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BmiModelStateExchangeItemXML.
 * 
 * @version $Revision$ $Date$
 */
public class BmiModelStateExchangeItemXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _items
     */
    private java.util.ArrayList _items;


      //----------------/
     //- Constructors -/
    //----------------/

    public BmiModelStateExchangeItemXML() {
        super();
        _items = new ArrayList();
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBmiModelStateExchangeItemXMLItem
     * 
     * @param vBmiModelStateExchangeItemXMLItem
     */
    public void addBmiModelStateExchangeItemXMLItem(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem vBmiModelStateExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(vBmiModelStateExchangeItemXMLItem);
    } //-- void addBmiModelStateExchangeItemXMLItem(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) 

    /**
     * Method addBmiModelStateExchangeItemXMLItem
     * 
     * @param index
     * @param vBmiModelStateExchangeItemXMLItem
     */
    public void addBmiModelStateExchangeItemXMLItem(int index, org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem vBmiModelStateExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _items.add(index, vBmiModelStateExchangeItemXMLItem);
    } //-- void addBmiModelStateExchangeItemXMLItem(int, org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) 

    /**
     * Method clearBmiModelStateExchangeItemXMLItem
     */
    public void clearBmiModelStateExchangeItemXMLItem()
    {
        _items.clear();
    } //-- void clearBmiModelStateExchangeItemXMLItem() 

    /**
     * Method enumerateBmiModelStateExchangeItemXMLItem
     */
    public java.util.Enumeration enumerateBmiModelStateExchangeItemXMLItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_items.iterator());
    } //-- java.util.Enumeration enumerateBmiModelStateExchangeItemXMLItem() 

    /**
     * Method getBmiModelStateExchangeItemXMLItem
     * 
     * @param index
     */
    public org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem getBmiModelStateExchangeItemXMLItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) _items.get(index);
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem getBmiModelStateExchangeItemXMLItem(int) 

    /**
     * Method getBmiModelStateExchangeItemXMLItem
     */
    public org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem[] getBmiModelStateExchangeItemXMLItem()
    {
        int size = _items.size();
        org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem[] mArray = new org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) _items.get(index);
        }
        return mArray;
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem[] getBmiModelStateExchangeItemXMLItem() 

    /**
     * Method getBmiModelStateExchangeItemXMLItemCount
     */
    public int getBmiModelStateExchangeItemXMLItemCount()
    {
        return _items.size();
    } //-- int getBmiModelStateExchangeItemXMLItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBmiModelStateExchangeItemXMLItem
     * 
     * @param vBmiModelStateExchangeItemXMLItem
     */
    public boolean removeBmiModelStateExchangeItemXMLItem(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem vBmiModelStateExchangeItemXMLItem)
    {
        boolean removed = _items.remove(vBmiModelStateExchangeItemXMLItem);
        return removed;
    } //-- boolean removeBmiModelStateExchangeItemXMLItem(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) 

    /**
     * Method setBmiModelStateExchangeItemXMLItem
     * 
     * @param index
     * @param vBmiModelStateExchangeItemXMLItem
     */
    public void setBmiModelStateExchangeItemXMLItem(int index, org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem vBmiModelStateExchangeItemXMLItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _items.size())) {
            throw new IndexOutOfBoundsException();
        }
        _items.set(index, vBmiModelStateExchangeItemXMLItem);
    } //-- void setBmiModelStateExchangeItemXMLItem(int, org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) 

    /**
     * Method setBmiModelStateExchangeItemXMLItem
     * 
     * @param bmiModelStateExchangeItemXMLItemArray
     */
    public void setBmiModelStateExchangeItemXMLItem(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem[] bmiModelStateExchangeItemXMLItemArray)
    {
        //-- copy array
        _items.clear();
        for (int i = 0; i < bmiModelStateExchangeItemXMLItemArray.length; i++) {
            _items.add(bmiModelStateExchangeItemXMLItemArray[i]);
        }
    } //-- void setBmiModelStateExchangeItemXMLItem(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem) 

    /**
     * Method unmarshalBmiModelStateExchangeItemXML
     * 
     * @param reader
     */
    public static org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML unmarshalBmiModelStateExchangeItemXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML) Unmarshaller.unmarshal(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML.class, reader);
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML unmarshalBmiModelStateExchangeItemXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
