/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class LimitedExchangeItem.
 * 
 * @version $Revision$ $Date$
 */
public class LimitedExchangeItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Name of a State ExchangeItem.
     */
    private java.lang.String _exchangeItemId;

    /**
     * Optional. If the value of a model exchange item is below the
     * lower limit, then the value is changed to the lower limit.
     */
    private double _lowerLimit;

    /**
     * keeps track of state for field: _lowerLimit
     */
    private boolean _has_lowerLimit;

    /**
     * Optional. If the value of a model exchange item is above the
     * upper limit, then the value is changed to the upper limit. 
     */
    private double _upperLimit;

    /**
     * keeps track of state for field: _upperLimit
     */
    private boolean _has_upperLimit;


      //----------------/
     //- Constructors -/
    //----------------/

    public LimitedExchangeItem() {
        super();
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteLowerLimit
     */
    public void deleteLowerLimit()
    {
        this._has_lowerLimit= false;
    } //-- void deleteLowerLimit() 

    /**
     * Method deleteUpperLimit
     */
    public void deleteUpperLimit()
    {
        this._has_upperLimit= false;
    } //-- void deleteUpperLimit() 

    /**
     * Returns the value of field 'exchangeItemId'. The field
     * 'exchangeItemId' has the following description: Name of a
     * State ExchangeItem.
     * 
     * @return the value of field 'exchangeItemId'.
     */
    public java.lang.String getExchangeItemId()
    {
        return this._exchangeItemId;
    } //-- java.lang.String getExchangeItemId() 

    /**
     * Returns the value of field 'lowerLimit'. The field
     * 'lowerLimit' has the following description: Optional. If the
     * value of a model exchange item is below the lower limit,
     * then the value is changed to the lower limit.
     * 
     * @return the value of field 'lowerLimit'.
     */
    public double getLowerLimit()
    {
        return this._lowerLimit;
    } //-- double getLowerLimit() 

    /**
     * Returns the value of field 'upperLimit'. The field
     * 'upperLimit' has the following description: Optional. If the
     * value of a model exchange item is above the upper limit,
     * then the value is changed to the upper limit. 
     * 
     * @return the value of field 'upperLimit'.
     */
    public double getUpperLimit()
    {
        return this._upperLimit;
    } //-- double getUpperLimit() 

    /**
     * Method hasLowerLimit
     */
    public boolean hasLowerLimit()
    {
        return this._has_lowerLimit;
    } //-- boolean hasLowerLimit() 

    /**
     * Method hasUpperLimit
     */
    public boolean hasUpperLimit()
    {
        return this._has_upperLimit;
    } //-- boolean hasUpperLimit() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'exchangeItemId'. The field
     * 'exchangeItemId' has the following description: Name of a
     * State ExchangeItem.
     * 
     * @param exchangeItemId the value of field 'exchangeItemId'.
     */
    public void setExchangeItemId(java.lang.String exchangeItemId)
    {
        this._exchangeItemId = exchangeItemId;
    } //-- void setExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'lowerLimit'. The field 'lowerLimit'
     * has the following description: Optional. If the value of a
     * model exchange item is below the lower limit, then the value
     * is changed to the lower limit.
     * 
     * @param lowerLimit the value of field 'lowerLimit'.
     */
    public void setLowerLimit(double lowerLimit)
    {
        this._lowerLimit = lowerLimit;
        this._has_lowerLimit = true;
    } //-- void setLowerLimit(double) 

    /**
     * Sets the value of field 'upperLimit'. The field 'upperLimit'
     * has the following description: Optional. If the value of a
     * model exchange item is above the upper limit, then the value
     * is changed to the upper limit. 
     * 
     * @param upperLimit the value of field 'upperLimit'.
     */
    public void setUpperLimit(double upperLimit)
    {
        this._upperLimit = upperLimit;
        this._has_upperLimit = true;
    } //-- void setUpperLimit(double) 

    /**
     * Method unmarshalLimitedExchangeItem
     * 
     * @param reader
     */
    public static org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem unmarshalLimitedExchangeItem(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem) Unmarshaller.unmarshal(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem.class, reader);
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem unmarshalLimitedExchangeItem(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
