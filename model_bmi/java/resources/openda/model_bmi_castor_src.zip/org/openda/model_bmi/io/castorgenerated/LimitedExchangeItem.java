/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class LimitedExchangeItem.
 * 
 * @version $Revision$ $Date$
 */
public class LimitedExchangeItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Name of a State ExchangeItem.
     */
    private java.lang.String _exchangeItemId;

    /**
     * Field _limitedExchangeItemChoice
     */
    private org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice _limitedExchangeItemChoice;

    /**
     * Field _limitedExchangeItemChoice2
     */
    private org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice2 _limitedExchangeItemChoice2;


      //----------------/
     //- Constructors -/
    //----------------/

    public LimitedExchangeItem() {
        super();
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'exchangeItemId'. The field
     * 'exchangeItemId' has the following description: Name of a
     * State ExchangeItem.
     * 
     * @return the value of field 'exchangeItemId'.
     */
    public java.lang.String getExchangeItemId()
    {
        return this._exchangeItemId;
    } //-- java.lang.String getExchangeItemId() 

    /**
     * Returns the value of field 'limitedExchangeItemChoice'.
     * 
     * @return the value of field 'limitedExchangeItemChoice'.
     */
    public org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice getLimitedExchangeItemChoice()
    {
        return this._limitedExchangeItemChoice;
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice getLimitedExchangeItemChoice() 

    /**
     * Returns the value of field 'limitedExchangeItemChoice2'.
     * 
     * @return the value of field 'limitedExchangeItemChoice2'.
     */
    public org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice2 getLimitedExchangeItemChoice2()
    {
        return this._limitedExchangeItemChoice2;
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice2 getLimitedExchangeItemChoice2() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'exchangeItemId'. The field
     * 'exchangeItemId' has the following description: Name of a
     * State ExchangeItem.
     * 
     * @param exchangeItemId the value of field 'exchangeItemId'.
     */
    public void setExchangeItemId(java.lang.String exchangeItemId)
    {
        this._exchangeItemId = exchangeItemId;
    } //-- void setExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'limitedExchangeItemChoice'.
     * 
     * @param limitedExchangeItemChoice the value of field
     * 'limitedExchangeItemChoice'.
     */
    public void setLimitedExchangeItemChoice(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice limitedExchangeItemChoice)
    {
        this._limitedExchangeItemChoice = limitedExchangeItemChoice;
    } //-- void setLimitedExchangeItemChoice(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice) 

    /**
     * Sets the value of field 'limitedExchangeItemChoice2'.
     * 
     * @param limitedExchangeItemChoice2 the value of field
     * 'limitedExchangeItemChoice2'.
     */
    public void setLimitedExchangeItemChoice2(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice2 limitedExchangeItemChoice2)
    {
        this._limitedExchangeItemChoice2 = limitedExchangeItemChoice2;
    } //-- void setLimitedExchangeItemChoice2(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItemChoice2) 

    /**
     * Method unmarshalLimitedExchangeItem
     * 
     * @param reader
     */
    public static org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem unmarshalLimitedExchangeItem(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem) Unmarshaller.unmarshal(org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem.class, reader);
    } //-- org.openda.model_bmi.io.castorgenerated.LimitedExchangeItem unmarshalLimitedExchangeItem(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
