/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class BmiModelStateExchangeItemXMLItem.
 * 
 * @version $Revision$ $Date$
 */
public class BmiModelStateExchangeItemXMLItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _exchangeItemId
     */
    private java.lang.String _exchangeItemId;


      //----------------/
     //- Constructors -/
    //----------------/

    public BmiModelStateExchangeItemXMLItem() {
        super();
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXMLItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'exchangeItemId'.
     * 
     * @return the value of field 'exchangeItemId'.
     */
    public java.lang.String getExchangeItemId()
    {
        return this._exchangeItemId;
    } //-- java.lang.String getExchangeItemId() 

    /**
     * Sets the value of field 'exchangeItemId'.
     * 
     * @param exchangeItemId the value of field 'exchangeItemId'.
     */
    public void setExchangeItemId(java.lang.String exchangeItemId)
    {
        this._exchangeItemId = exchangeItemId;
    } //-- void setExchangeItemId(java.lang.String) 

}
