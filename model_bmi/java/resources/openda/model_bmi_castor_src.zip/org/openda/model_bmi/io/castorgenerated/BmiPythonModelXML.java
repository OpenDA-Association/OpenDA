/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BmiPythonModelXML.
 * 
 * @version $Revision$ $Date$
 */
public class BmiPythonModelXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Path that contains the Python code of the model (relative to
     * this configuration file).
     */
    private java.lang.String _pythonPath;

    /**
     * The (fully qualified) name of the Python module that
     * contains the class specified in className, e.g. wflow_bmi.
     */
    private java.lang.String _moduleName;

    /**
     * The name of the Python class that implements the BMI
     * interface, e.g. wflowbmi.
     */
    private java.lang.String _className;


      //----------------/
     //- Constructors -/
    //----------------/

    public BmiPythonModelXML() {
        super();
    } //-- org.openda.model_bmi.io.castorgenerated.BmiPythonModelXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: The name of the
     * Python class that implements the BMI interface, e.g.
     * wflowbmi.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'moduleName'. The field
     * 'moduleName' has the following description: The (fully
     * qualified) name of the Python module that contains the class
     * specified in className, e.g. wflow_bmi.
     * 
     * @return the value of field 'moduleName'.
     */
    public java.lang.String getModuleName()
    {
        return this._moduleName;
    } //-- java.lang.String getModuleName() 

    /**
     * Returns the value of field 'pythonPath'. The field
     * 'pythonPath' has the following description: Path that
     * contains the Python code of the model (relative to this
     * configuration file).
     * 
     * @return the value of field 'pythonPath'.
     */
    public java.lang.String getPythonPath()
    {
        return this._pythonPath;
    } //-- java.lang.String getPythonPath() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: The name of the Python class
     * that implements the BMI interface, e.g. wflowbmi.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'moduleName'. The field 'moduleName'
     * has the following description: The (fully qualified) name of
     * the Python module that contains the class specified in
     * className, e.g. wflow_bmi.
     * 
     * @param moduleName the value of field 'moduleName'.
     */
    public void setModuleName(java.lang.String moduleName)
    {
        this._moduleName = moduleName;
    } //-- void setModuleName(java.lang.String) 

    /**
     * Sets the value of field 'pythonPath'. The field 'pythonPath'
     * has the following description: Path that contains the Python
     * code of the model (relative to this configuration file).
     * 
     * @param pythonPath the value of field 'pythonPath'.
     */
    public void setPythonPath(java.lang.String pythonPath)
    {
        this._pythonPath = pythonPath;
    } //-- void setPythonPath(java.lang.String) 

    /**
     * Method unmarshalBmiPythonModelXML
     * 
     * @param reader
     */
    public static org.openda.model_bmi.io.castorgenerated.BmiPythonModelXML unmarshalBmiPythonModelXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_bmi.io.castorgenerated.BmiPythonModelXML) Unmarshaller.unmarshal(org.openda.model_bmi.io.castorgenerated.BmiPythonModelXML.class, reader);
    } //-- org.openda.model_bmi.io.castorgenerated.BmiPythonModelXML unmarshalBmiPythonModelXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
