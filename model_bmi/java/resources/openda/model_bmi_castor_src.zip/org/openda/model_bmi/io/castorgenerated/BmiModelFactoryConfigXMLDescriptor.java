/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import org.exolab.castor.mapping.AccessMode;
import org.exolab.castor.xml.TypeValidator;
import org.exolab.castor.xml.XMLFieldDescriptor;
import org.exolab.castor.xml.validators.*;

/**
 * Class BmiModelFactoryConfigXMLDescriptor.
 * 
 * @version $Revision$ $Date$
 */
public class BmiModelFactoryConfigXMLDescriptor extends org.exolab.castor.xml.util.XMLClassDescriptorImpl {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field nsPrefix
     */
    private java.lang.String nsPrefix;

    /**
     * Field nsURI
     */
    private java.lang.String nsURI;

    /**
     * Field xmlName
     */
    private java.lang.String xmlName;

    /**
     * Field identity
     */
    private org.exolab.castor.xml.XMLFieldDescriptor identity;


      //----------------/
     //- Constructors -/
    //----------------/

    public BmiModelFactoryConfigXMLDescriptor() {
        super();
        nsURI = "http://www.openda.org";
        xmlName = "BmiModelFactoryConfigXML";
        
        //-- set grouping compositor
        setCompositorAsSequence();
        org.exolab.castor.xml.util.XMLFieldDescriptorImpl  desc           = null;
        org.exolab.castor.xml.XMLFieldHandler              handler        = null;
        org.exolab.castor.xml.FieldValidator               fieldValidator = null;
        //-- initialize attribute descriptors
        
        //-- initialize element descriptors
        
        //-- _bmiModelFactoryConfigXMLChoice
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice.class, "_bmiModelFactoryConfigXMLChoice", "-error-if-this-is-used-", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getBmiModelFactoryConfigXMLChoice();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.setBmiModelFactoryConfigXMLChoice( (org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice();
            }
        } );
        desc.setHandler(handler);
        desc.setContainer(true);
        desc.setClassDescriptor(new org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoiceDescriptor());
        desc.setRequired(true);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _bmiModelFactoryConfigXMLChoice
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _modelTemplateDirectory
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_modelTemplateDirectory", "modelTemplateDirectory", org.exolab.castor.xml.NodeType.Element);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getModelTemplateDirectory();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.setModelTemplateDirectory( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setRequired(true);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _modelTemplateDirectory
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _modelConfigFile
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_modelConfigFile", "modelConfigFile", org.exolab.castor.xml.NodeType.Element);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getModelConfigFile();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.setModelConfigFile( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setRequired(true);
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _modelConfigFile
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _inputStateDirectory
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_inputStateDirectory", "inputStateDirectory", org.exolab.castor.xml.NodeType.Element);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getInputStateDirectory();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.setInputStateDirectory( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _inputStateDirectory
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _outputStateDirectory
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_outputStateDirectory", "outputStateDirectory", org.exolab.castor.xml.NodeType.Element);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getOutputStateDirectory();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.setOutputStateDirectory( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _outputStateDirectory
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _hosts
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.String.class, "_hosts", "hosts", org.exolab.castor.xml.NodeType.Element);
        desc.setImmutable(true);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getHosts();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.setHosts( (java.lang.String) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _hosts
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
            StringValidator typeValidator = new StringValidator();
            typeValidator.setWhiteSpace("preserve");
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
        //-- _bmiModelForcingsConfigList
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML.class, "_bmiModelForcingsConfigList", "bmiModelForcingsConfig", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getBmiModelForcingsConfig();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.addBmiModelForcingsConfig( (org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(true);
        addFieldDescriptor(desc);
        
        //-- validation code for: _bmiModelForcingsConfigList
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(0);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _staticLimitDataObjectsList
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML.class, "_staticLimitDataObjectsList", "staticLimitDataObjects", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getStaticLimitDataObjects();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.addStaticLimitDataObjects( (org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(true);
        addFieldDescriptor(desc);
        
        //-- validation code for: _staticLimitDataObjectsList
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(0);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _bmiModelStateExchangeItemsList
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML.class, "_bmiModelStateExchangeItemsList", "bmiModelStateExchangeItems", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                return target.getBmiModelStateExchangeItems();
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    target.addBmiModelStateExchangeItems( (org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML) value);
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return new org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML();
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setRequired(true);
        desc.setMultivalued(true);
        addFieldDescriptor(desc);
        
        //-- validation code for: _bmiModelStateExchangeItemsList
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        fieldValidator.setMinOccurs(1);
        { //-- local scope
        }
        desc.setValidator(fieldValidator);
        //-- _missingValue
        desc = new org.exolab.castor.xml.util.XMLFieldDescriptorImpl(java.lang.Double.TYPE, "_missingValue", "missingValue", org.exolab.castor.xml.NodeType.Element);
        handler = (new org.exolab.castor.xml.XMLFieldHandler() {
            public java.lang.Object getValue( java.lang.Object object ) 
                throws IllegalStateException
            {
                BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                if(!target.hasMissingValue())
                    return null;
                return new Double(target.getMissingValue());
            }
            public void setValue( java.lang.Object object, java.lang.Object value) 
                throws IllegalStateException, IllegalArgumentException
            {
                try {
                    BmiModelFactoryConfigXML target = (BmiModelFactoryConfigXML) object;
                    // if null, use delete method for optional primitives 
                    if (value == null) {
                        target.deleteMissingValue();
                        return;
                    }
                    target.setMissingValue( ((Double)value).doubleValue());
                }
                catch (java.lang.Exception ex) {
                    throw new IllegalStateException(ex.toString());
                }
            }
            public java.lang.Object newInstance( java.lang.Object parent ) {
                return null;
            }
        } );
        desc.setHandler(handler);
        desc.setNameSpaceURI("http://www.openda.org");
        desc.setMultivalued(false);
        addFieldDescriptor(desc);
        
        //-- validation code for: _missingValue
        fieldValidator = new org.exolab.castor.xml.FieldValidator();
        { //-- local scope
            DoubleValidator typeValidator = new DoubleValidator();
            fieldValidator.setValidator(typeValidator);
        }
        desc.setValidator(fieldValidator);
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLDescriptor()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method getAccessMode
     */
    public org.exolab.castor.mapping.AccessMode getAccessMode()
    {
        return null;
    } //-- org.exolab.castor.mapping.AccessMode getAccessMode() 

    /**
     * Method getExtends
     */
    public org.exolab.castor.mapping.ClassDescriptor getExtends()
    {
        return null;
    } //-- org.exolab.castor.mapping.ClassDescriptor getExtends() 

    /**
     * Method getIdentity
     */
    public org.exolab.castor.mapping.FieldDescriptor getIdentity()
    {
        return identity;
    } //-- org.exolab.castor.mapping.FieldDescriptor getIdentity() 

    /**
     * Method getJavaClass
     */
    public java.lang.Class getJavaClass()
    {
        return org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXML.class;
    } //-- java.lang.Class getJavaClass() 

    /**
     * Method getNameSpacePrefix
     */
    public java.lang.String getNameSpacePrefix()
    {
        return nsPrefix;
    } //-- java.lang.String getNameSpacePrefix() 

    /**
     * Method getNameSpaceURI
     */
    public java.lang.String getNameSpaceURI()
    {
        return nsURI;
    } //-- java.lang.String getNameSpaceURI() 

    /**
     * Method getValidator
     */
    public org.exolab.castor.xml.TypeValidator getValidator()
    {
        return this;
    } //-- org.exolab.castor.xml.TypeValidator getValidator() 

    /**
     * Method getXMLName
     */
    public java.lang.String getXMLName()
    {
        return xmlName;
    } //-- java.lang.String getXMLName() 

}
