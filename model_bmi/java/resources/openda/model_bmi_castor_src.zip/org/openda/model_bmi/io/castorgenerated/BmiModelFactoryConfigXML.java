/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_bmi.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BmiModelFactoryConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class BmiModelFactoryConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _bmiModelFactoryConfigXMLChoice
     */
    private org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice _bmiModelFactoryConfigXMLChoice;

    /**
     * Path and name of the model template directory (relative to
     * this configuration file). This directory will be cloned to
     * create instance directories called work0, work1, work2, etc.
     * The work directories will be created next to the model
     * template directory, i.e. with the same parent directory.
     * Before each run, any work directories from previous runs
     * will be removed.
     */
    private java.lang.String _modelTemplateDirectory;

    /**
     * The path and name of the model configuration file (relative
     * to the model template directory).
     */
    private java.lang.String _modelConfigFile;

    /**
     * The directory in the model instance that contains the input
     * state
     */
    private java.lang.String _inputStateDirectory = "input_state";

    /**
     * The directory in the model instance that contains the input
     * state
     */
    private java.lang.String _outputStateDirectory = "output_state";

    /**
     * DEPRECATED: This element will probably be removed in future.
     */
    private java.lang.String _hosts;

    /**
     * Field _bmiModelForcingsConfigList
     */
    private java.util.ArrayList _bmiModelForcingsConfigList;

    /**
     * Field _bmiModelStateExchangeItems
     */
    private org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML _bmiModelStateExchangeItems;


      //----------------/
     //- Constructors -/
    //----------------/

    public BmiModelFactoryConfigXML() {
        super();
        setInputStateDirectory("input_state");
        setOutputStateDirectory("output_state");
        _bmiModelForcingsConfigList = new ArrayList();
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addBmiModelForcingsConfig
     * 
     * @param vBmiModelForcingsConfig
     */
    public void addBmiModelForcingsConfig(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML vBmiModelForcingsConfig)
        throws java.lang.IndexOutOfBoundsException
    {
        _bmiModelForcingsConfigList.add(vBmiModelForcingsConfig);
    } //-- void addBmiModelForcingsConfig(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) 

    /**
     * Method addBmiModelForcingsConfig
     * 
     * @param index
     * @param vBmiModelForcingsConfig
     */
    public void addBmiModelForcingsConfig(int index, org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML vBmiModelForcingsConfig)
        throws java.lang.IndexOutOfBoundsException
    {
        _bmiModelForcingsConfigList.add(index, vBmiModelForcingsConfig);
    } //-- void addBmiModelForcingsConfig(int, org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) 

    /**
     * Method clearBmiModelForcingsConfig
     */
    public void clearBmiModelForcingsConfig()
    {
        _bmiModelForcingsConfigList.clear();
    } //-- void clearBmiModelForcingsConfig() 

    /**
     * Method enumerateBmiModelForcingsConfig
     */
    public java.util.Enumeration enumerateBmiModelForcingsConfig()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_bmiModelForcingsConfigList.iterator());
    } //-- java.util.Enumeration enumerateBmiModelForcingsConfig() 

    /**
     * Returns the value of field 'bmiModelFactoryConfigXMLChoice'.
     * 
     * @return the value of field 'bmiModelFactoryConfigXMLChoice'.
     */
    public org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice getBmiModelFactoryConfigXMLChoice()
    {
        return this._bmiModelFactoryConfigXMLChoice;
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice getBmiModelFactoryConfigXMLChoice() 

    /**
     * Method getBmiModelForcingsConfig
     * 
     * @param index
     */
    public org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML getBmiModelForcingsConfig(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _bmiModelForcingsConfigList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) _bmiModelForcingsConfigList.get(index);
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML getBmiModelForcingsConfig(int) 

    /**
     * Method getBmiModelForcingsConfig
     */
    public org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML[] getBmiModelForcingsConfig()
    {
        int size = _bmiModelForcingsConfigList.size();
        org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML[] mArray = new org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) _bmiModelForcingsConfigList.get(index);
        }
        return mArray;
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML[] getBmiModelForcingsConfig() 

    /**
     * Method getBmiModelForcingsConfigCount
     */
    public int getBmiModelForcingsConfigCount()
    {
        return _bmiModelForcingsConfigList.size();
    } //-- int getBmiModelForcingsConfigCount() 

    /**
     * Returns the value of field 'bmiModelStateExchangeItems'.
     * 
     * @return the value of field 'bmiModelStateExchangeItems'.
     */
    public org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML getBmiModelStateExchangeItems()
    {
        return this._bmiModelStateExchangeItems;
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML getBmiModelStateExchangeItems() 

    /**
     * Returns the value of field 'hosts'. The field 'hosts' has
     * the following description: DEPRECATED: This element will
     * probably be removed in future.
     * 
     * @return the value of field 'hosts'.
     */
    public java.lang.String getHosts()
    {
        return this._hosts;
    } //-- java.lang.String getHosts() 

    /**
     * Returns the value of field 'inputStateDirectory'. The field
     * 'inputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @return the value of field 'inputStateDirectory'.
     */
    public java.lang.String getInputStateDirectory()
    {
        return this._inputStateDirectory;
    } //-- java.lang.String getInputStateDirectory() 

    /**
     * Returns the value of field 'modelConfigFile'. The field
     * 'modelConfigFile' has the following description: The path
     * and name of the model configuration file (relative to the
     * model template directory).
     * 
     * @return the value of field 'modelConfigFile'.
     */
    public java.lang.String getModelConfigFile()
    {
        return this._modelConfigFile;
    } //-- java.lang.String getModelConfigFile() 

    /**
     * Returns the value of field 'modelTemplateDirectory'. The
     * field 'modelTemplateDirectory' has the following
     * description: Path and name of the model template directory
     * (relative to this configuration file). This directory will
     * be cloned to create instance directories called work0,
     * work1, work2, etc. The work directories will be created next
     * to the model template directory, i.e. with the same parent
     * directory. Before each run, any work directories from
     * previous runs will be removed.
     * 
     * @return the value of field 'modelTemplateDirectory'.
     */
    public java.lang.String getModelTemplateDirectory()
    {
        return this._modelTemplateDirectory;
    } //-- java.lang.String getModelTemplateDirectory() 

    /**
     * Returns the value of field 'outputStateDirectory'. The field
     * 'outputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @return the value of field 'outputStateDirectory'.
     */
    public java.lang.String getOutputStateDirectory()
    {
        return this._outputStateDirectory;
    } //-- java.lang.String getOutputStateDirectory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeBmiModelForcingsConfig
     * 
     * @param vBmiModelForcingsConfig
     */
    public boolean removeBmiModelForcingsConfig(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML vBmiModelForcingsConfig)
    {
        boolean removed = _bmiModelForcingsConfigList.remove(vBmiModelForcingsConfig);
        return removed;
    } //-- boolean removeBmiModelForcingsConfig(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) 

    /**
     * Sets the value of field 'bmiModelFactoryConfigXMLChoice'.
     * 
     * @param bmiModelFactoryConfigXMLChoice the value of field
     * 'bmiModelFactoryConfigXMLChoice'.
     */
    public void setBmiModelFactoryConfigXMLChoice(org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice bmiModelFactoryConfigXMLChoice)
    {
        this._bmiModelFactoryConfigXMLChoice = bmiModelFactoryConfigXMLChoice;
    } //-- void setBmiModelFactoryConfigXMLChoice(org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXMLChoice) 

    /**
     * Method setBmiModelForcingsConfig
     * 
     * @param index
     * @param vBmiModelForcingsConfig
     */
    public void setBmiModelForcingsConfig(int index, org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML vBmiModelForcingsConfig)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _bmiModelForcingsConfigList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _bmiModelForcingsConfigList.set(index, vBmiModelForcingsConfig);
    } //-- void setBmiModelForcingsConfig(int, org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) 

    /**
     * Method setBmiModelForcingsConfig
     * 
     * @param bmiModelForcingsConfigArray
     */
    public void setBmiModelForcingsConfig(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML[] bmiModelForcingsConfigArray)
    {
        //-- copy array
        _bmiModelForcingsConfigList.clear();
        for (int i = 0; i < bmiModelForcingsConfigArray.length; i++) {
            _bmiModelForcingsConfigList.add(bmiModelForcingsConfigArray[i]);
        }
    } //-- void setBmiModelForcingsConfig(org.openda.model_bmi.io.castorgenerated.BmiModelForcingsConfigXML) 

    /**
     * Sets the value of field 'bmiModelStateExchangeItems'.
     * 
     * @param bmiModelStateExchangeItems the value of field
     * 'bmiModelStateExchangeItems'.
     */
    public void setBmiModelStateExchangeItems(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML bmiModelStateExchangeItems)
    {
        this._bmiModelStateExchangeItems = bmiModelStateExchangeItems;
    } //-- void setBmiModelStateExchangeItems(org.openda.model_bmi.io.castorgenerated.BmiModelStateExchangeItemXML) 

    /**
     * Sets the value of field 'hosts'. The field 'hosts' has the
     * following description: DEPRECATED: This element will
     * probably be removed in future.
     * 
     * @param hosts the value of field 'hosts'.
     */
    public void setHosts(java.lang.String hosts)
    {
        this._hosts = hosts;
    } //-- void setHosts(java.lang.String) 

    /**
     * Sets the value of field 'inputStateDirectory'. The field
     * 'inputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @param inputStateDirectory the value of field
     * 'inputStateDirectory'.
     */
    public void setInputStateDirectory(java.lang.String inputStateDirectory)
    {
        this._inputStateDirectory = inputStateDirectory;
    } //-- void setInputStateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'modelConfigFile'. The field
     * 'modelConfigFile' has the following description: The path
     * and name of the model configuration file (relative to the
     * model template directory).
     * 
     * @param modelConfigFile the value of field 'modelConfigFile'.
     */
    public void setModelConfigFile(java.lang.String modelConfigFile)
    {
        this._modelConfigFile = modelConfigFile;
    } //-- void setModelConfigFile(java.lang.String) 

    /**
     * Sets the value of field 'modelTemplateDirectory'. The field
     * 'modelTemplateDirectory' has the following description: Path
     * and name of the model template directory (relative to this
     * configuration file). This directory will be cloned to create
     * instance directories called work0, work1, work2, etc. The
     * work directories will be created next to the model template
     * directory, i.e. with the same parent directory. Before each
     * run, any work directories from previous runs will be
     * removed.
     * 
     * @param modelTemplateDirectory the value of field
     * 'modelTemplateDirectory'.
     */
    public void setModelTemplateDirectory(java.lang.String modelTemplateDirectory)
    {
        this._modelTemplateDirectory = modelTemplateDirectory;
    } //-- void setModelTemplateDirectory(java.lang.String) 

    /**
     * Sets the value of field 'outputStateDirectory'. The field
     * 'outputStateDirectory' has the following description: The
     * directory in the model instance that contains the input
     * state
     * 
     * @param outputStateDirectory the value of field
     * 'outputStateDirectory'.
     */
    public void setOutputStateDirectory(java.lang.String outputStateDirectory)
    {
        this._outputStateDirectory = outputStateDirectory;
    } //-- void setOutputStateDirectory(java.lang.String) 

    /**
     * Method unmarshalBmiModelFactoryConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXML unmarshalBmiModelFactoryConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXML) Unmarshaller.unmarshal(org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXML.class, reader);
    } //-- org.openda.model_bmi.io.castorgenerated.BmiModelFactoryConfigXML unmarshalBmiModelFactoryConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
