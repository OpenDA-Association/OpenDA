/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_wflow.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class WflowModelFactoryConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class WflowModelFactoryConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The name of the Python module that contains the model to
     * use, e.g. wflow_hbv.
     */
    private java.lang.String _pythonModuleName;

    /**
     * Optional run period for the model. If the timeHorizon is set
     * from 'outside' (e.g. when running from an operational
     * system), then that timeHorizon overrules the timeHorizon
     * that is configured here (if this is present). For runs with
     * only OpenDA the timeHorizon for the model must be configured
     * here.
     */
    private org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML _timeHorizon;

    /**
     * Case directory path (relative to this configuration file).
     */
    private java.lang.String _caseDirectory;

    /**
     * Base name of the run id within the current case (relative to
     * the case directory). The number of the instance will be
     * appended to this base name to create the instance run id
     * (instance directory name).
     */
    private java.lang.String _templateRunId;

    /**
     * The name of the model configuration file (relative to the
     * case directory).
     */
    private java.lang.String _modelConfigFileName;

    /**
     * The name of the map file that describes the catchment
     * (relative to the staticmaps folder in the case directory).
     */
    private java.lang.String _cloneMapFileName;

    /**
     * The path and name of one or more input netcdf files
     * (relative to the case directory). Together these input files
     * must contain all (boundary) input data that is needed for
     * the model to run. If the (boundary) input data should be
     * different for different model instances, then use the option
     * boundaryProvider in the blackBoxStochModel config instead.
     */
    private java.util.ArrayList _inputFileList;

    /**
     * The path and name of the model output netcdf file (relative
     * to the instance directory). This file will be created during
     * the model run. After each model timestep the model output
     * data will be written to this file.
     */
    private java.lang.String _modelOutputFile;

    /**
     * The path and name of the analysis output netcdf file
     * (relative to the instance directory). This file will be
     * created during the model run. After each analysis time the
     * updated state will be written to this file.
     */
    private java.lang.String _analysisOutputFile;

    /**
     * Selection of exchange items to be included in the model and
     * analysis output files (2D gridded data).
     */
    private java.util.ArrayList _outputExchangeItemIdList;

    /**
     * Specification of scalar model output to be written to output
     * netcdf files.
     */
    private org.openda.model_wflow.io.castorgenerated.ScalarModelOutput _scalarModelOutput;


      //----------------/
     //- Constructors -/
    //----------------/

    public WflowModelFactoryConfigXML() {
        super();
        _inputFileList = new ArrayList();
        _outputExchangeItemIdList = new ArrayList();
    } //-- org.openda.model_wflow.io.castorgenerated.WflowModelFactoryConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addInputFile
     * 
     * @param vInputFile
     */
    public void addInputFile(java.lang.String vInputFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _inputFileList.add(vInputFile);
    } //-- void addInputFile(java.lang.String) 

    /**
     * Method addInputFile
     * 
     * @param index
     * @param vInputFile
     */
    public void addInputFile(int index, java.lang.String vInputFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _inputFileList.add(index, vInputFile);
    } //-- void addInputFile(int, java.lang.String) 

    /**
     * Method addOutputExchangeItemId
     * 
     * @param vOutputExchangeItemId
     */
    public void addOutputExchangeItemId(java.lang.String vOutputExchangeItemId)
        throws java.lang.IndexOutOfBoundsException
    {
        _outputExchangeItemIdList.add(vOutputExchangeItemId);
    } //-- void addOutputExchangeItemId(java.lang.String) 

    /**
     * Method addOutputExchangeItemId
     * 
     * @param index
     * @param vOutputExchangeItemId
     */
    public void addOutputExchangeItemId(int index, java.lang.String vOutputExchangeItemId)
        throws java.lang.IndexOutOfBoundsException
    {
        _outputExchangeItemIdList.add(index, vOutputExchangeItemId);
    } //-- void addOutputExchangeItemId(int, java.lang.String) 

    /**
     * Method clearInputFile
     */
    public void clearInputFile()
    {
        _inputFileList.clear();
    } //-- void clearInputFile() 

    /**
     * Method clearOutputExchangeItemId
     */
    public void clearOutputExchangeItemId()
    {
        _outputExchangeItemIdList.clear();
    } //-- void clearOutputExchangeItemId() 

    /**
     * Method enumerateInputFile
     */
    public java.util.Enumeration enumerateInputFile()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_inputFileList.iterator());
    } //-- java.util.Enumeration enumerateInputFile() 

    /**
     * Method enumerateOutputExchangeItemId
     */
    public java.util.Enumeration enumerateOutputExchangeItemId()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_outputExchangeItemIdList.iterator());
    } //-- java.util.Enumeration enumerateOutputExchangeItemId() 

    /**
     * Returns the value of field 'analysisOutputFile'. The field
     * 'analysisOutputFile' has the following description: The path
     * and name of the analysis output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each analysis time the updated state will
     * be written to this file.
     * 
     * @return the value of field 'analysisOutputFile'.
     */
    public java.lang.String getAnalysisOutputFile()
    {
        return this._analysisOutputFile;
    } //-- java.lang.String getAnalysisOutputFile() 

    /**
     * Returns the value of field 'caseDirectory'. The field
     * 'caseDirectory' has the following description: Case
     * directory path (relative to this configuration file).
     * 
     * @return the value of field 'caseDirectory'.
     */
    public java.lang.String getCaseDirectory()
    {
        return this._caseDirectory;
    } //-- java.lang.String getCaseDirectory() 

    /**
     * Returns the value of field 'cloneMapFileName'. The field
     * 'cloneMapFileName' has the following description: The name
     * of the map file that describes the catchment (relative to
     * the staticmaps folder in the case directory).
     * 
     * @return the value of field 'cloneMapFileName'.
     */
    public java.lang.String getCloneMapFileName()
    {
        return this._cloneMapFileName;
    } //-- java.lang.String getCloneMapFileName() 

    /**
     * Method getInputFile
     * 
     * @param index
     */
    public java.lang.String getInputFile(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _inputFileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_inputFileList.get(index);
    } //-- java.lang.String getInputFile(int) 

    /**
     * Method getInputFile
     */
    public java.lang.String[] getInputFile()
    {
        int size = _inputFileList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_inputFileList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getInputFile() 

    /**
     * Method getInputFileCount
     */
    public int getInputFileCount()
    {
        return _inputFileList.size();
    } //-- int getInputFileCount() 

    /**
     * Returns the value of field 'modelConfigFileName'. The field
     * 'modelConfigFileName' has the following description: The
     * name of the model configuration file (relative to the case
     * directory).
     * 
     * @return the value of field 'modelConfigFileName'.
     */
    public java.lang.String getModelConfigFileName()
    {
        return this._modelConfigFileName;
    } //-- java.lang.String getModelConfigFileName() 

    /**
     * Returns the value of field 'modelOutputFile'. The field
     * 'modelOutputFile' has the following description: The path
     * and name of the model output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each model timestep the model output data
     * will be written to this file.
     * 
     * @return the value of field 'modelOutputFile'.
     */
    public java.lang.String getModelOutputFile()
    {
        return this._modelOutputFile;
    } //-- java.lang.String getModelOutputFile() 

    /**
     * Method getOutputExchangeItemId
     * 
     * @param index
     */
    public java.lang.String getOutputExchangeItemId(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _outputExchangeItemIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_outputExchangeItemIdList.get(index);
    } //-- java.lang.String getOutputExchangeItemId(int) 

    /**
     * Method getOutputExchangeItemId
     */
    public java.lang.String[] getOutputExchangeItemId()
    {
        int size = _outputExchangeItemIdList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_outputExchangeItemIdList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getOutputExchangeItemId() 

    /**
     * Method getOutputExchangeItemIdCount
     */
    public int getOutputExchangeItemIdCount()
    {
        return _outputExchangeItemIdList.size();
    } //-- int getOutputExchangeItemIdCount() 

    /**
     * Returns the value of field 'pythonModuleName'. The field
     * 'pythonModuleName' has the following description: The name
     * of the Python module that contains the model to use, e.g.
     * wflow_hbv.
     * 
     * @return the value of field 'pythonModuleName'.
     */
    public java.lang.String getPythonModuleName()
    {
        return this._pythonModuleName;
    } //-- java.lang.String getPythonModuleName() 

    /**
     * Returns the value of field 'scalarModelOutput'. The field
     * 'scalarModelOutput' has the following description:
     * Specification of scalar model output to be written to output
     * netcdf files.
     * 
     * @return the value of field 'scalarModelOutput'.
     */
    public org.openda.model_wflow.io.castorgenerated.ScalarModelOutput getScalarModelOutput()
    {
        return this._scalarModelOutput;
    } //-- org.openda.model_wflow.io.castorgenerated.ScalarModelOutput getScalarModelOutput() 

    /**
     * Returns the value of field 'templateRunId'. The field
     * 'templateRunId' has the following description: Base name of
     * the run id within the current case (relative to the case
     * directory). The number of the instance will be appended to
     * this base name to create the instance run id (instance
     * directory name).
     * 
     * @return the value of field 'templateRunId'.
     */
    public java.lang.String getTemplateRunId()
    {
        return this._templateRunId;
    } //-- java.lang.String getTemplateRunId() 

    /**
     * Returns the value of field 'timeHorizon'. The field
     * 'timeHorizon' has the following description: Optional run
     * period for the model. If the timeHorizon is set from
     * 'outside' (e.g. when running from an operational system),
     * then that timeHorizon overrules the timeHorizon that is
     * configured here (if this is present). For runs with only
     * OpenDA the timeHorizon for the model must be configured
     * here.
     * 
     * @return the value of field 'timeHorizon'.
     */
    public org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML getTimeHorizon()
    {
        return this._timeHorizon;
    } //-- org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML getTimeHorizon() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeInputFile
     * 
     * @param vInputFile
     */
    public boolean removeInputFile(java.lang.String vInputFile)
    {
        boolean removed = _inputFileList.remove(vInputFile);
        return removed;
    } //-- boolean removeInputFile(java.lang.String) 

    /**
     * Method removeOutputExchangeItemId
     * 
     * @param vOutputExchangeItemId
     */
    public boolean removeOutputExchangeItemId(java.lang.String vOutputExchangeItemId)
    {
        boolean removed = _outputExchangeItemIdList.remove(vOutputExchangeItemId);
        return removed;
    } //-- boolean removeOutputExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'analysisOutputFile'. The field
     * 'analysisOutputFile' has the following description: The path
     * and name of the analysis output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each analysis time the updated state will
     * be written to this file.
     * 
     * @param analysisOutputFile the value of field
     * 'analysisOutputFile'.
     */
    public void setAnalysisOutputFile(java.lang.String analysisOutputFile)
    {
        this._analysisOutputFile = analysisOutputFile;
    } //-- void setAnalysisOutputFile(java.lang.String) 

    /**
     * Sets the value of field 'caseDirectory'. The field
     * 'caseDirectory' has the following description: Case
     * directory path (relative to this configuration file).
     * 
     * @param caseDirectory the value of field 'caseDirectory'.
     */
    public void setCaseDirectory(java.lang.String caseDirectory)
    {
        this._caseDirectory = caseDirectory;
    } //-- void setCaseDirectory(java.lang.String) 

    /**
     * Sets the value of field 'cloneMapFileName'. The field
     * 'cloneMapFileName' has the following description: The name
     * of the map file that describes the catchment (relative to
     * the staticmaps folder in the case directory).
     * 
     * @param cloneMapFileName the value of field 'cloneMapFileName'
     */
    public void setCloneMapFileName(java.lang.String cloneMapFileName)
    {
        this._cloneMapFileName = cloneMapFileName;
    } //-- void setCloneMapFileName(java.lang.String) 

    /**
     * Method setInputFile
     * 
     * @param index
     * @param vInputFile
     */
    public void setInputFile(int index, java.lang.String vInputFile)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _inputFileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _inputFileList.set(index, vInputFile);
    } //-- void setInputFile(int, java.lang.String) 

    /**
     * Method setInputFile
     * 
     * @param inputFileArray
     */
    public void setInputFile(java.lang.String[] inputFileArray)
    {
        //-- copy array
        _inputFileList.clear();
        for (int i = 0; i < inputFileArray.length; i++) {
            _inputFileList.add(inputFileArray[i]);
        }
    } //-- void setInputFile(java.lang.String) 

    /**
     * Sets the value of field 'modelConfigFileName'. The field
     * 'modelConfigFileName' has the following description: The
     * name of the model configuration file (relative to the case
     * directory).
     * 
     * @param modelConfigFileName the value of field
     * 'modelConfigFileName'.
     */
    public void setModelConfigFileName(java.lang.String modelConfigFileName)
    {
        this._modelConfigFileName = modelConfigFileName;
    } //-- void setModelConfigFileName(java.lang.String) 

    /**
     * Sets the value of field 'modelOutputFile'. The field
     * 'modelOutputFile' has the following description: The path
     * and name of the model output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each model timestep the model output data
     * will be written to this file.
     * 
     * @param modelOutputFile the value of field 'modelOutputFile'.
     */
    public void setModelOutputFile(java.lang.String modelOutputFile)
    {
        this._modelOutputFile = modelOutputFile;
    } //-- void setModelOutputFile(java.lang.String) 

    /**
     * Method setOutputExchangeItemId
     * 
     * @param index
     * @param vOutputExchangeItemId
     */
    public void setOutputExchangeItemId(int index, java.lang.String vOutputExchangeItemId)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _outputExchangeItemIdList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _outputExchangeItemIdList.set(index, vOutputExchangeItemId);
    } //-- void setOutputExchangeItemId(int, java.lang.String) 

    /**
     * Method setOutputExchangeItemId
     * 
     * @param outputExchangeItemIdArray
     */
    public void setOutputExchangeItemId(java.lang.String[] outputExchangeItemIdArray)
    {
        //-- copy array
        _outputExchangeItemIdList.clear();
        for (int i = 0; i < outputExchangeItemIdArray.length; i++) {
            _outputExchangeItemIdList.add(outputExchangeItemIdArray[i]);
        }
    } //-- void setOutputExchangeItemId(java.lang.String) 

    /**
     * Sets the value of field 'pythonModuleName'. The field
     * 'pythonModuleName' has the following description: The name
     * of the Python module that contains the model to use, e.g.
     * wflow_hbv.
     * 
     * @param pythonModuleName the value of field 'pythonModuleName'
     */
    public void setPythonModuleName(java.lang.String pythonModuleName)
    {
        this._pythonModuleName = pythonModuleName;
    } //-- void setPythonModuleName(java.lang.String) 

    /**
     * Sets the value of field 'scalarModelOutput'. The field
     * 'scalarModelOutput' has the following description:
     * Specification of scalar model output to be written to output
     * netcdf files.
     * 
     * @param scalarModelOutput the value of field
     * 'scalarModelOutput'.
     */
    public void setScalarModelOutput(org.openda.model_wflow.io.castorgenerated.ScalarModelOutput scalarModelOutput)
    {
        this._scalarModelOutput = scalarModelOutput;
    } //-- void setScalarModelOutput(org.openda.model_wflow.io.castorgenerated.ScalarModelOutput) 

    /**
     * Sets the value of field 'templateRunId'. The field
     * 'templateRunId' has the following description: Base name of
     * the run id within the current case (relative to the case
     * directory). The number of the instance will be appended to
     * this base name to create the instance run id (instance
     * directory name).
     * 
     * @param templateRunId the value of field 'templateRunId'.
     */
    public void setTemplateRunId(java.lang.String templateRunId)
    {
        this._templateRunId = templateRunId;
    } //-- void setTemplateRunId(java.lang.String) 

    /**
     * Sets the value of field 'timeHorizon'. The field
     * 'timeHorizon' has the following description: Optional run
     * period for the model. If the timeHorizon is set from
     * 'outside' (e.g. when running from an operational system),
     * then that timeHorizon overrules the timeHorizon that is
     * configured here (if this is present). For runs with only
     * OpenDA the timeHorizon for the model must be configured
     * here.
     * 
     * @param timeHorizon the value of field 'timeHorizon'.
     */
    public void setTimeHorizon(org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML timeHorizon)
    {
        this._timeHorizon = timeHorizon;
    } //-- void setTimeHorizon(org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML) 

    /**
     * Method unmarshalWflowModelFactoryConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_wflow.io.castorgenerated.WflowModelFactoryConfigXML unmarshalWflowModelFactoryConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_wflow.io.castorgenerated.WflowModelFactoryConfigXML) Unmarshaller.unmarshal(org.openda.model_wflow.io.castorgenerated.WflowModelFactoryConfigXML.class, reader);
    } //-- org.openda.model_wflow.io.castorgenerated.WflowModelFactoryConfigXML unmarshalWflowModelFactoryConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
