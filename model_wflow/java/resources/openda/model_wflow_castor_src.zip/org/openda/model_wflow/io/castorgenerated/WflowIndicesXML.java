/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_wflow.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class WflowIndicesXML.
 * 
 * @version $Revision$ $Date$
 */
public class WflowIndicesXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Indices of the selected array elements of the first
     * dimension. Format: "ind1" (single index)," ind1:" (from ind1
     * up to the last index), ":ind1" (from the first index up to
     * ind1), "ind1:ind2" (from ind1 up to ind2). Example: 8, :4,
     * 19:, 7:12.
     */
    private java.lang.String _index1;

    /**
     * Indices of the selected array elements of the second
     * dimension. Format: "ind1" (single index)," ind1:" (from ind1
     * up to the last index), ":ind1" (from the first index up to
     * ind1), "ind1:ind2" (from ind1 up to ind2). Example: 8, :4,
     * 19:, 7:12.
     */
    private java.lang.String _index2;

    /**
     * Indices of the selected array elements of the third
     * dimension. Format: "ind1" (single index)," ind1:" (from ind1
     * up to the last index), ":ind1" (from the first index up to
     * ind1), "ind1:ind2" (from ind1 up to ind2). Example: 8, :4,
     * 19:, 7:12.
     */
    private java.lang.String _index3;

    /**
     * Base number, which gives the index of the vector's first
     * element (sometimes 1 instead of 0)
     */
    private int _base = 0;

    /**
     * keeps track of state for field: _base
     */
    private boolean _has_base;


      //----------------/
     //- Constructors -/
    //----------------/

    public WflowIndicesXML() {
        super();
    } //-- org.openda.model_wflow.io.castorgenerated.WflowIndicesXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteBase
     */
    public void deleteBase()
    {
        this._has_base= false;
    } //-- void deleteBase() 

    /**
     * Returns the value of field 'base'. The field 'base' has the
     * following description: Base number, which gives the index of
     * the vector's first element (sometimes 1 instead of 0)
     * 
     * @return the value of field 'base'.
     */
    public int getBase()
    {
        return this._base;
    } //-- int getBase() 

    /**
     * Returns the value of field 'index1'. The field 'index1' has
     * the following description: Indices of the selected array
     * elements of the first dimension. Format: "ind1" (single
     * index)," ind1:" (from ind1 up to the last index), ":ind1"
     * (from the first index up to ind1), "ind1:ind2" (from ind1 up
     * to ind2). Example: 8, :4, 19:, 7:12.
     * 
     * @return the value of field 'index1'.
     */
    public java.lang.String getIndex1()
    {
        return this._index1;
    } //-- java.lang.String getIndex1() 

    /**
     * Returns the value of field 'index2'. The field 'index2' has
     * the following description: Indices of the selected array
     * elements of the second dimension. Format: "ind1" (single
     * index)," ind1:" (from ind1 up to the last index), ":ind1"
     * (from the first index up to ind1), "ind1:ind2" (from ind1 up
     * to ind2). Example: 8, :4, 19:, 7:12.
     * 
     * @return the value of field 'index2'.
     */
    public java.lang.String getIndex2()
    {
        return this._index2;
    } //-- java.lang.String getIndex2() 

    /**
     * Returns the value of field 'index3'. The field 'index3' has
     * the following description: Indices of the selected array
     * elements of the third dimension. Format: "ind1" (single
     * index)," ind1:" (from ind1 up to the last index), ":ind1"
     * (from the first index up to ind1), "ind1:ind2" (from ind1 up
     * to ind2). Example: 8, :4, 19:, 7:12.
     * 
     * @return the value of field 'index3'.
     */
    public java.lang.String getIndex3()
    {
        return this._index3;
    } //-- java.lang.String getIndex3() 

    /**
     * Method hasBase
     */
    public boolean hasBase()
    {
        return this._has_base;
    } //-- boolean hasBase() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'base'. The field 'base' has the
     * following description: Base number, which gives the index of
     * the vector's first element (sometimes 1 instead of 0)
     * 
     * @param base the value of field 'base'.
     */
    public void setBase(int base)
    {
        this._base = base;
        this._has_base = true;
    } //-- void setBase(int) 

    /**
     * Sets the value of field 'index1'. The field 'index1' has the
     * following description: Indices of the selected array
     * elements of the first dimension. Format: "ind1" (single
     * index)," ind1:" (from ind1 up to the last index), ":ind1"
     * (from the first index up to ind1), "ind1:ind2" (from ind1 up
     * to ind2). Example: 8, :4, 19:, 7:12.
     * 
     * @param index1 the value of field 'index1'.
     */
    public void setIndex1(java.lang.String index1)
    {
        this._index1 = index1;
    } //-- void setIndex1(java.lang.String) 

    /**
     * Sets the value of field 'index2'. The field 'index2' has the
     * following description: Indices of the selected array
     * elements of the second dimension. Format: "ind1" (single
     * index)," ind1:" (from ind1 up to the last index), ":ind1"
     * (from the first index up to ind1), "ind1:ind2" (from ind1 up
     * to ind2). Example: 8, :4, 19:, 7:12.
     * 
     * @param index2 the value of field 'index2'.
     */
    public void setIndex2(java.lang.String index2)
    {
        this._index2 = index2;
    } //-- void setIndex2(java.lang.String) 

    /**
     * Sets the value of field 'index3'. The field 'index3' has the
     * following description: Indices of the selected array
     * elements of the third dimension. Format: "ind1" (single
     * index)," ind1:" (from ind1 up to the last index), ":ind1"
     * (from the first index up to ind1), "ind1:ind2" (from ind1 up
     * to ind2). Example: 8, :4, 19:, 7:12.
     * 
     * @param index3 the value of field 'index3'.
     */
    public void setIndex3(java.lang.String index3)
    {
        this._index3 = index3;
    } //-- void setIndex3(java.lang.String) 

    /**
     * Method unmarshalWflowIndicesXML
     * 
     * @param reader
     */
    public static org.openda.model_wflow.io.castorgenerated.WflowIndicesXML unmarshalWflowIndicesXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_wflow.io.castorgenerated.WflowIndicesXML) Unmarshaller.unmarshal(org.openda.model_wflow.io.castorgenerated.WflowIndicesXML.class, reader);
    } //-- org.openda.model_wflow.io.castorgenerated.WflowIndicesXML unmarshalWflowIndicesXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
