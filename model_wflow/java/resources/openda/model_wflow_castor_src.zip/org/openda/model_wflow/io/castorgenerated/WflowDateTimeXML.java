/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_wflow.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.types.Time;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class WflowDateTimeXML.
 * 
 * @version $Revision$ $Date$
 */
public class WflowDateTimeXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _date
     */
    private org.exolab.castor.types.Date _date;

    /**
     * Field _time
     */
    private org.exolab.castor.types.Time _time;


      //----------------/
     //- Constructors -/
    //----------------/

    public WflowDateTimeXML() {
        super();
    } //-- org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'date'.
     * 
     * @return the value of field 'date'.
     */
    public org.exolab.castor.types.Date getDate()
    {
        return this._date;
    } //-- org.exolab.castor.types.Date getDate() 

    /**
     * Returns the value of field 'time'.
     * 
     * @return the value of field 'time'.
     */
    public org.exolab.castor.types.Time getTime()
    {
        return this._time;
    } //-- org.exolab.castor.types.Time getTime() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'date'.
     * 
     * @param date the value of field 'date'.
     */
    public void setDate(org.exolab.castor.types.Date date)
    {
        this._date = date;
    } //-- void setDate(org.exolab.castor.types.Date) 

    /**
     * Sets the value of field 'time'.
     * 
     * @param time the value of field 'time'.
     */
    public void setTime(org.exolab.castor.types.Time time)
    {
        this._time = time;
    } //-- void setTime(org.exolab.castor.types.Time) 

    /**
     * Method unmarshalWflowDateTimeXML
     * 
     * @param reader
     */
    public static org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML unmarshalWflowDateTimeXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML) Unmarshaller.unmarshal(org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML.class, reader);
    } //-- org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML unmarshalWflowDateTimeXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
