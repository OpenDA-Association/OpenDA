/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_wflow.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Specification of scalar model output to be written to output
 * netcdf files.
 * 
 * @version $Revision$ $Date$
 */
public class ScalarModelOutput implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The path and name of the model output netcdf file (relative
     * to the instance directory). This file will be created during
     * the model run. After each model timestep the model output
     * data will be written to this file.
     */
    private java.lang.String _modelOutputFile;

    /**
     * The path and name of the analysis output netcdf file
     * (relative to the instance directory). This file will be
     * created during the model run. After each analysis time the
     * updated state will be written to this file.
     */
    private java.lang.String _analysisOutputFile;

    /**
     * Specification of source exchange items and their
     * corresponding selection.
     */
    private java.util.ArrayList _subVectorList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ScalarModelOutput() {
        super();
        _subVectorList = new ArrayList();
    } //-- org.openda.model_wflow.io.castorgenerated.ScalarModelOutput()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addSubVector
     * 
     * @param vSubVector
     */
    public void addSubVector(org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput vSubVector)
        throws java.lang.IndexOutOfBoundsException
    {
        _subVectorList.add(vSubVector);
    } //-- void addSubVector(org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) 

    /**
     * Method addSubVector
     * 
     * @param index
     * @param vSubVector
     */
    public void addSubVector(int index, org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput vSubVector)
        throws java.lang.IndexOutOfBoundsException
    {
        _subVectorList.add(index, vSubVector);
    } //-- void addSubVector(int, org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) 

    /**
     * Method clearSubVector
     */
    public void clearSubVector()
    {
        _subVectorList.clear();
    } //-- void clearSubVector() 

    /**
     * Method enumerateSubVector
     */
    public java.util.Enumeration enumerateSubVector()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_subVectorList.iterator());
    } //-- java.util.Enumeration enumerateSubVector() 

    /**
     * Returns the value of field 'analysisOutputFile'. The field
     * 'analysisOutputFile' has the following description: The path
     * and name of the analysis output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each analysis time the updated state will
     * be written to this file.
     * 
     * @return the value of field 'analysisOutputFile'.
     */
    public java.lang.String getAnalysisOutputFile()
    {
        return this._analysisOutputFile;
    } //-- java.lang.String getAnalysisOutputFile() 

    /**
     * Returns the value of field 'modelOutputFile'. The field
     * 'modelOutputFile' has the following description: The path
     * and name of the model output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each model timestep the model output data
     * will be written to this file.
     * 
     * @return the value of field 'modelOutputFile'.
     */
    public java.lang.String getModelOutputFile()
    {
        return this._modelOutputFile;
    } //-- java.lang.String getModelOutputFile() 

    /**
     * Method getSubVector
     * 
     * @param index
     */
    public org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput getSubVector(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _subVectorList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) _subVectorList.get(index);
    } //-- org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput getSubVector(int) 

    /**
     * Method getSubVector
     */
    public org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput[] getSubVector()
    {
        int size = _subVectorList.size();
        org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput[] mArray = new org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) _subVectorList.get(index);
        }
        return mArray;
    } //-- org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput[] getSubVector() 

    /**
     * Method getSubVectorCount
     */
    public int getSubVectorCount()
    {
        return _subVectorList.size();
    } //-- int getSubVectorCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeSubVector
     * 
     * @param vSubVector
     */
    public boolean removeSubVector(org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput vSubVector)
    {
        boolean removed = _subVectorList.remove(vSubVector);
        return removed;
    } //-- boolean removeSubVector(org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) 

    /**
     * Sets the value of field 'analysisOutputFile'. The field
     * 'analysisOutputFile' has the following description: The path
     * and name of the analysis output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each analysis time the updated state will
     * be written to this file.
     * 
     * @param analysisOutputFile the value of field
     * 'analysisOutputFile'.
     */
    public void setAnalysisOutputFile(java.lang.String analysisOutputFile)
    {
        this._analysisOutputFile = analysisOutputFile;
    } //-- void setAnalysisOutputFile(java.lang.String) 

    /**
     * Sets the value of field 'modelOutputFile'. The field
     * 'modelOutputFile' has the following description: The path
     * and name of the model output netcdf file (relative to the
     * instance directory). This file will be created during the
     * model run. After each model timestep the model output data
     * will be written to this file.
     * 
     * @param modelOutputFile the value of field 'modelOutputFile'.
     */
    public void setModelOutputFile(java.lang.String modelOutputFile)
    {
        this._modelOutputFile = modelOutputFile;
    } //-- void setModelOutputFile(java.lang.String) 

    /**
     * Method setSubVector
     * 
     * @param index
     * @param vSubVector
     */
    public void setSubVector(int index, org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput vSubVector)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _subVectorList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _subVectorList.set(index, vSubVector);
    } //-- void setSubVector(int, org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) 

    /**
     * Method setSubVector
     * 
     * @param subVectorArray
     */
    public void setSubVector(org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput[] subVectorArray)
    {
        //-- copy array
        _subVectorList.clear();
        for (int i = 0; i < subVectorArray.length; i++) {
            _subVectorList.add(subVectorArray[i]);
        }
    } //-- void setSubVector(org.openda.model_wflow.io.castorgenerated.WflowScalarModelOutput) 

    /**
     * Method unmarshalScalarModelOutput
     * 
     * @param reader
     */
    public static org.openda.model_wflow.io.castorgenerated.ScalarModelOutput unmarshalScalarModelOutput(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_wflow.io.castorgenerated.ScalarModelOutput) Unmarshaller.unmarshal(org.openda.model_wflow.io.castorgenerated.ScalarModelOutput.class, reader);
    } //-- org.openda.model_wflow.io.castorgenerated.ScalarModelOutput unmarshalScalarModelOutput(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
