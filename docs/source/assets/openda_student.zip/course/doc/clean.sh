#! /bin/bash

rm -f latex/pdf*.fls
rm -f latex/*.tmp
rm -f latex/openda_course_summerschool_2023.log
rm -f latex/openda_course_summerschool_2023.aux
rm -f latex/openda_course_summerschool_2023.toc 
rm -f latex/openda_course_summerschool_2023.out

