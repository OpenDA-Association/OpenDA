#!/bin/sh
rm c1_locA.csv
rm c1_locB.csv
rm c1_locC.csv
rm c2_locA.csv
rm c2_locB.csv
rm c2_locC.csv
rm -r maps
rm reactive_pollution_model.log
rm -r restart

