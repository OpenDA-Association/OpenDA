
This module contains the wrapper for the reactive_pollution_model.
To compile the code use:
ant build

Then add reactive_pollution_wrapper.jar from the bin directory to the bin directory of your OpenDA version or
add it to the java CLASSPATH, eg with:
export CLASSPATH=$PWD/bin/reactive_pollution_wrapper.jar

