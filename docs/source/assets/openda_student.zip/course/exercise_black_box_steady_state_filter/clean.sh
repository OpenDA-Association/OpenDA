#! /bin/bash

rm -f [0-9][0-9][0-9][0-9]
rm -rf work/work*
rm -f *_results.py
rm -f openda_logfile.txt
rm -rf enkf_gain_*
rm -rf __pycache__
rm -rf work
