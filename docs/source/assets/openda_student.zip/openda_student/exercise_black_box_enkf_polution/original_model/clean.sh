#! /bin/bash

rm -rf __pycache__

