/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class User.
 * 
 * @version $Revision$ $Date$
 */
public class User implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _NUM
     */
    private org.openda.model_swan.io.castorgenerated.swivt.NUM _NUM;


      //----------------/
     //- Constructors -/
    //----------------/

    public User() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.User()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'NUM'.
     * 
     * @return the value of field 'NUM'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.NUM getNUM()
    {
        return this._NUM;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.NUM getNUM() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'NUM'.
     * 
     * @param NUM the value of field 'NUM'.
     */
    public void setNUM(org.openda.model_swan.io.castorgenerated.swivt.NUM NUM)
    {
        this._NUM = NUM;
    } //-- void setNUM(org.openda.model_swan.io.castorgenerated.swivt.NUM) 

    /**
     * Method unmarshalUser
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.User unmarshalUser(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.User) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.User.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.User unmarshalUser(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
