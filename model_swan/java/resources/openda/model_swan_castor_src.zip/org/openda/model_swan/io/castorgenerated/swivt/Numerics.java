/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class Numerics.
 * 
 * @version $Revision$ $Date$
 */
public class Numerics implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _user
     */
    private org.openda.model_swan.io.castorgenerated.swivt.User _user;


      //----------------/
     //- Constructors -/
    //----------------/

    public Numerics() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Numerics()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'user'.
     * 
     * @return the value of field 'user'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.User getUser()
    {
        return this._user;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.User getUser() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'user'.
     * 
     * @param user the value of field 'user'.
     */
    public void setUser(org.openda.model_swan.io.castorgenerated.swivt.User user)
    {
        this._user = user;
    } //-- void setUser(org.openda.model_swan.io.castorgenerated.swivt.User) 

    /**
     * Method unmarshalNumerics
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.Numerics unmarshalNumerics(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.Numerics) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.Numerics.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Numerics unmarshalNumerics(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
