/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class Physics.
 * 
 * @version $Revision$ $Date$
 */
public class Physics implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _user
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _user;

    /**
     * Field _SWAN4041A
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _SWAN4041A;

    /**
     * Field _SWAN4051A
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _SWAN4051A;

    /**
     * Field _SWAN4072A
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _SWAN4072A;

    /**
     * Field _SWAN4072ABCDE
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _SWAN4072ABCDE;

    /**
     * Field _SWAN4081
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _SWAN4081;

    /**
     * Field _ONR
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _ONR;

    /**
     * Field _HR2006
     */
    private org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan _HR2006;


      //----------------/
     //- Constructors -/
    //----------------/

    public Physics() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Physics()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'HR2006'.
     * 
     * @return the value of field 'HR2006'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getHR2006()
    {
        return this._HR2006;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getHR2006() 

    /**
     * Returns the value of field 'ONR'.
     * 
     * @return the value of field 'ONR'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getONR()
    {
        return this._ONR;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getONR() 

    /**
     * Returns the value of field 'SWAN4041A'.
     * 
     * @return the value of field 'SWAN4041A'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4041A()
    {
        return this._SWAN4041A;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4041A() 

    /**
     * Returns the value of field 'SWAN4051A'.
     * 
     * @return the value of field 'SWAN4051A'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4051A()
    {
        return this._SWAN4051A;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4051A() 

    /**
     * Returns the value of field 'SWAN4072A'.
     * 
     * @return the value of field 'SWAN4072A'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4072A()
    {
        return this._SWAN4072A;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4072A() 

    /**
     * Returns the value of field 'SWAN4072ABCDE'.
     * 
     * @return the value of field 'SWAN4072ABCDE'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4072ABCDE()
    {
        return this._SWAN4072ABCDE;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4072ABCDE() 

    /**
     * Returns the value of field 'SWAN4081'.
     * 
     * @return the value of field 'SWAN4081'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4081()
    {
        return this._SWAN4081;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getSWAN4081() 

    /**
     * Returns the value of field 'user'.
     * 
     * @return the value of field 'user'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getUser()
    {
        return this._user;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan getUser() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'HR2006'.
     * 
     * @param HR2006 the value of field 'HR2006'.
     */
    public void setHR2006(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan HR2006)
    {
        this._HR2006 = HR2006;
    } //-- void setHR2006(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'ONR'.
     * 
     * @param ONR the value of field 'ONR'.
     */
    public void setONR(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan ONR)
    {
        this._ONR = ONR;
    } //-- void setONR(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'SWAN4041A'.
     * 
     * @param SWAN4041A the value of field 'SWAN4041A'.
     */
    public void setSWAN4041A(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan SWAN4041A)
    {
        this._SWAN4041A = SWAN4041A;
    } //-- void setSWAN4041A(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'SWAN4051A'.
     * 
     * @param SWAN4051A the value of field 'SWAN4051A'.
     */
    public void setSWAN4051A(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan SWAN4051A)
    {
        this._SWAN4051A = SWAN4051A;
    } //-- void setSWAN4051A(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'SWAN4072A'.
     * 
     * @param SWAN4072A the value of field 'SWAN4072A'.
     */
    public void setSWAN4072A(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan SWAN4072A)
    {
        this._SWAN4072A = SWAN4072A;
    } //-- void setSWAN4072A(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'SWAN4072ABCDE'.
     * 
     * @param SWAN4072ABCDE the value of field 'SWAN4072ABCDE'.
     */
    public void setSWAN4072ABCDE(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan SWAN4072ABCDE)
    {
        this._SWAN4072ABCDE = SWAN4072ABCDE;
    } //-- void setSWAN4072ABCDE(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'SWAN4081'.
     * 
     * @param SWAN4081 the value of field 'SWAN4081'.
     */
    public void setSWAN4081(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan SWAN4081)
    {
        this._SWAN4081 = SWAN4081;
    } //-- void setSWAN4081(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Sets the value of field 'user'.
     * 
     * @param user the value of field 'user'.
     */
    public void setUser(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan user)
    {
        this._user = user;
    } //-- void setUser(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) 

    /**
     * Method unmarshalPhysics
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.Physics unmarshalPhysics(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.Physics) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.Physics.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Physics unmarshalPhysics(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
