/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.model_swan.io.castorgenerated.swivt.types.Textbool;
import org.xml.sax.ContentHandler;

/**
 * Class QUAD.
 * 
 * @version $Revision$ $Date$
 */
public class QUAD implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selected
     */
    private org.openda.model_swan.io.castorgenerated.swivt.types.Textbool _selected;

    /**
     * Field _iquad
     */
    private int _iquad;

    /**
     * keeps track of state for field: _iquad
     */
    private boolean _has_iquad;

    /**
     * Field _lambda
     */
    private java.lang.String _lambda;

    /**
     * Field _cnl4
     */
    private int _cnl4;

    /**
     * keeps track of state for field: _cnl4
     */
    private boolean _has_cnl4;

    /**
     * Field _ursell
     */
    private int _ursell;

    /**
     * keeps track of state for field: _ursell
     */
    private boolean _has_ursell;

    /**
     * Field _qb
     */
    private int _qb;

    /**
     * keeps track of state for field: _qb
     */
    private boolean _has_qb;


      //----------------/
     //- Constructors -/
    //----------------/

    public QUAD() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.QUAD()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'cnl4'.
     * 
     * @return the value of field 'cnl4'.
     */
    public int getCnl4()
    {
        return this._cnl4;
    } //-- int getCnl4() 

    /**
     * Returns the value of field 'iquad'.
     * 
     * @return the value of field 'iquad'.
     */
    public int getIquad()
    {
        return this._iquad;
    } //-- int getIquad() 

    /**
     * Returns the value of field 'lambda'.
     * 
     * @return the value of field 'lambda'.
     */
    public java.lang.String getLambda()
    {
        return this._lambda;
    } //-- java.lang.String getLambda() 

    /**
     * Returns the value of field 'qb'.
     * 
     * @return the value of field 'qb'.
     */
    public int getQb()
    {
        return this._qb;
    } //-- int getQb() 

    /**
     * Returns the value of field 'selected'.
     * 
     * @return the value of field 'selected'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected()
    {
        return this._selected;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected() 

    /**
     * Returns the value of field 'ursell'.
     * 
     * @return the value of field 'ursell'.
     */
    public int getUrsell()
    {
        return this._ursell;
    } //-- int getUrsell() 

    /**
     * Method hasCnl4
     */
    public boolean hasCnl4()
    {
        return this._has_cnl4;
    } //-- boolean hasCnl4() 

    /**
     * Method hasIquad
     */
    public boolean hasIquad()
    {
        return this._has_iquad;
    } //-- boolean hasIquad() 

    /**
     * Method hasQb
     */
    public boolean hasQb()
    {
        return this._has_qb;
    } //-- boolean hasQb() 

    /**
     * Method hasUrsell
     */
    public boolean hasUrsell()
    {
        return this._has_ursell;
    } //-- boolean hasUrsell() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'cnl4'.
     * 
     * @param cnl4 the value of field 'cnl4'.
     */
    public void setCnl4(int cnl4)
    {
        this._cnl4 = cnl4;
        this._has_cnl4 = true;
    } //-- void setCnl4(int) 

    /**
     * Sets the value of field 'iquad'.
     * 
     * @param iquad the value of field 'iquad'.
     */
    public void setIquad(int iquad)
    {
        this._iquad = iquad;
        this._has_iquad = true;
    } //-- void setIquad(int) 

    /**
     * Sets the value of field 'lambda'.
     * 
     * @param lambda the value of field 'lambda'.
     */
    public void setLambda(java.lang.String lambda)
    {
        this._lambda = lambda;
    } //-- void setLambda(java.lang.String) 

    /**
     * Sets the value of field 'qb'.
     * 
     * @param qb the value of field 'qb'.
     */
    public void setQb(int qb)
    {
        this._qb = qb;
        this._has_qb = true;
    } //-- void setQb(int) 

    /**
     * Sets the value of field 'selected'.
     * 
     * @param selected the value of field 'selected'.
     */
    public void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool selected)
    {
        this._selected = selected;
    } //-- void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool) 

    /**
     * Sets the value of field 'ursell'.
     * 
     * @param ursell the value of field 'ursell'.
     */
    public void setUrsell(int ursell)
    {
        this._ursell = ursell;
        this._has_ursell = true;
    } //-- void setUrsell(int) 

    /**
     * Method unmarshalQUAD
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.QUAD unmarshalQUAD(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.QUAD) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.QUAD.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.QUAD unmarshalQUAD(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
