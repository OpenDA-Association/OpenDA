/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.model_swan.io.castorgenerated.swivt.types.Textbool;
import org.xml.sax.ContentHandler;

/**
 * Class NUMREFRL.
 * 
 * @version $Revision$ $Date$
 */
public class NUMREFRL implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selected
     */
    private org.openda.model_swan.io.castorgenerated.swivt.types.Textbool _selected;

    /**
     * Field _frlim
     */
    private java.lang.String _frlim;

    /**
     * Field _power
     */
    private java.lang.String _power;


      //----------------/
     //- Constructors -/
    //----------------/

    public NUMREFRL() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'frlim'.
     * 
     * @return the value of field 'frlim'.
     */
    public java.lang.String getFrlim()
    {
        return this._frlim;
    } //-- java.lang.String getFrlim() 

    /**
     * Returns the value of field 'power'.
     * 
     * @return the value of field 'power'.
     */
    public java.lang.String getPower()
    {
        return this._power;
    } //-- java.lang.String getPower() 

    /**
     * Returns the value of field 'selected'.
     * 
     * @return the value of field 'selected'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected()
    {
        return this._selected;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'frlim'.
     * 
     * @param frlim the value of field 'frlim'.
     */
    public void setFrlim(java.lang.String frlim)
    {
        this._frlim = frlim;
    } //-- void setFrlim(java.lang.String) 

    /**
     * Sets the value of field 'power'.
     * 
     * @param power the value of field 'power'.
     */
    public void setPower(java.lang.String power)
    {
        this._power = power;
    } //-- void setPower(java.lang.String) 

    /**
     * Sets the value of field 'selected'.
     * 
     * @param selected the value of field 'selected'.
     */
    public void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool selected)
    {
        this._selected = selected;
    } //-- void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool) 

    /**
     * Method unmarshalNUMREFRL
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL unmarshalNUMREFRL(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL unmarshalNUMREFRL(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
