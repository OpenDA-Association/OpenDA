/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.model_swan.io.castorgenerated.swivt.types.Textbool;
import org.xml.sax.ContentHandler;

/**
 * Class TRIAD.
 * 
 * @version $Revision$ $Date$
 */
public class TRIAD implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selected
     */
    private org.openda.model_swan.io.castorgenerated.swivt.types.Textbool _selected;

    /**
     * Field _trfac
     */
    private java.lang.String _trfac;

    /**
     * Field _cutfr
     */
    private java.lang.String _cutfr;


      //----------------/
     //- Constructors -/
    //----------------/

    public TRIAD() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.TRIAD()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'cutfr'.
     * 
     * @return the value of field 'cutfr'.
     */
    public java.lang.String getCutfr()
    {
        return this._cutfr;
    } //-- java.lang.String getCutfr() 

    /**
     * Returns the value of field 'selected'.
     * 
     * @return the value of field 'selected'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected()
    {
        return this._selected;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected() 

    /**
     * Returns the value of field 'trfac'.
     * 
     * @return the value of field 'trfac'.
     */
    public java.lang.String getTrfac()
    {
        return this._trfac;
    } //-- java.lang.String getTrfac() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'cutfr'.
     * 
     * @param cutfr the value of field 'cutfr'.
     */
    public void setCutfr(java.lang.String cutfr)
    {
        this._cutfr = cutfr;
    } //-- void setCutfr(java.lang.String) 

    /**
     * Sets the value of field 'selected'.
     * 
     * @param selected the value of field 'selected'.
     */
    public void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool selected)
    {
        this._selected = selected;
    } //-- void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool) 

    /**
     * Sets the value of field 'trfac'.
     * 
     * @param trfac the value of field 'trfac'.
     */
    public void setTrfac(java.lang.String trfac)
    {
        this._trfac = trfac;
    } //-- void setTrfac(java.lang.String) 

    /**
     * Method unmarshalTRIAD
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.TRIAD unmarshalTRIAD(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.TRIAD) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.TRIAD.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.TRIAD unmarshalTRIAD(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
