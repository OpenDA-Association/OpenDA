/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class Swivt.
 * 
 * @version $Revision$ $Date$
 */
public class Swivt implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _case
     */
    private org.openda.model_swan.io.castorgenerated.swivt.Case _case;


      //----------------/
     //- Constructors -/
    //----------------/

    public Swivt() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Swivt()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'case'.
     * 
     * @return the value of field 'case'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.Case getCase()
    {
        return this._case;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Case getCase() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'case'.
     * 
     * @param _case
     * @param case the value of field 'case'.
     */
    public void setCase(org.openda.model_swan.io.castorgenerated.swivt.Case _case)
    {
        this._case = _case;
    } //-- void setCase(org.openda.model_swan.io.castorgenerated.swivt.Case) 

    /**
     * Method unmarshalSwivt
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.Swivt unmarshalSwivt(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.Swivt) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.Swivt.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Swivt unmarshalSwivt(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
