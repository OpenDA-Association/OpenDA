/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class Case.
 * 
 * @version $Revision$ $Date$
 */
public class Case implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _code
     */
    private java.lang.String _code;

    /**
     * Field _settings
     */
    private org.openda.model_swan.io.castorgenerated.swivt.Settings _settings;


      //----------------/
     //- Constructors -/
    //----------------/

    public Case() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Case()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'code'.
     * 
     * @return the value of field 'code'.
     */
    public java.lang.String getCode()
    {
        return this._code;
    } //-- java.lang.String getCode() 

    /**
     * Returns the value of field 'settings'.
     * 
     * @return the value of field 'settings'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.Settings getSettings()
    {
        return this._settings;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Settings getSettings() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'code'.
     * 
     * @param code the value of field 'code'.
     */
    public void setCode(java.lang.String code)
    {
        this._code = code;
    } //-- void setCode(java.lang.String) 

    /**
     * Sets the value of field 'settings'.
     * 
     * @param settings the value of field 'settings'.
     */
    public void setSettings(org.openda.model_swan.io.castorgenerated.swivt.Settings settings)
    {
        this._settings = settings;
    } //-- void setSettings(org.openda.model_swan.io.castorgenerated.swivt.Settings) 

    /**
     * Method unmarshalCase
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.Case unmarshalCase(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.Case) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.Case.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Case unmarshalCase(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
