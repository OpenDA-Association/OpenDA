/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.model_swan.io.castorgenerated.swivt.types.Textbool;
import org.xml.sax.ContentHandler;

/**
 * Class WCAP1.
 * 
 * @version $Revision$ $Date$
 */
public class WCAP1 implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selected
     */
    private org.openda.model_swan.io.castorgenerated.swivt.types.Textbool _selected;

    /**
     * Field _cds2
     */
    private java.lang.String _cds2;

    /**
     * Field _br
     */
    private java.lang.String _br;

    /**
     * Field _p0
     */
    private java.lang.String _p0;

    /**
     * Field _powst
     */
    private java.lang.String _powst;

    /**
     * Field _powk
     */
    private java.lang.String _powk;

    /**
     * Field _nldisp
     */
    private int _nldisp;

    /**
     * keeps track of state for field: _nldisp
     */
    private boolean _has_nldisp;

    /**
     * Field _cds3
     */
    private java.lang.String _cds3;

    /**
     * Field _powfsh
     */
    private java.lang.String _powfsh;


      //----------------/
     //- Constructors -/
    //----------------/

    public WCAP1() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.WCAP1()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'br'.
     * 
     * @return the value of field 'br'.
     */
    public java.lang.String getBr()
    {
        return this._br;
    } //-- java.lang.String getBr() 

    /**
     * Returns the value of field 'cds2'.
     * 
     * @return the value of field 'cds2'.
     */
    public java.lang.String getCds2()
    {
        return this._cds2;
    } //-- java.lang.String getCds2() 

    /**
     * Returns the value of field 'cds3'.
     * 
     * @return the value of field 'cds3'.
     */
    public java.lang.String getCds3()
    {
        return this._cds3;
    } //-- java.lang.String getCds3() 

    /**
     * Returns the value of field 'nldisp'.
     * 
     * @return the value of field 'nldisp'.
     */
    public int getNldisp()
    {
        return this._nldisp;
    } //-- int getNldisp() 

    /**
     * Returns the value of field 'p0'.
     * 
     * @return the value of field 'p0'.
     */
    public java.lang.String getP0()
    {
        return this._p0;
    } //-- java.lang.String getP0() 

    /**
     * Returns the value of field 'powfsh'.
     * 
     * @return the value of field 'powfsh'.
     */
    public java.lang.String getPowfsh()
    {
        return this._powfsh;
    } //-- java.lang.String getPowfsh() 

    /**
     * Returns the value of field 'powk'.
     * 
     * @return the value of field 'powk'.
     */
    public java.lang.String getPowk()
    {
        return this._powk;
    } //-- java.lang.String getPowk() 

    /**
     * Returns the value of field 'powst'.
     * 
     * @return the value of field 'powst'.
     */
    public java.lang.String getPowst()
    {
        return this._powst;
    } //-- java.lang.String getPowst() 

    /**
     * Returns the value of field 'selected'.
     * 
     * @return the value of field 'selected'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected()
    {
        return this._selected;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected() 

    /**
     * Method hasNldisp
     */
    public boolean hasNldisp()
    {
        return this._has_nldisp;
    } //-- boolean hasNldisp() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'br'.
     * 
     * @param br the value of field 'br'.
     */
    public void setBr(java.lang.String br)
    {
        this._br = br;
    } //-- void setBr(java.lang.String) 

    /**
     * Sets the value of field 'cds2'.
     * 
     * @param cds2 the value of field 'cds2'.
     */
    public void setCds2(java.lang.String cds2)
    {
        this._cds2 = cds2;
    } //-- void setCds2(java.lang.String) 

    /**
     * Sets the value of field 'cds3'.
     * 
     * @param cds3 the value of field 'cds3'.
     */
    public void setCds3(java.lang.String cds3)
    {
        this._cds3 = cds3;
    } //-- void setCds3(java.lang.String) 

    /**
     * Sets the value of field 'nldisp'.
     * 
     * @param nldisp the value of field 'nldisp'.
     */
    public void setNldisp(int nldisp)
    {
        this._nldisp = nldisp;
        this._has_nldisp = true;
    } //-- void setNldisp(int) 

    /**
     * Sets the value of field 'p0'.
     * 
     * @param p0 the value of field 'p0'.
     */
    public void setP0(java.lang.String p0)
    {
        this._p0 = p0;
    } //-- void setP0(java.lang.String) 

    /**
     * Sets the value of field 'powfsh'.
     * 
     * @param powfsh the value of field 'powfsh'.
     */
    public void setPowfsh(java.lang.String powfsh)
    {
        this._powfsh = powfsh;
    } //-- void setPowfsh(java.lang.String) 

    /**
     * Sets the value of field 'powk'.
     * 
     * @param powk the value of field 'powk'.
     */
    public void setPowk(java.lang.String powk)
    {
        this._powk = powk;
    } //-- void setPowk(java.lang.String) 

    /**
     * Sets the value of field 'powst'.
     * 
     * @param powst the value of field 'powst'.
     */
    public void setPowst(java.lang.String powst)
    {
        this._powst = powst;
    } //-- void setPowst(java.lang.String) 

    /**
     * Sets the value of field 'selected'.
     * 
     * @param selected the value of field 'selected'.
     */
    public void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool selected)
    {
        this._selected = selected;
    } //-- void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool) 

    /**
     * Method unmarshalWCAP1
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.WCAP1 unmarshalWCAP1(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.WCAP1) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.WCAP1.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.WCAP1 unmarshalWCAP1(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
