/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.model_swan.io.castorgenerated.swivt.types.Textbool;
import org.xml.sax.ContentHandler;

/**
 * Class NUM.
 * 
 * @version $Revision$ $Date$
 */
public class NUM implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selected
     */
    private org.openda.model_swan.io.castorgenerated.swivt.types.Textbool _selected;

    /**
     * Field _dabs
     */
    private java.lang.String _dabs;

    /**
     * Field _drel
     */
    private java.lang.String _drel;

    /**
     * Field _curvat
     */
    private java.lang.String _curvat;

    /**
     * Field _npnts
     */
    private java.lang.String _npnts;

    /**
     * Field _mxitst
     */
    private int _mxitst;

    /**
     * keeps track of state for field: _mxitst
     */
    private boolean _has_mxitst;


      //----------------/
     //- Constructors -/
    //----------------/

    public NUM() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.NUM()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'curvat'.
     * 
     * @return the value of field 'curvat'.
     */
    public java.lang.String getCurvat()
    {
        return this._curvat;
    } //-- java.lang.String getCurvat() 

    /**
     * Returns the value of field 'dabs'.
     * 
     * @return the value of field 'dabs'.
     */
    public java.lang.String getDabs()
    {
        return this._dabs;
    } //-- java.lang.String getDabs() 

    /**
     * Returns the value of field 'drel'.
     * 
     * @return the value of field 'drel'.
     */
    public java.lang.String getDrel()
    {
        return this._drel;
    } //-- java.lang.String getDrel() 

    /**
     * Returns the value of field 'mxitst'.
     * 
     * @return the value of field 'mxitst'.
     */
    public int getMxitst()
    {
        return this._mxitst;
    } //-- int getMxitst() 

    /**
     * Returns the value of field 'npnts'.
     * 
     * @return the value of field 'npnts'.
     */
    public java.lang.String getNpnts()
    {
        return this._npnts;
    } //-- java.lang.String getNpnts() 

    /**
     * Returns the value of field 'selected'.
     * 
     * @return the value of field 'selected'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected()
    {
        return this._selected;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected() 

    /**
     * Method hasMxitst
     */
    public boolean hasMxitst()
    {
        return this._has_mxitst;
    } //-- boolean hasMxitst() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'curvat'.
     * 
     * @param curvat the value of field 'curvat'.
     */
    public void setCurvat(java.lang.String curvat)
    {
        this._curvat = curvat;
    } //-- void setCurvat(java.lang.String) 

    /**
     * Sets the value of field 'dabs'.
     * 
     * @param dabs the value of field 'dabs'.
     */
    public void setDabs(java.lang.String dabs)
    {
        this._dabs = dabs;
    } //-- void setDabs(java.lang.String) 

    /**
     * Sets the value of field 'drel'.
     * 
     * @param drel the value of field 'drel'.
     */
    public void setDrel(java.lang.String drel)
    {
        this._drel = drel;
    } //-- void setDrel(java.lang.String) 

    /**
     * Sets the value of field 'mxitst'.
     * 
     * @param mxitst the value of field 'mxitst'.
     */
    public void setMxitst(int mxitst)
    {
        this._mxitst = mxitst;
        this._has_mxitst = true;
    } //-- void setMxitst(int) 

    /**
     * Sets the value of field 'npnts'.
     * 
     * @param npnts the value of field 'npnts'.
     */
    public void setNpnts(java.lang.String npnts)
    {
        this._npnts = npnts;
    } //-- void setNpnts(java.lang.String) 

    /**
     * Sets the value of field 'selected'.
     * 
     * @param selected the value of field 'selected'.
     */
    public void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool selected)
    {
        this._selected = selected;
    } //-- void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool) 

    /**
     * Method unmarshalNUM
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.NUM unmarshalNUM(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.NUM) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.NUM.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.NUM unmarshalNUM(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
