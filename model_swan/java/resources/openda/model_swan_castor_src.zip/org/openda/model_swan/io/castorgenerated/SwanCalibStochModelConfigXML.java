/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class SwanCalibStochModelConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class SwanCalibStochModelConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the information about the model wrapper class name,
     * working directory containing all model related files to be
     * cloned, and input arguments to the model wrapper object.
     */
    private org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML _model;

    /**
     * Specify the openda:class of the uncertainty module, its
     * working directory containing configuration file, and
     * argument to the openda:class (configuration file name).
     */
    private org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML _uncertaintyModule;


      //----------------/
     //- Constructors -/
    //----------------/

    public SwanCalibStochModelConfigXML() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.SwanCalibStochModelConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'model'. The field 'model' has
     * the following description: Specify the information about the
     * model wrapper class name, working directory containing all
     * model related files to be cloned, and input arguments to the
     * model wrapper object.
     * 
     * @return the value of field 'model'.
     */
    public org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML getModel()
    {
        return this._model;
    } //-- org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML getModel() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: Specify
     * the openda:class of the uncertainty module, its working
     * directory containing configuration file, and argument to the
     * openda:class (configuration file name).
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML getUncertaintyModule() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'model'. The field 'model' has the
     * following description: Specify the information about the
     * model wrapper class name, working directory containing all
     * model related files to be cloned, and input arguments to the
     * model wrapper object.
     * 
     * @param model the value of field 'model'.
     */
    public void setModel(org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML model)
    {
        this._model = model;
    } //-- void setModel(org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: Specify
     * the openda:class of the uncertainty module, its working
     * directory containing configuration file, and argument to the
     * openda:class (configuration file name).
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(org.openda.model_swan.io.castorgenerated.SwanCalibComponentXML) 

    /**
     * Method unmarshalSwanCalibStochModelConfigXML
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.SwanCalibStochModelConfigXML unmarshalSwanCalibStochModelConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.SwanCalibStochModelConfigXML) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.SwanCalibStochModelConfigXML.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.SwanCalibStochModelConfigXML unmarshalSwanCalibStochModelConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
