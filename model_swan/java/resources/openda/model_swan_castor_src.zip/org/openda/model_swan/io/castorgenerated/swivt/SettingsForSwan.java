/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class SettingsForSwan.
 * 
 * @version $Revision$ $Date$
 */
public class SettingsForSwan implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _GEN3
     */
    private org.openda.model_swan.io.castorgenerated.swivt.GEN3 _GEN3;

    /**
     * Field _WCAP
     */
    private org.openda.model_swan.io.castorgenerated.swivt.WCAP _WCAP;

    /**
     * Field _WCAP1
     */
    private org.openda.model_swan.io.castorgenerated.swivt.WCAP1 _WCAP1;

    /**
     * Field _QUAD
     */
    private org.openda.model_swan.io.castorgenerated.swivt.QUAD _QUAD;

    /**
     * Field _FRIC
     */
    private org.openda.model_swan.io.castorgenerated.swivt.FRIC _FRIC;

    /**
     * Field _BREA
     */
    private org.openda.model_swan.io.castorgenerated.swivt.BREA _BREA;

    /**
     * Field _BREA1
     */
    private org.openda.model_swan.io.castorgenerated.swivt.BREA1 _BREA1;

    /**
     * Field _TRIAD
     */
    private org.openda.model_swan.io.castorgenerated.swivt.TRIAD _TRIAD;

    /**
     * Field _NUMREFRL
     */
    private org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL _NUMREFRL;


      //----------------/
     //- Constructors -/
    //----------------/

    public SettingsForSwan() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'BREA'.
     * 
     * @return the value of field 'BREA'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.BREA getBREA()
    {
        return this._BREA;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.BREA getBREA() 

    /**
     * Returns the value of field 'BREA1'.
     * 
     * @return the value of field 'BREA1'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.BREA1 getBREA1()
    {
        return this._BREA1;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.BREA1 getBREA1() 

    /**
     * Returns the value of field 'FRIC'.
     * 
     * @return the value of field 'FRIC'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.FRIC getFRIC()
    {
        return this._FRIC;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.FRIC getFRIC() 

    /**
     * Returns the value of field 'GEN3'.
     * 
     * @return the value of field 'GEN3'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.GEN3 getGEN3()
    {
        return this._GEN3;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.GEN3 getGEN3() 

    /**
     * Returns the value of field 'NUMREFRL'.
     * 
     * @return the value of field 'NUMREFRL'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL getNUMREFRL()
    {
        return this._NUMREFRL;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL getNUMREFRL() 

    /**
     * Returns the value of field 'QUAD'.
     * 
     * @return the value of field 'QUAD'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.QUAD getQUAD()
    {
        return this._QUAD;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.QUAD getQUAD() 

    /**
     * Returns the value of field 'TRIAD'.
     * 
     * @return the value of field 'TRIAD'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.TRIAD getTRIAD()
    {
        return this._TRIAD;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.TRIAD getTRIAD() 

    /**
     * Returns the value of field 'WCAP'.
     * 
     * @return the value of field 'WCAP'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.WCAP getWCAP()
    {
        return this._WCAP;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.WCAP getWCAP() 

    /**
     * Returns the value of field 'WCAP1'.
     * 
     * @return the value of field 'WCAP1'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.WCAP1 getWCAP1()
    {
        return this._WCAP1;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.WCAP1 getWCAP1() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'BREA'.
     * 
     * @param BREA the value of field 'BREA'.
     */
    public void setBREA(org.openda.model_swan.io.castorgenerated.swivt.BREA BREA)
    {
        this._BREA = BREA;
    } //-- void setBREA(org.openda.model_swan.io.castorgenerated.swivt.BREA) 

    /**
     * Sets the value of field 'BREA1'.
     * 
     * @param BREA1 the value of field 'BREA1'.
     */
    public void setBREA1(org.openda.model_swan.io.castorgenerated.swivt.BREA1 BREA1)
    {
        this._BREA1 = BREA1;
    } //-- void setBREA1(org.openda.model_swan.io.castorgenerated.swivt.BREA1) 

    /**
     * Sets the value of field 'FRIC'.
     * 
     * @param FRIC the value of field 'FRIC'.
     */
    public void setFRIC(org.openda.model_swan.io.castorgenerated.swivt.FRIC FRIC)
    {
        this._FRIC = FRIC;
    } //-- void setFRIC(org.openda.model_swan.io.castorgenerated.swivt.FRIC) 

    /**
     * Sets the value of field 'GEN3'.
     * 
     * @param GEN3 the value of field 'GEN3'.
     */
    public void setGEN3(org.openda.model_swan.io.castorgenerated.swivt.GEN3 GEN3)
    {
        this._GEN3 = GEN3;
    } //-- void setGEN3(org.openda.model_swan.io.castorgenerated.swivt.GEN3) 

    /**
     * Sets the value of field 'NUMREFRL'.
     * 
     * @param NUMREFRL the value of field 'NUMREFRL'.
     */
    public void setNUMREFRL(org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL NUMREFRL)
    {
        this._NUMREFRL = NUMREFRL;
    } //-- void setNUMREFRL(org.openda.model_swan.io.castorgenerated.swivt.NUMREFRL) 

    /**
     * Sets the value of field 'QUAD'.
     * 
     * @param QUAD the value of field 'QUAD'.
     */
    public void setQUAD(org.openda.model_swan.io.castorgenerated.swivt.QUAD QUAD)
    {
        this._QUAD = QUAD;
    } //-- void setQUAD(org.openda.model_swan.io.castorgenerated.swivt.QUAD) 

    /**
     * Sets the value of field 'TRIAD'.
     * 
     * @param TRIAD the value of field 'TRIAD'.
     */
    public void setTRIAD(org.openda.model_swan.io.castorgenerated.swivt.TRIAD TRIAD)
    {
        this._TRIAD = TRIAD;
    } //-- void setTRIAD(org.openda.model_swan.io.castorgenerated.swivt.TRIAD) 

    /**
     * Sets the value of field 'WCAP'.
     * 
     * @param WCAP the value of field 'WCAP'.
     */
    public void setWCAP(org.openda.model_swan.io.castorgenerated.swivt.WCAP WCAP)
    {
        this._WCAP = WCAP;
    } //-- void setWCAP(org.openda.model_swan.io.castorgenerated.swivt.WCAP) 

    /**
     * Sets the value of field 'WCAP1'.
     * 
     * @param WCAP1 the value of field 'WCAP1'.
     */
    public void setWCAP1(org.openda.model_swan.io.castorgenerated.swivt.WCAP1 WCAP1)
    {
        this._WCAP1 = WCAP1;
    } //-- void setWCAP1(org.openda.model_swan.io.castorgenerated.swivt.WCAP1) 

    /**
     * Method unmarshalSettingsForSwan
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan unmarshalSettingsForSwan(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.SettingsForSwan unmarshalSettingsForSwan(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
