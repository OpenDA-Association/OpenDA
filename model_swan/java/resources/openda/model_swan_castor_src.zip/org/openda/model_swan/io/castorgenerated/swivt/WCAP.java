/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.model_swan.io.castorgenerated.swivt.types.Textbool;
import org.xml.sax.ContentHandler;

/**
 * Class WCAP.
 * 
 * @version $Revision$ $Date$
 */
public class WCAP implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _selected
     */
    private org.openda.model_swan.io.castorgenerated.swivt.types.Textbool _selected;

    /**
     * Field _cds2
     */
    private java.lang.String _cds2;

    /**
     * Field _stpm
     */
    private java.lang.String _stpm;

    /**
     * Field _powst
     */
    private int _powst;

    /**
     * keeps track of state for field: _powst
     */
    private boolean _has_powst;

    /**
     * Field _delta
     */
    private int _delta;

    /**
     * keeps track of state for field: _delta
     */
    private boolean _has_delta;

    /**
     * Field _powk
     */
    private int _powk;

    /**
     * keeps track of state for field: _powk
     */
    private boolean _has_powk;


      //----------------/
     //- Constructors -/
    //----------------/

    public WCAP() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.WCAP()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'cds2'.
     * 
     * @return the value of field 'cds2'.
     */
    public java.lang.String getCds2()
    {
        return this._cds2;
    } //-- java.lang.String getCds2() 

    /**
     * Returns the value of field 'delta'.
     * 
     * @return the value of field 'delta'.
     */
    public int getDelta()
    {
        return this._delta;
    } //-- int getDelta() 

    /**
     * Returns the value of field 'powk'.
     * 
     * @return the value of field 'powk'.
     */
    public int getPowk()
    {
        return this._powk;
    } //-- int getPowk() 

    /**
     * Returns the value of field 'powst'.
     * 
     * @return the value of field 'powst'.
     */
    public int getPowst()
    {
        return this._powst;
    } //-- int getPowst() 

    /**
     * Returns the value of field 'selected'.
     * 
     * @return the value of field 'selected'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected()
    {
        return this._selected;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.types.Textbool getSelected() 

    /**
     * Returns the value of field 'stpm'.
     * 
     * @return the value of field 'stpm'.
     */
    public java.lang.String getStpm()
    {
        return this._stpm;
    } //-- java.lang.String getStpm() 

    /**
     * Method hasDelta
     */
    public boolean hasDelta()
    {
        return this._has_delta;
    } //-- boolean hasDelta() 

    /**
     * Method hasPowk
     */
    public boolean hasPowk()
    {
        return this._has_powk;
    } //-- boolean hasPowk() 

    /**
     * Method hasPowst
     */
    public boolean hasPowst()
    {
        return this._has_powst;
    } //-- boolean hasPowst() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'cds2'.
     * 
     * @param cds2 the value of field 'cds2'.
     */
    public void setCds2(java.lang.String cds2)
    {
        this._cds2 = cds2;
    } //-- void setCds2(java.lang.String) 

    /**
     * Sets the value of field 'delta'.
     * 
     * @param delta the value of field 'delta'.
     */
    public void setDelta(int delta)
    {
        this._delta = delta;
        this._has_delta = true;
    } //-- void setDelta(int) 

    /**
     * Sets the value of field 'powk'.
     * 
     * @param powk the value of field 'powk'.
     */
    public void setPowk(int powk)
    {
        this._powk = powk;
        this._has_powk = true;
    } //-- void setPowk(int) 

    /**
     * Sets the value of field 'powst'.
     * 
     * @param powst the value of field 'powst'.
     */
    public void setPowst(int powst)
    {
        this._powst = powst;
        this._has_powst = true;
    } //-- void setPowst(int) 

    /**
     * Sets the value of field 'selected'.
     * 
     * @param selected the value of field 'selected'.
     */
    public void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool selected)
    {
        this._selected = selected;
    } //-- void setSelected(org.openda.model_swan.io.castorgenerated.swivt.types.Textbool) 

    /**
     * Sets the value of field 'stpm'.
     * 
     * @param stpm the value of field 'stpm'.
     */
    public void setStpm(java.lang.String stpm)
    {
        this._stpm = stpm;
    } //-- void setStpm(java.lang.String) 

    /**
     * Method unmarshalWCAP
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.WCAP unmarshalWCAP(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.WCAP) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.WCAP.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.WCAP unmarshalWCAP(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
