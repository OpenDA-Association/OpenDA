/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated.swivt;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class Settings.
 * 
 * @version $Revision$ $Date$
 */
public class Settings implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _physics
     */
    private org.openda.model_swan.io.castorgenerated.swivt.Physics _physics;

    /**
     * Field _numerics
     */
    private org.openda.model_swan.io.castorgenerated.swivt.Numerics _numerics;


      //----------------/
     //- Constructors -/
    //----------------/

    public Settings() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Settings()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'numerics'.
     * 
     * @return the value of field 'numerics'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.Numerics getNumerics()
    {
        return this._numerics;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Numerics getNumerics() 

    /**
     * Returns the value of field 'physics'.
     * 
     * @return the value of field 'physics'.
     */
    public org.openda.model_swan.io.castorgenerated.swivt.Physics getPhysics()
    {
        return this._physics;
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Physics getPhysics() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'numerics'.
     * 
     * @param numerics the value of field 'numerics'.
     */
    public void setNumerics(org.openda.model_swan.io.castorgenerated.swivt.Numerics numerics)
    {
        this._numerics = numerics;
    } //-- void setNumerics(org.openda.model_swan.io.castorgenerated.swivt.Numerics) 

    /**
     * Sets the value of field 'physics'.
     * 
     * @param physics the value of field 'physics'.
     */
    public void setPhysics(org.openda.model_swan.io.castorgenerated.swivt.Physics physics)
    {
        this._physics = physics;
    } //-- void setPhysics(org.openda.model_swan.io.castorgenerated.swivt.Physics) 

    /**
     * Method unmarshalSettings
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.swivt.Settings unmarshalSettings(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.swivt.Settings) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.swivt.Settings.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.swivt.Settings unmarshalSettings(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
