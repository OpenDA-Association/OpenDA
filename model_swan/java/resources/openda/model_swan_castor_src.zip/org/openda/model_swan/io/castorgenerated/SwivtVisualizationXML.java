/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class SwivtVisualizationXML.
 * 
 * @version $Revision$ $Date$
 */
public class SwivtVisualizationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify whether this swivt presentation setting is active.
     */
    private boolean _isActive = true;

    /**
     * keeps track of state for field: _isActive
     */
    private boolean _has_isActive;

    /**
     * visualization executable
     */
    private java.lang.String _executable;

    /**
     * Directory where per instance a subdirectory is created that
     * will contain the figures (default instanceDir/../figures).
     * If omitted, the files are placed in "modelDirectory", the
     * directory where the model results are. 
     */
    private java.lang.String _outputDirectoryParent;

    /**
     * visualization visualizationFiles
     */
    private org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML _visualizationFiles;


      //----------------/
     //- Constructors -/
    //----------------/

    public SwivtVisualizationXML() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.SwivtVisualizationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteIsActive
     */
    public void deleteIsActive()
    {
        this._has_isActive= false;
    } //-- void deleteIsActive() 

    /**
     * Returns the value of field 'executable'. The field
     * 'executable' has the following description: visualization
     * executable
     * 
     * @return the value of field 'executable'.
     */
    public java.lang.String getExecutable()
    {
        return this._executable;
    } //-- java.lang.String getExecutable() 

    /**
     * Returns the value of field 'isActive'. The field 'isActive'
     * has the following description: Specify whether this swivt
     * presentation setting is active.
     * 
     * @return the value of field 'isActive'.
     */
    public boolean getIsActive()
    {
        return this._isActive;
    } //-- boolean getIsActive() 

    /**
     * Returns the value of field 'outputDirectoryParent'. The
     * field 'outputDirectoryParent' has the following description:
     * Directory where per instance a subdirectory is created that
     * will contain the figures (default instanceDir/../figures).
     * If omitted, the files are placed in "modelDirectory", the
     * directory where the model results are. 
     * 
     * @return the value of field 'outputDirectoryParent'.
     */
    public java.lang.String getOutputDirectoryParent()
    {
        return this._outputDirectoryParent;
    } //-- java.lang.String getOutputDirectoryParent() 

    /**
     * Returns the value of field 'visualizationFiles'. The field
     * 'visualizationFiles' has the following description:
     * visualization visualizationFiles
     * 
     * @return the value of field 'visualizationFiles'.
     */
    public org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML getVisualizationFiles()
    {
        return this._visualizationFiles;
    } //-- org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML getVisualizationFiles() 

    /**
     * Method hasIsActive
     */
    public boolean hasIsActive()
    {
        return this._has_isActive;
    } //-- boolean hasIsActive() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'executable'. The field 'executable'
     * has the following description: visualization executable
     * 
     * @param executable the value of field 'executable'.
     */
    public void setExecutable(java.lang.String executable)
    {
        this._executable = executable;
    } //-- void setExecutable(java.lang.String) 

    /**
     * Sets the value of field 'isActive'. The field 'isActive' has
     * the following description: Specify whether this swivt
     * presentation setting is active.
     * 
     * @param isActive the value of field 'isActive'.
     */
    public void setIsActive(boolean isActive)
    {
        this._isActive = isActive;
        this._has_isActive = true;
    } //-- void setIsActive(boolean) 

    /**
     * Sets the value of field 'outputDirectoryParent'. The field
     * 'outputDirectoryParent' has the following description:
     * Directory where per instance a subdirectory is created that
     * will contain the figures (default instanceDir/../figures).
     * If omitted, the files are placed in "modelDirectory", the
     * directory where the model results are. 
     * 
     * @param outputDirectoryParent the value of field
     * 'outputDirectoryParent'.
     */
    public void setOutputDirectoryParent(java.lang.String outputDirectoryParent)
    {
        this._outputDirectoryParent = outputDirectoryParent;
    } //-- void setOutputDirectoryParent(java.lang.String) 

    /**
     * Sets the value of field 'visualizationFiles'. The field
     * 'visualizationFiles' has the following description:
     * visualization visualizationFiles
     * 
     * @param visualizationFiles the value of field
     * 'visualizationFiles'.
     */
    public void setVisualizationFiles(org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML visualizationFiles)
    {
        this._visualizationFiles = visualizationFiles;
    } //-- void setVisualizationFiles(org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML) 

    /**
     * Method unmarshalSwivtVisualizationXML
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.SwivtVisualizationXML unmarshalSwivtVisualizationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.SwivtVisualizationXML) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.SwivtVisualizationXML.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.SwivtVisualizationXML unmarshalSwivtVisualizationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
