/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_swan.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class SwivtVisualizationFilesXML.
 * 
 * @version $Revision$ $Date$
 */
public class SwivtVisualizationFilesXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * directory containing the observations
     */
    private java.lang.String _observationDirectory;

    /**
     * directory containing the model results (should be ommited,
     * in which case default, the instance directory, is taken)
     */
    private java.lang.String _modelDirectory;

    /**
     * directory containing the *.mat file(s) with visualization
     * settings
     */
    private java.lang.String _presentationSettingsDirectory;


      //----------------/
     //- Constructors -/
    //----------------/

    public SwivtVisualizationFilesXML() {
        super();
    } //-- org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'modelDirectory'. The field
     * 'modelDirectory' has the following description: directory
     * containing the model results (should be ommited, in which
     * case default, the instance directory, is taken)
     * 
     * @return the value of field 'modelDirectory'.
     */
    public java.lang.String getModelDirectory()
    {
        return this._modelDirectory;
    } //-- java.lang.String getModelDirectory() 

    /**
     * Returns the value of field 'observationDirectory'. The field
     * 'observationDirectory' has the following description:
     * directory containing the observations
     * 
     * @return the value of field 'observationDirectory'.
     */
    public java.lang.String getObservationDirectory()
    {
        return this._observationDirectory;
    } //-- java.lang.String getObservationDirectory() 

    /**
     * Returns the value of field 'presentationSettingsDirectory'.
     * The field 'presentationSettingsDirectory' has the following
     * description: directory containing the *.mat file(s) with
     * visualization settings
     * 
     * @return the value of field 'presentationSettingsDirectory'.
     */
    public java.lang.String getPresentationSettingsDirectory()
    {
        return this._presentationSettingsDirectory;
    } //-- java.lang.String getPresentationSettingsDirectory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'modelDirectory'. The field
     * 'modelDirectory' has the following description: directory
     * containing the model results (should be ommited, in which
     * case default, the instance directory, is taken)
     * 
     * @param modelDirectory the value of field 'modelDirectory'.
     */
    public void setModelDirectory(java.lang.String modelDirectory)
    {
        this._modelDirectory = modelDirectory;
    } //-- void setModelDirectory(java.lang.String) 

    /**
     * Sets the value of field 'observationDirectory'. The field
     * 'observationDirectory' has the following description:
     * directory containing the observations
     * 
     * @param observationDirectory the value of field
     * 'observationDirectory'.
     */
    public void setObservationDirectory(java.lang.String observationDirectory)
    {
        this._observationDirectory = observationDirectory;
    } //-- void setObservationDirectory(java.lang.String) 

    /**
     * Sets the value of field 'presentationSettingsDirectory'. The
     * field 'presentationSettingsDirectory' has the following
     * description: directory containing the *.mat file(s) with
     * visualization settings
     * 
     * @param presentationSettingsDirectory the value of field
     * 'presentationSettingsDirectory'.
     */
    public void setPresentationSettingsDirectory(java.lang.String presentationSettingsDirectory)
    {
        this._presentationSettingsDirectory = presentationSettingsDirectory;
    } //-- void setPresentationSettingsDirectory(java.lang.String) 

    /**
     * Method unmarshalSwivtVisualizationFilesXML
     * 
     * @param reader
     */
    public static org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML unmarshalSwivtVisualizationFilesXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML) Unmarshaller.unmarshal(org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML.class, reader);
    } //-- org.openda.model_swan.io.castorgenerated.SwivtVisualizationFilesXML unmarshalSwivtVisualizationFilesXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
