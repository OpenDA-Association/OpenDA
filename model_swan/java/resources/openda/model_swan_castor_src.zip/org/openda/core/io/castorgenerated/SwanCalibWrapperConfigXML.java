/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class SwanCalibWrapperConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class SwanCalibWrapperConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The executable to be run, and its arguments
     */
    private org.openda.core.io.castorgenerated.ActionXML _swanAction;

    /**
     * Configuration file containing SWIVT parameters.
     */
    private java.lang.String _swivtParameters;

    /**
     * Additional parameters not defined in swift xml file.
     */
    private java.lang.String _nonSwivtParameters;

    /**
     */
    private java.lang.String _swanInputTemplate;

    /**
     * Actual SWAN input file.
     */
    private java.lang.String _actualSwanInput;

    /**
     * File containing the coordinates of observation locations.
     */
    private java.lang.String _observationLocations;

    /**
     */
    private java.lang.String _swanResults;

    /**
     * File that contains wind interpolation table data.
     */
    private java.lang.String _windInterpolationTable;

    /**
     * File that contains validation rules for perturbed values.
     */
    private java.lang.String _perturbedValuesValidation;

    /**
     * The cleanup action to be performed after the executable has
     * run 
     */
    private org.openda.core.io.castorgenerated.ActionXML _cleanupAction;


      //----------------/
     //- Constructors -/
    //----------------/

    public SwanCalibWrapperConfigXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.SwanCalibWrapperConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'actualSwanInput'. The field
     * 'actualSwanInput' has the following description: Actual SWAN
     * input file.
     * 
     * @return the value of field 'actualSwanInput'.
     */
    public java.lang.String getActualSwanInput()
    {
        return this._actualSwanInput;
    } //-- java.lang.String getActualSwanInput() 

    /**
     * Returns the value of field 'cleanupAction'. The field
     * 'cleanupAction' has the following description: The cleanup
     * action to be performed after the executable has run 
     * 
     * @return the value of field 'cleanupAction'.
     */
    public org.openda.core.io.castorgenerated.ActionXML getCleanupAction()
    {
        return this._cleanupAction;
    } //-- org.openda.core.io.castorgenerated.ActionXML getCleanupAction() 

    /**
     * Returns the value of field 'nonSwivtParameters'. The field
     * 'nonSwivtParameters' has the following description:
     * Additional parameters not defined in swift xml file.
     * 
     * @return the value of field 'nonSwivtParameters'.
     */
    public java.lang.String getNonSwivtParameters()
    {
        return this._nonSwivtParameters;
    } //-- java.lang.String getNonSwivtParameters() 

    /**
     * Returns the value of field 'observationLocations'. The field
     * 'observationLocations' has the following description: File
     * containing the coordinates of observation locations.
     * 
     * @return the value of field 'observationLocations'.
     */
    public java.lang.String getObservationLocations()
    {
        return this._observationLocations;
    } //-- java.lang.String getObservationLocations() 

    /**
     * Returns the value of field 'perturbedValuesValidation'. The
     * field 'perturbedValuesValidation' has the following
     * description: File that contains validation rules for
     * perturbed values.
     * 
     * @return the value of field 'perturbedValuesValidation'.
     */
    public java.lang.String getPerturbedValuesValidation()
    {
        return this._perturbedValuesValidation;
    } //-- java.lang.String getPerturbedValuesValidation() 

    /**
     * Returns the value of field 'swanAction'. The field
     * 'swanAction' has the following description: The executable
     * to be run, and its arguments
     * 
     * @return the value of field 'swanAction'.
     */
    public org.openda.core.io.castorgenerated.ActionXML getSwanAction()
    {
        return this._swanAction;
    } //-- org.openda.core.io.castorgenerated.ActionXML getSwanAction() 

    /**
     * Returns the value of field 'swanInputTemplate'.
     * 
     * @return the value of field 'swanInputTemplate'.
     */
    public java.lang.String getSwanInputTemplate()
    {
        return this._swanInputTemplate;
    } //-- java.lang.String getSwanInputTemplate() 

    /**
     * Returns the value of field 'swanResults'.
     * 
     * @return the value of field 'swanResults'.
     */
    public java.lang.String getSwanResults()
    {
        return this._swanResults;
    } //-- java.lang.String getSwanResults() 

    /**
     * Returns the value of field 'swivtParameters'. The field
     * 'swivtParameters' has the following description:
     * Configuration file containing SWIVT parameters.
     * 
     * @return the value of field 'swivtParameters'.
     */
    public java.lang.String getSwivtParameters()
    {
        return this._swivtParameters;
    } //-- java.lang.String getSwivtParameters() 

    /**
     * Returns the value of field 'windInterpolationTable'. The
     * field 'windInterpolationTable' has the following
     * description: File that contains wind interpolation table
     * data.
     * 
     * @return the value of field 'windInterpolationTable'.
     */
    public java.lang.String getWindInterpolationTable()
    {
        return this._windInterpolationTable;
    } //-- java.lang.String getWindInterpolationTable() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'actualSwanInput'. The field
     * 'actualSwanInput' has the following description: Actual SWAN
     * input file.
     * 
     * @param actualSwanInput the value of field 'actualSwanInput'.
     */
    public void setActualSwanInput(java.lang.String actualSwanInput)
    {
        this._actualSwanInput = actualSwanInput;
    } //-- void setActualSwanInput(java.lang.String) 

    /**
     * Sets the value of field 'cleanupAction'. The field
     * 'cleanupAction' has the following description: The cleanup
     * action to be performed after the executable has run 
     * 
     * @param cleanupAction the value of field 'cleanupAction'.
     */
    public void setCleanupAction(org.openda.core.io.castorgenerated.ActionXML cleanupAction)
    {
        this._cleanupAction = cleanupAction;
    } //-- void setCleanupAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Sets the value of field 'nonSwivtParameters'. The field
     * 'nonSwivtParameters' has the following description:
     * Additional parameters not defined in swift xml file.
     * 
     * @param nonSwivtParameters the value of field
     * 'nonSwivtParameters'.
     */
    public void setNonSwivtParameters(java.lang.String nonSwivtParameters)
    {
        this._nonSwivtParameters = nonSwivtParameters;
    } //-- void setNonSwivtParameters(java.lang.String) 

    /**
     * Sets the value of field 'observationLocations'. The field
     * 'observationLocations' has the following description: File
     * containing the coordinates of observation locations.
     * 
     * @param observationLocations the value of field
     * 'observationLocations'.
     */
    public void setObservationLocations(java.lang.String observationLocations)
    {
        this._observationLocations = observationLocations;
    } //-- void setObservationLocations(java.lang.String) 

    /**
     * Sets the value of field 'perturbedValuesValidation'. The
     * field 'perturbedValuesValidation' has the following
     * description: File that contains validation rules for
     * perturbed values.
     * 
     * @param perturbedValuesValidation the value of field
     * 'perturbedValuesValidation'.
     */
    public void setPerturbedValuesValidation(java.lang.String perturbedValuesValidation)
    {
        this._perturbedValuesValidation = perturbedValuesValidation;
    } //-- void setPerturbedValuesValidation(java.lang.String) 

    /**
     * Sets the value of field 'swanAction'. The field 'swanAction'
     * has the following description: The executable to be run, and
     * its arguments
     * 
     * @param swanAction the value of field 'swanAction'.
     */
    public void setSwanAction(org.openda.core.io.castorgenerated.ActionXML swanAction)
    {
        this._swanAction = swanAction;
    } //-- void setSwanAction(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Sets the value of field 'swanInputTemplate'.
     * 
     * @param swanInputTemplate the value of field
     * 'swanInputTemplate'.
     */
    public void setSwanInputTemplate(java.lang.String swanInputTemplate)
    {
        this._swanInputTemplate = swanInputTemplate;
    } //-- void setSwanInputTemplate(java.lang.String) 

    /**
     * Sets the value of field 'swanResults'.
     * 
     * @param swanResults the value of field 'swanResults'.
     */
    public void setSwanResults(java.lang.String swanResults)
    {
        this._swanResults = swanResults;
    } //-- void setSwanResults(java.lang.String) 

    /**
     * Sets the value of field 'swivtParameters'. The field
     * 'swivtParameters' has the following description:
     * Configuration file containing SWIVT parameters.
     * 
     * @param swivtParameters the value of field 'swivtParameters'.
     */
    public void setSwivtParameters(java.lang.String swivtParameters)
    {
        this._swivtParameters = swivtParameters;
    } //-- void setSwivtParameters(java.lang.String) 

    /**
     * Sets the value of field 'windInterpolationTable'. The field
     * 'windInterpolationTable' has the following description: File
     * that contains wind interpolation table data.
     * 
     * @param windInterpolationTable the value of field
     * 'windInterpolationTable'.
     */
    public void setWindInterpolationTable(java.lang.String windInterpolationTable)
    {
        this._windInterpolationTable = windInterpolationTable;
    } //-- void setWindInterpolationTable(java.lang.String) 

    /**
     * Method unmarshalSwanCalibWrapperConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.SwanCalibWrapperConfigXML unmarshalSwanCalibWrapperConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.SwanCalibWrapperConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.SwanCalibWrapperConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.SwanCalibWrapperConfigXML unmarshalSwanCalibWrapperConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
